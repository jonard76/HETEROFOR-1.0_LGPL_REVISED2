/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.model;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import capsis.lib.castanea2018march.FmLeaf;
import capsis.lib.castanea2018march.FmSpecies;
import capsis.lib.samsaralight.SLFoliageStateManager;
import heterofor.model.meteorology.HetMeteoLine;
import heterofor.model.soil.HetSoil;
import heterofor.model.treechemistry.HetTreeCompartment;
import heterofor.model.treechemistry.HetTreeElement;
import heterofor.model.vegetationperiod.HetAbsorbedRaditionCoefficientsYearlyLevel;
import heterofor.model.vegetationperiod.HetAbsorptionCoefficientEvaluator;
import heterofor.model.waterbalance.HetHorizonsWaterContentCalculator;
import heterofor.model.waterbalance.HetWaterBalance;
import heterofor.model.waterbalance.pedon.Pedon;

/**
 * Calculate grossPrimaryProduction_kgC and maintenanceLeafRespiration_kgC
 *
 * @author M. Jonard, F. de Coligny - July 2017
 */
public class HetCastaneaPhotosynthesis {

	private HetInitialParameters ip;
	private HetScene refScene;
	private HetTree refTree;
	private HetScene newScene;
	private int newYear;
	private HetModel model;
	private HetTreeRadiationStatus radiationStatus;
	private double sunlitLeaf;
	private double shadedLeaf;
	private double crownLeafArea;

	// Returned values
	private double yearlyGPP_kgC;
	private double yearlyLeafRespiration_kgC = 0;

	/**
	 * Constructor
	 */
	public HetCastaneaPhotosynthesis(HetInitialParameters ip, HetScene refScene, HetTree refTree, HetScene newScene,
			int newYear, HetModel model, HetTreeRadiationStatus radiationStatus, double sunlitLeaf, double shadedLeaf,
			double crownLeafArea) throws Exception {

		this.ip = ip;
		this.refScene = refScene;
		this.refTree = refTree;
		this.newScene = newScene;
		this.newYear = newYear;
		this.model = model;
		this.radiationStatus = radiationStatus;
		this.sunlitLeaf = sunlitLeaf;
		this.shadedLeaf = shadedLeaf;
		this.crownLeafArea = crownLeafArea;

	}

	public void run() throws Exception {

		// fc-et-al-20.1.2017

		// Conversion Hetrofor sp -> Castanea sp
		Map<String, Integer> spMap = new HashMap<>();
		spMap.put("quercus", 3);
		spMap.put("fagus", 4);
		spMap.put("carpinus", 4);
		spMap.put("betulus", 3);
		spMap.put("broadleaved", 4);
		spMap.put("coniferous", 8);
		//fa-19.12.2019
		spMap.put("picea", 8);
		spMap.put("pseudotsuga", 11);
		spMap.put("pinus", 5);
		spMap.put("abies", 7);
		spMap.put("acer", 4);

		HetSpecies sp = refTree.getSpecies();
		int castaneaCode = spMap.get(sp.getName());
		FmSpecies fmSpecies = ip.castaneaSpeciesMap.get(castaneaCode);

		// Absorbed radiation coefficients
		double treeLeafAbsorbedDirectRadiationCoefficient = 0;
		double treeLeafAbsorbedDiffuseRadiationCoefficient = 0;

		// If not fine resolution, yearly level coefficients
		if (!ip.fineResolutionRadiativeBalanceActivated) {

			// fc+fa-17.5.2017 Refactored absorbed radiation coefficients
			// calculation
			HetAbsorbedRaditionCoefficientsYearlyLevel arcyl = new HetAbsorbedRaditionCoefficientsYearlyLevel(newScene,
					refTree);

			treeLeafAbsorbedDirectRadiationCoefficient = arcyl.getTreeLeafAbsorbedDirectRadiationCoefficient();
			treeLeafAbsorbedDiffuseRadiationCoefficient = arcyl.getTreeLeafAbsorbedDiffuseRadiationCoefficient();

			// fa-31.05.2017
			// System.out.println("LEGACY mode: TreeId = " + refTree.getId() +
			// ", treeLeafAbsorbedDirectRadiationCoefficient = " +
			// treeLeafAbsorbedDirectRadiationCoefficient +
			// ", treeLeafAbsorbedDiffuseRadiationCoefficient = " +
			// treeLeafAbsorbedDiffuseRadiationCoefficient);
		}

		double Propsun = sunlitLeaf / crownLeafArea;
		double Propshad = shadedLeaf / crownLeafArea;

		double nContent = 0; // kg
		for (HetTreeCompartment comp : refTree.getTreeCompartmentsForType(HetTreeCompartment.TYPE_LEAF)) {
			nContent += comp.getNutrientContent(HetTreeElement.N);
		}
		double NLAI = nContent * 1000 / crownLeafArea; // g/m2

		double rb = 25; // hd-20.1.2017

		double g1min = 1;
		double g1max = fmSpecies.g1;

		int istrat = 0; // upper crown part
		FmLeaf fmLeaf = new FmLeaf(istrat, ip);

		// Loop on Heterofor hourly meteo lines
		List<HetMeteoLine> lines = ip.meteorology.getMeteoLines(newYear);

		HetAbsorptionCoefficientEvaluator coefEval = null;

		if (ip.fineResolutionRadiativeBalanceActivated) {

			// Calculate for each doy of interest in the year the
			// treeLeafAbsorbedDirectRadiationCoefficient and
			// treeLeafAbsorbedDiffuseRadiationCoefficient per hour

			coefEval = new HetAbsorptionCoefficientEvaluator(refTree, refScene,
					refScene.getVegetationPeriodOfNextYear(), refScene.getBeamSetFactory().getAverageRadiation());

		}

		// // fa-19.06.2017: TRACE
		// String fileName = "heterofor_CoefEval_TagMode.txt";
		// // System.out.println("heterofor_CoefEval_TagMode.txt!!!!!!!!!!!!");
		// BufferedWriter out = new BufferedWriter(new FileWriter(fileName));
		//
		// out.write("Tree" + "\t" + "DOY" + "\t" + "hour" + "\t" + "directCoef"
		// + "\t" + "diffuseCoef" + "\t" + "ladProp"
		// + "\t" + "greenProp"+ "\t" + "radiation");
		// out.newLine();
		// // fa-19.06.2017

		for (HetMeteoLine line : lines) {

			int doy = line.getDoy();
			// int doy = HetMeteorology.doy(line.year, line.month, line.day);

			// fc+mj+fa-29.6.2017
			double ladProp = 1;
			double greenProp = 1;

			if (ip.phenologyActivated) { // fa-3.7.217: ladProp and greenProp
											// are computed only when phenology
											// mode is activated

				SLFoliageStateManager foliageStateManager = (SLFoliageStateManager) refScene;

				// Calculates ladProp at tree level. nb-06.11.2019
				// ladProp =
				// foliageStateManager.getLadProportionOfNextYear(refTree.getSpeciesCode(),
				// doy);
				ladProp = foliageStateManager.getLadProportionOfNextYear(refTree.getId(), doy);

				greenProp = foliageStateManager.getGreenProportionOfNextYear(refTree.getId(), doy);

			}

			// fc+mj+fa-29.6.2017
			double treeLeafArea_m2 = refTree.getLeafArea() * greenProp;

			// Check if we are in vegetation period
			// in FineResolutionMode, check in the scene's HetVegetationPeriod
			// (null if not fineResolution)
			// otherwise, check in SamsaraLight
			// SLModel slModel = model.getSLModel();

			// fc+fa-18.5.2017 in vegetation period ?
			// fc+mj+fa-29.6.2017 refactored
			// fa-30.6.2017: added conditions on ladProp and greenProp to avoid
			// division by zero (treeLeafArea_m2 = 0)
			// if (!model.isVegetationPeriod(refScene.getVegetationPeriod(),
			// ip.samsaFileLoader, doy) || (ladProp == 0) || (greenProp == 0))
			// if (!model.isVegetationPeriod(newScene.getVegetationPeriod(),
			// ip.samsaFileLoader, doy) || (ladProp == 0) || (greenProp == 0))
			// //fa-4.7.2017: vegetation period for current year => new scene
			// if (!model.isVegetationPeriod(newScene, doy) || (ladProp == 0) ||
			// (greenProp == 0)) //fa-4.7.2017: vegetation period for current
			// year => new scene

			if (!model.isExtendedVegetationPeriod(newScene, doy) || (ladProp == 0) || (greenProp == 0)) // fa-4.7.2017:
																										// vegetation
																										// period
																										// for
																										// current
																										// year
																										// =>
																										// new
																										// scene
				continue; // next hour in meteo lines

			double hourlyGPP = 0;
			double hourlyLeafRespiration = 0;

			// If fine resolution, hourly level coefficients
			if (ip.fineResolutionRadiativeBalanceActivated) {

				treeLeafAbsorbedDirectRadiationCoefficient = coefEval.getCrownDirectCoefficient(doy, line.hour);
				treeLeafAbsorbedDiffuseRadiationCoefficient = coefEval.getCrownDiffuseCoefficient(doy, line.hour);

				// fa-31.05.2017
				// System.out.println("TagMode: TreeId =" + refTree.getId() +
				// ", DOY = " + doy + ", hour = " + line.hour +
				// ", DirectCoef = " +
				// treeLeafAbsorbedDirectRadiationCoefficient +
				// ", DiffuseCoef = " +
				// treeLeafAbsorbedDiffuseRadiationCoefficient + ", ladProp = "
				// + refScene.getLadProportion(refTree.getSpeciesCode(), doy));

				// // fa-19.06.2017: TRACE
				// out.write("" + refTree.getId() + "\t" + doy + "\t" +
				// line.hour + "\t"
				// + treeLeafAbsorbedDirectRadiationCoefficient + "\t"
				// + treeLeafAbsorbedDiffuseRadiationCoefficient + "\t"
				// +
				// refScene.getLadProportionOfNextYear(refTree.getSpeciesCode(),
				// doy) + "\t"
				// +
				// refScene.getGreenProportionOfNextYear(refTree.getSpeciesCode(),
				// doy) + "\t"
				// +
				// refScene.getBeamSetFactory().getAverageRadiation().getIncidentGlobalRadiation(doy,
				// line.hour));
				// out.newLine();
				// // fa-19.06.2017: TRACE

			}

			double T = line.airTemperature;

			// fa-23.6.2017
			double PARsun = 0;
			double PARdif = 0;

			// fa-23.6.2017: if-else due to change of the definition of
			// treeLeafAbsorbedDirectRadiationCoefficient and
			// treeLeafAbsorbedDiffuseRadiationCoefficient in Tag mode
			// (InterceptedDirect/IncidentDirect &
			// InterceptedDiffuse/IncidentDiffuse)
			// -> to be done for Legacy mode LATER
			if (ip.fineResolutionRadiativeBalanceActivated) {
				PARsun = line.radiation * (1 - line.diffuseToGlobalRatio) * treeLeafAbsorbedDirectRadiationCoefficient
						/ (treeLeafArea_m2 * Propsun) * 4.55 * 0.46;
				PARdif = line.radiation * line.diffuseToGlobalRatio * treeLeafAbsorbedDiffuseRadiationCoefficient
						/ treeLeafArea_m2 * 4.55 * 0.46;
			} else {
				// fc+mj-10.3.2017
				PARsun = line.radiation * (1 - line.diffuseToGlobalRatio) * treeLeafAbsorbedDirectRadiationCoefficient
						/ (treeLeafArea_m2 * Propsun) * 4.55 * 0.46;
				PARdif = line.radiation * line.diffuseToGlobalRatio * treeLeafAbsorbedDiffuseRadiationCoefficient
						/ treeLeafArea_m2 * 4.55 * 0.46;

				// System.out.println("DOY = " + doy + ", CoefDirect = " +
				// treeLeafAbsorbedDirectRadiationCoefficient + ", CoefDiffuse =
				// " + treeLeafAbsorbedDiffuseRadiationCoefficient + ", PARsun =
				// " + PARsun + ", PARdif = " + PARdif + ", LeafArea = " +
				// treeLeafArea_m2 + ", ladProp = " + ladProp + ", greenProp = "
				// + greenProp);
				// double PARsun = line.radiation *
				// treeLeafAbsorbedDirectRadiationCoefficient / 3600d /
				// treeLeafArea_m2 * 4.55
				// * 0.46;
				// double PARdif = line.radiation *
				// treeLeafAbsorbedDiffuseRadiationCoefficient / 3600d /
				// treeLeafArea_m2 * 4.55
				// * 0.46;
			}

			// effect of water potential on respiration inactive in heterofor

			double potsoil = 0;

			if (line.radiation <= 0) {
				// Night
				hourlyLeafRespiration = fmLeaf.getLeafRespiration(ip, fmSpecies, NLAI, T, PARdif, potsoil) * 3600; // micro
				// mol/m2/h

			} else {
				// Day

				double RH = line.relativeHumidity;

				// fa-25.11.2019
//				String key = "" + line.year + "_" + line.month + "_" + line.day + "_" + line.hour;
				String key;
				if (!refScene.getSoil().isDiscreteSoil())
					key = "" + line.year + "_" + line.month + "_" + line.day + "_" + line.hour;
				else // waterBalanceMap already integrated at daily time step
					key = "" + line.year + "_" + line.month + "_" + line.day + "_";

				// fc-19.11.2019
				HetWaterBalance wb = newScene.getWaterBalanceMap().get(key);
				// HetWaterBalance wb = newScene.waterBalanceMap.get(key);

				// double stomatalControl = 1;
				// mj+fa-14.12.2017: for correspondence with transpiration
				// double rewSensitivity_oak = -11.14;
				// double rewSensitivity_beech = -2.15;
				// double stomatalControl = 1 - Math.exp(rewSensitivity_beech *
				// (wb.relativeExtractableWater));
				// if (sp.getName().equals("quercus"))
				// stomatalControl = 1 - Math.exp(rewSensitivity_oak *
				// (wb.relativeExtractableWater));
				// stomatalControl = Math.max(stomatalControl, 0);

				// fc+mj+fa-19.11.2019 HetHorizonsWaterContentCalculator
				Pedon refPedon = null;
				Pedon newPedon = null;
				if (!refScene.getSoil().isDiscreteSoil()) {
//				if (refScene.getSoil() instanceof HetSoil) {
					refPedon = refScene.getSoil().getPedonSpecimen();
					newPedon = newScene.getSoil().getPedonSpecimen();
					
				} else {
					// HetDiscreteSoil, get the treePedons matching the treeId
					refPedon = refScene.getSoil().getPedonMap().get(refTree.getId ());
					newPedon = newScene.getSoil().getPedonMap().get(refTree.getId ());				
				}
				
				HetHorizonsWaterContentCalculator hwcCalculator = new HetHorizonsWaterContentCalculator(refScene,
						refPedon, newPedon);

				// fa-18.06.2019
				// HetHorizonsWaterContentCalculator hwcCalculator = new
				// HetHorizonsWaterContentCalculator(refScene, newScene);

				// fc-19.11.2019
				double weightedMeanPrevWaterPotential = hwcCalculator.calculateWeightedMeanWaterPotential(
						newPedon.getHorizonMap(), wb.horizonWaterContent);
//				double weightedMeanPrevWaterPotential = hwcCalculator.calculateWeightedMeanWaterPotential(
//						newScene.getSoil().getPedonSpecimen().getHorizonMap(), wb.horizonWaterContent);
				
				// double weightedMeanPrevWaterPotential =
				// hwcCalculator.calculateWeightedMeanWaterPotential(newScene.getSoil().getHorizonMap(),
				// wb.horizonWaterContent);

				double soilPf = Math.log10(weightedMeanPrevWaterPotential);
				double stomatalControl = sp.swcModifier.result(soilPf); // mj+fa-17.06.2019

				// TO BE REVIEWED when waterBalance is checked
				// fc+mj-10.3.2017 checked ;-)
				// mj+fa-14.12.2017: commented
				// if (wb.relativeExtractableWater < 0.4)
				// stomatalControl = wb.relativeExtractableWater / 0.4;

				double g1 = (g1max - g1min) * stomatalControl + g1min;
				// g1 = g1 * 17d / refTree.getHlce(); // mj+fa-06.10.2017
				g1 = g1 * 12d / refTree.getHlce(); // mj+fa-23.10.2017 (12 is
													// the estimated Hlce for
													// Hesse)

				double Nc = fmSpecies.NC;

				double photoEvergreenCorrection = 1;

				// if (doy == 200 && line.hour == 12) {
				// System.out.println("HetTreeForwardGrower breakpoint...");
				// }

				// Case of a variable atmospheric CO2 concentration over time.
				// nb-15.03.2018
				if (ip.variableAtmCO2ConcentrationOverTime) {
					if (ip.yearAtmCO2ConcentrationMap.get(newYear) == null) {
						throw new Exception("Atmospheric CO2 concentration is missing for year: " + newYear);
					} else {
						ip.Ca = ip.yearAtmCO2ConcentrationMap.get(newYear);
					}
				}

				fmLeaf.calculateFluxes(ip, fmSpecies, NLAI, T, RH, PARsun, PARdif, Propsun, Propshad, rb, g1,
						stomatalControl, Nc, photoEvergreenCorrection, potsoil);
				hourlyGPP = fmLeaf.getGrossPhotosynthesis() * 3600; // micro
																	// mol/m2/h
				hourlyLeafRespiration = fmLeaf.getRespiration() * 3600; // micro
																		// mol/m2/h

				// if (Double.isNaN(hourlyGPP))
				// System.out.println("HetTreeForwardGrower : NaN(hourlyGPP)");

			}

			// fc+mj-10.3.2017, SHOULD be divided by 1000 ?
			// yearlyGPP_kgC += hourlyGPP * 12 * 1000 / 1E6 *
			// treeLeafArea_m2;
			// yearlyLeafRespiration_kgC += hourlyLeafRespiration * 12 * 1000d /
			// 1E6 * treeLeafArea_m2;
			yearlyGPP_kgC += hourlyGPP * 12 / 1000d / 1E6 * treeLeafArea_m2;
			yearlyLeafRespiration_kgC += hourlyLeafRespiration * 12 / 1000d / 1E6 * treeLeafArea_m2;

		}

		// // fa-19.06.2017: TRACE
		// out.close();

		// if (Double.isNaN(yearlyGPP_kgC))
		// System.out.println("HetTreeForwardGrower : NaN(yearlyGPP_kgC)");

	}

	public double getYearlyGPP_kgC() {
		return yearlyGPP_kgC;
	}

	public double getYearlyLeafRespiration_kgC() {
		return yearlyLeafRespiration_kgC;
	}

}
