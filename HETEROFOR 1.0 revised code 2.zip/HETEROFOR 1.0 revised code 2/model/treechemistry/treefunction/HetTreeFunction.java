/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.model.treechemistry.treefunction;

import java.io.Serializable;

import heterofor.model.treechemistry.HetTreeCompartment;

/**
 * A superclass for concentration functions for tree compartments.
 *
 * @author M. Jonard - March 2016
 */
public abstract class HetTreeFunction implements Serializable {

	/**
	 * A convenient method to decode a HetTreeFunction
	 */
	static public HetTreeFunction getFunction(String encodedFunction) throws Exception {
		if (encodedFunction.startsWith("defaultFunction")) {
			return new HetTreeDefaultFunction(encodedFunction);
		} else if (encodedFunction.startsWith("normal")) {
			return new HetTreeNormalFunction(encodedFunction);
		} else if (encodedFunction.startsWith("logNormal")) {
			return new HetTreeLogNormalFunction(encodedFunction);
		} else if (encodedFunction.startsWith("decreasing(")) {
			return new HetTreeDecreasingFunction(encodedFunction);
		} else if (encodedFunction.startsWith("decreasingBarkWood")) {
			return new HetTreeDecreasingBarkWoodFunction(encodedFunction);
		} else {
			throw new Exception("HetTreeFunction, unknown function: " + encodedFunction);
		}

	}

	/**
	 * Returns a concentration value for the given compartment.
	 */
	public abstract double getValue(HetTreeCompartment compartment);

}
