/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.model.treechemistry;

import heterofor.model.HetElementState;
import heterofor.model.HetReporter;

import java.io.Serializable;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import jeeb.lib.util.DefaultNumberFormat;
import jeeb.lib.util.Log;

/**
 * HetLitterCompartment is a tree compartment of litter, e.g. leaves, branches,
 * fine roots...
 *
 * @author M. Jonard - March 2016
 */
public class HetLitterCompartment implements HetCompartment, Serializable {

	private static NumberFormat nf = DefaultNumberFormat.getInstance(2);

	// 5 compartment names
	public static final String LEAVES = "LEAVES";
	public static final String BRANCHES = "BRANCHES";
	public static final String ROOTS = "ROOTS";
	public static final String FINE_ROOTS = "FINE_ROOTS";
	public static final String MYCORRHIZAE = "MYCORRHIZAE";
	public static final String FRUITS = "FRUITS"; //mj+fa-01.12.2017

	public static List<String> compartmentNames;
	public static Map<String, String> shortNames; // fc-28.9.2016
	public static Set<String> aboveGroundCompartmentNames; // fc+mj-7.12.2016

	static {
		compartmentNames = new ArrayList<>();
		compartmentNames.add(LEAVES);
		compartmentNames.add(BRANCHES);
		compartmentNames.add(ROOTS);
		compartmentNames.add(FINE_ROOTS);
		compartmentNames.add(MYCORRHIZAE);
		compartmentNames.add(FRUITS); //mj+fa-01.12.2017

		shortNames = new HashMap<>(); // fc-28.9.2016
		shortNames.put(LEAVES, "lc.Le");
		shortNames.put(BRANCHES, "lc.Br");
		shortNames.put(ROOTS, "lc.Ro");
		shortNames.put(FINE_ROOTS, "lc.FRo");
		shortNames.put(MYCORRHIZAE, "lc.My");
		shortNames.put(FRUITS, "lc.Fr"); //mj+fa-01.12.2017

		aboveGroundCompartmentNames = new HashSet<>();
		aboveGroundCompartmentNames.add(LEAVES);
		aboveGroundCompartmentNames.add(BRANCHES);
		aboveGroundCompartmentNames.add(FRUITS); //mj+fa-01.12.2017

	}

	public String name; // LEAVES,... MYCORRHIZAE

	public double biomass; // kgC

	private HetElementState concentrations; // Nutrient name -> concentration
											// (mg/g)

	/**
	 * Constructor.
	 */
	public HetLitterCompartment(String name) {
		this.name = name;
		this.concentrations = new HetElementState();
	}

	public boolean isAboveGround () {
		return aboveGroundCompartmentNames.contains (name);
	}

	public double getNutrientFlux(String eName) {
		double Cconc = getConcentration(HetTreeElement.C);
		if (Cconc == 0)
			Cconc = 500;
		double v = biomass / (Cconc / 1000d) * (getConcentration(eName) / 1000d); // Kg
		if (Double.isNaN(v)) {
			HetReporter.printInLog("HetLitterCompartment.getNutientFlux () NaN, biomass: " + biomass + " Cconc: " + Cconc
					+ " eName: " + eName + " getConcentration(eName): " + getConcentration(eName));
		}
		return v;
		// return biomass / (Cconc / 1000d) * (getConcentration(eName) / 1000d);
		// // Kg
	}

	public void setBiomass(double biomass) {
		this.biomass = biomass;
	}

	@Override
	public String getName() {
		return name;
	}

	@Override
	public double getBiomass() {
		return biomass;
	}

	public void setConcentration(String elementName, double concentration) {
		concentrations.setValue(elementName, concentration);
	}

	/**
	 * Returns the concentration for the given element name or null if the
	 * element is not in the ElementState
	 */
	public Double getConcentration(String eName) {
		return concentrations.getValue(eName);
	}

	public HetElementState getConcentrations() { // fc-22.9.2016
		return concentrations;
	}

	public String getFormattedHeader(String separatorBetweenElements) {

		StringBuffer b = new StringBuffer();

		b.append(getShortName(name) + " biomass(KgC)");
		b.append(separatorBetweenElements);

		String prefix = getShortName(name) + " "; // lc.Le...
		String suffix = "(mg/g)";
		String s = concentrations.getFormattedHeader("\t", prefix, suffix);
		b.append(s);

		return b.toString();
	}

	public String getFormattedValues(String separatorBetweenElements) {

		StringBuffer b = new StringBuffer();
		b.append("" + nf.format(biomass));

		b.append(separatorBetweenElements);
		b.append(concentrations.getFormattedValues("\t"));

		return b.toString();

	}

	/**
	 * Returns this compartments concentration or nutrient content for each
	 * element name in a formatted String. e.g. possible outputs: "C N P S Ca Mg
	 * K Na Al Mn Fe Cl Si" OR "475.16 4.21 0.09 0.14 1.49 0.21 1.06 0 0 0.44 0
	 * 0 0"
	 *
	 * @param concentrationIfTrueElseFlux
	 *            : if true, writes concentration, else writes nutrient flux
	 * @param separatorBetweenElements
	 *            : to be used between each element information
	 * @param includingElementNames
	 *            : if true, each element name is written
	 * @param includingValues
	 *            : if true, each value is written
	 * @param separatorBetweenElementNameAndValue
	 *            : if both element name and valu are written, this separator is
	 *            written between them
	 * @param replaceNullAndNaNByZero
	 *            : if true, null and NaN values are replaced by zeroes
	 * @return
	 */
//	public String getFormatedString(boolean concentrationIfTrueElseFlux, String separatorBetweenElements,
//			boolean includingElementNames, boolean includingValues, String separatorBetweenElementNameAndValue,
//			boolean replaceNullAndNaNByZero) {
//
//		StringBuffer b = new StringBuffer();
//		boolean first = true;
//		for (String eName : HetTreeElement.elementNames) {
//
//			if (first)
//				first = false;
//			else
//				b.append(separatorBetweenElements);
//
//			if (includingElementNames)
//				b.append(eName);
//
//			if (includingElementNames && includingValues)
//				b.append(separatorBetweenElementNameAndValue);
//
//			if (includingValues) {
//
//				Double v = null;
//				if (concentrationIfTrueElseFlux)
//					v = concentrations.getValue(eName);
//				else
//					v = getNutrientFlux(eName);
//
//				if (v == null) {
//					b.append(replaceNullAndNaNByZero ? 0 : "null");
//				} else if (v.isNaN()) {
//					b.append(replaceNullAndNaNByZero ? 0 : "NaN");
//				} else {
//					b.append(nf.format(v));
//				}
//			}
//
//		}
//		return b.toString();
//
//	}

	/**
	 * Returns the short name of the given element, returns the given name if
	 * not found.
	 */
	public static String getShortName(String eName) { // fc-28.9.2016
		String sn = shortNames.get(eName);
		return sn != null ? sn : eName;
	}

	public String toString() {
		StringBuffer c = new StringBuffer();
		for (String eName : HetTreeElement.elementNames) {
			c.append(" ");
			c.append(eName);
			c.append(": ");
			Double v = concentrations.getValue(eName);
			if (v == null) {
				c.append("null");
			} else {
				c.append(nf.format(v));
			}
		}

		return name + " biomass: " + biomass + c;
	}

}
