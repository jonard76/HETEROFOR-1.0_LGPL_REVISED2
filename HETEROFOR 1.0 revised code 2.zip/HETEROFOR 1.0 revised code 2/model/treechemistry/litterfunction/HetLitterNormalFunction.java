/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.model.treechemistry.litterfunction;

import heterofor.model.treechemistry.HetLitterCompartment;

import java.util.StringTokenizer;

import jeeb.lib.util.Check;

/**
 * A concentration function for an element in a litter compartment.
 *
 * @author M. Jonard - March 2016
 */
public class HetLitterNormalFunction extends HetLitterFunction {

	private double mean;
	private double sd;

	/**
	 * Constructor.
	 */
	public HetLitterNormalFunction(String str) throws Exception { // e.g.
															// normal(509.3;20.35)
		if (!str.startsWith("normal(")) {
			throw new Exception("HetLitterNormalFunction error, string should start with \"normal(\": " + str);
		}
		String s = str.replace("normal(", "");
		s = s.replace(')', ' ');
		s = s.trim();
		StringTokenizer st = new StringTokenizer(s, " ;");
		mean = Check.doubleValue(st.nextToken());
		sd = Check.doubleValue(st.nextToken());

	}

	/**
	 * Returns a concentration value for the given compartment.
	 */
	@Override
	public double getValue(HetLitterCompartment compartment) {
		return mean;
	}

	public String toString() {
		return "normal(" + mean + ";" + sd + ")";
	}

}
