/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.model.treechemistry.litterfunction;

import heterofor.model.treechemistry.HetLitterCompartment;

import java.io.Serializable;

/**
 * A superclass for concentration functions for litter compartments.
 *
 * @author M. Jonard - March 2016
 */
public abstract class HetLitterFunction implements Serializable {

	/**
	 * A convenient method to decode a HetLitterFunction
	 */
	static public HetLitterFunction getFunction(String encodedFunction) throws Exception {
		if (encodedFunction.startsWith("defaultFunction")) {
			return new HetLitterDefaultFunction(encodedFunction);
		} else if (encodedFunction.startsWith("normal")) {
			return new HetLitterNormalFunction(encodedFunction);
		} else if (encodedFunction.startsWith("logNormal")) {
			return new HetLitterLogNormalFunction(encodedFunction);
		} else {
			throw new Exception("HetLitterFunction, unknown function: " + encodedFunction);
		}

	}

	/**
	 * Returns a concentration value for the given compartment.
	 */
	public abstract double getValue(HetLitterCompartment compartment);

}
