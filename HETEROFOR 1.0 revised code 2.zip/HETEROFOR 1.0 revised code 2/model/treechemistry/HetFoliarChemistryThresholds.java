/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.model.treechemistry;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jeeb.lib.util.ListMap;

/**
 * Foliar thresholds for given species and nutrients.
 *
 * @author M. Jonard - March 2016
 */
public class HetFoliarChemistryThresholds implements Serializable {

	private ListMap<String, String> species_elementList;

	// Key: speciesName+'.'+elementName
	// Value: foliar deficiency concentration
	private Map<String, Double> deficiencyMap;

	// Key: speciesName+'.'+elementName
	// Value: foliar optimum concentration
	private Map<String, Double> optimumMap;

	/**
	 * Constructor
	 */
	public HetFoliarChemistryThresholds() {
		species_elementList = new ListMap<>();
		deficiencyMap = new HashMap<>();
		optimumMap = new HashMap<>();
	}

	public void add(String speciesName, String elementName, double foliarDeficiencyConcentration,
			double foliarOptimumConcentration) {

		species_elementList.addObject(speciesName, elementName);

		String key = speciesName+'.'+elementName;
		deficiencyMap.put(key, foliarDeficiencyConcentration);
		optimumMap.put(key, foliarOptimumConcentration);

	}

	public List<String> getElementNames (String speciesName) {
		return species_elementList.getObjects(speciesName);
	}

	public double getDeficiencyConcentration (String speciesName, String elementName) {
		String key = speciesName+'.'+elementName;
		return deficiencyMap.get(key);
	}

	public double getOptimumConcentration (String speciesName, String elementName) {
		String key = speciesName+'.'+elementName;
		return optimumMap.get(key);
	}

	// Mainly for checking in Capsis inspectors
	public Map<String, Double> getDeficiencyMap () {
		return deficiencyMap;
	}

	// Mainly for checking in Capsis inspectors
	public Map<String, Double> getOptimumMap() {
		return optimumMap;
	}

}
