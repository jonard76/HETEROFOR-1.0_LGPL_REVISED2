/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.model;

import java.util.List;

import jeeb.lib.util.Import;
import jeeb.lib.util.Record;
import jeeb.lib.util.fileloader.FileLoader;

/**
 * This class allows to store in a map the content of the fructification's observations file.
 *
 * @author N. Beudez - November 2017
 */
public class HetFructificationFileLoader extends FileLoader {

	public List<HetFructificationRecord> fructificationObservationList;

	/**
	 * Constructor.
	 */
	public HetFructificationFileLoader() throws Exception {

		super();
	}

	@Override
	protected void checks() throws Exception {
	}

	/**
	 * An observation of fructification in the file.
	 *
	 * @author N. Beudez - November 2017
	 */
	@Import
	static public class HetFructificationRecord extends Record {

		public int year;
		public String speciesName;
		public double fruitLitterFall; // kg/ha

		public  HetFructificationRecord(String line) throws Exception {

			super(line);
		}
	}
}
