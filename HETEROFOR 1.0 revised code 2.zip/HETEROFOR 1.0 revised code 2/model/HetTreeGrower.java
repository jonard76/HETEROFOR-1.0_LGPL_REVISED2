/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.model;

import java.io.Serializable;

import heterofor.model.waterbalance.HetYearlyTranspirationMemory;

/**
 * A superclass for the Heterofor tree growth options.
 *
 * @author M. Jonard - March 2016
 */
public abstract class HetTreeGrower implements Serializable {

	public abstract HetTree getTree();

	public abstract HetTreeRadiationStatus getRadiationStatus();

	public abstract double getParUseEfficiency();

	public abstract double getGrossPrimaryProduction_kgC();

	public abstract double getMaintenanceRespiration_kgC();

	public abstract double getLeafRetranslocation_kgC();

	public abstract double getFineRootRetranslocation_kgC();

	public abstract double getNetPrimaryProduction_kgC();

	public abstract HetFunctionalCompartmentsProduction getProduction();

	public abstract double getTotalStructuralBiomassToAllocate_kgC();

	public abstract double getDeltaAboveGroundStructuralBiomass_kgC();

	public abstract double getDeltaDbh2Height(); //fa-31.10.2018

	public abstract double getDeltaG(); //fa-02.11.2018

	public abstract double getDeltaHeight();

	public abstract double getDeltaDbh_cm();

	// fc+mj+fa-14.11.2017
	public abstract HetYearlyTranspirationMemory getYearlyTranspirationMemory();

}
