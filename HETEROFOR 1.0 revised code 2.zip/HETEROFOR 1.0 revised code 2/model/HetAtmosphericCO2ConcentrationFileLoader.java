/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.model;

import java.util.List;

import jeeb.lib.util.Record;
import jeeb.lib.util.fileloader.FileLoader;

/**
 * A file loader for the atmospheric CO2 concentrations file.
 *
 * @author N. Beudez - March 2018
 *
 */
public class HetAtmosphericCO2ConcentrationFileLoader extends FileLoader {

	public List<AtmosphericCO2ConcentrationRecord> atmCO2ConcRecords;

	/**
	 * Constructor.
	 * @throws Exception
	 */
	public HetAtmosphericCO2ConcentrationFileLoader() throws Exception {
		super();
	}

	@Override
	protected void checks() throws Exception {
		// TODO FP Auto-generated method stub
	}

	// A line in the atmospheric CO2 concentrations file.
	static public class AtmosphericCO2ConcentrationRecord extends Record {

		public int year;
		public double atmCO2Concentration;

		public AtmosphericCO2ConcentrationRecord(String line) throws Exception {
			super(line);
		}
	}
}
