/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.model.nutrientlimitation;

import heterofor.model.HetElementState;
import heterofor.model.HetInitialParameters;
import heterofor.model.HetModel;
import heterofor.model.HetReporter;
import heterofor.model.HetScene;
import heterofor.model.HetSpecies;
import heterofor.model.HetTree;
import heterofor.model.HetTreeBuilder;
import heterofor.model.HetTreeForwardGrower;
import heterofor.model.treechemistry.HetTreeCompartment;
import heterofor.model.treechemistry.HetTreeElement;
import heterofor.model.waterbalance.HetYearlyTranspirationMemory;

import java.util.Random;

import jeeb.lib.util.Log;

/**
 * Compute tree actual uptake.
 *
 * @author M. Jonard - May 2016
 */
public class ActualUptakeCalculator {
	private HetInitialParameters ip;
	private HetModel model;
	private Random random;
	private HetScene refScene;
	private HetElementState refSceneLitterNutrientReturn;
	private HetTree refTree;
	private HetTree newTree;
	private HetElementState potentialUptake;
	private HetElementState requirement;
	private HetElementState retranslocation;
	private HetElementState demand;
	private double refStandLeafArea;
	private double refNStandDemand;
	private double refStandLitterNReturn_kg;


	private boolean reducedGrowth;
	private double minNppToGppRatio = 1; // 1 is the max value
	private HetElementState actualUptake;

	private boolean inverseGrowth;

	// fc+mj+fa-14.11.2017
	private HetYearlyTranspirationMemory yearlyTranspirationMemory;

	//fa+mj-05.12.2017
	private double fruitLitterFall_kgC;
	/**
	 * Constructor.
	 */
	public ActualUptakeCalculator(HetInitialParameters ip, HetModel model, Random random,
			HetScene refScene, HetElementState refSceneLitterNutrientReturn,
			HetTree refTree, HetTree newTree, HetElementState potentialUptake,
			HetElementState requirement, HetElementState retranslocation,
			HetElementState demand, double refStandLeafArea,
			double refNStandDemand, double refStandLitterNReturn_kg,
			boolean inverseGrowth, HetYearlyTranspirationMemory yearlyTranspirationMemory, double fruitLitterFall_kgC) {
		this.ip = ip;
		this.model = model; // fc-et-al-20.1.2017
		this.random = random;
		this.refScene = refScene;
		this.refSceneLitterNutrientReturn = refSceneLitterNutrientReturn;
		this.refTree = refTree;
		this.newTree = newTree;
		this.potentialUptake = potentialUptake;
		this.requirement = requirement;
		this.retranslocation = retranslocation;
		this.demand = demand;
		this.refStandLeafArea = refStandLeafArea;
		this.refNStandDemand = refNStandDemand;
		this.refStandLitterNReturn_kg = refStandLitterNReturn_kg;
		this.inverseGrowth = inverseGrowth;

		this.yearlyTranspirationMemory = yearlyTranspirationMemory;
		this.fruitLitterFall_kgC = fruitLitterFall_kgC; //mj+fa-05.12.2017

		actualUptake = new HetElementState();
	}

	/**
	 * Set nutrient status of the given tree, for the given eName with the given
	 * value, only if nutrient limitation is activated.
	 */
	private void setNutrientStatus(HetTree tree, String eName, double value) {

		// If nutrient limitation not activated, do not changed the eName value
		if (ip.generalNutrientLimitation)
			tree.getNutrientStatusMap().setValue(eName, value);

	}

	public void execute() throws Exception {

		// Soil chemistry is optional
		if (!refScene.isSoilChemistryAvailable())
			return;

		double area_ha = refScene.getArea() / 10000d;

		// Deficient and optimal status maps
		HetElementState deficientStatus = new HetElementState();
		HetElementState optimalStatus = new HetElementState();
		HetElementState nutrientStatusMap = refTree.getNutrientStatusMap();
		for (String eName : nutrientStatusMap.getKeys()) {
			deficientStatus.setValue(eName, 0);
			optimalStatus.setValue(eName, 1);
		}

		HetElementState deficientDemand = estimateDemand(refTree, newTree,
				deficientStatus);
		HetElementState optimalDemand = estimateDemand(refTree, newTree,
				optimalStatus);

		// fc+mj-7.12.2016
		newTree.setDeficientDemand(deficientDemand);
		newTree.setOptimalDemand(optimalDemand);

		for (String eName : HetTreeElement.elementNames) {

			if (inverseGrowth) {

				double dem = demand.getValue(eName);
				actualUptake.setValue(eName, dem);

			} else {

				// (1) Nitrogen
				if (eName.equals("N")) {

					double NDeposition_kg = refScene.getSoil()
							.getNutrientDeposition().getValue("N")
							* area_ha;
					double litterNReturn_kg = refTree.getLitterNutrientReturn()
							.getValue("N");
//					double NAvailable_kg = NDeposition_kg + refStandLitterNReturn_kg;

					if (!ip.nLimitation) {

						// fc+mj-9.12.2016
						double v = demand.getValue("N");
						actualUptake.setValue("N", v);

					} else { // nNutrientLimitation is true

						double defDemand_g = deficientDemand.getValue("N");
						double optDemand_g = optimalDemand.getValue("N");

						// fc+mj-9.12.2016
						double currentDemand_g = demand.getValue("N");

						// double nAllocatedToTree = refTree.getLeafArea()
						// / refStandLeafArea;
						double nAllocatedToTree = litterNReturn_kg
								/ refStandLitterNReturn_kg;
						if (refTree.getDemand() != null)
							nAllocatedToTree = refTree.getDemand().getValue("N")
									/ refNStandDemand;

						// double nDepositionAllocatedToTree = litterNReturn_kg
						// / refSceneLitterNutrientReturn.getValue("N");

						double pot_g = (litterNReturn_kg + NDeposition_kg
								* nAllocatedToTree) * 1000d;

						if (pot_g < defDemand_g) {

							reducedGrowth = true;

							// Search the nppToGppRatio which equalizes
							// defDemand and potential uptake
							double[] nppToGppRatioAndDemand = optimizeNppToGppRatio(
									"N", pot_g, refTree);
							double nppToGppRatio = nppToGppRatioAndDemand[0];
							double demand = nppToGppRatioAndDemand[1];
							setNutrientStatus(newTree, "N", 0);
							actualUptake.setValue("N", demand);

							minNppToGppRatio = Math.min(minNppToGppRatio,
									nppToGppRatio);

						} else { // pot_g >= defDemand_g

							if (pot_g >= optDemand_g) {

								if (currentDemand_g > optDemand_g) {

									if (pot_g > currentDemand_g) {

										actualUptake.setValue("N", currentDemand_g);

									} else { // pot_g <= currentDemand_g

										// Search the nutrientStatus which equalizes
										// demand
										// and potential uptake
										double[] statusAndDemand = optimizeStatus(
												"N", pot_g, refTree, newTree);
										double status = statusAndDemand[0];
										setNutrientStatus(newTree, "N", status);
										actualUptake.setValue("N", pot_g);

									}

								} else { // currentDemand_g <= optDemand_g

									// Search the nutrientStatus which equalizes
									// demand
									// and potential uptake
									double[] statusAndDemand = optimizeStatus("N",
											pot_g, refTree, newTree);
									double status = statusAndDemand[0];

									status = Math.min(3d, status);
									setNutrientStatus(newTree, "N", status);

									HetElementState demand = estimateDemand(
											refTree, newTree,
											newTree.getNutrientStatusMap());
									actualUptake
											.setValue("N", demand.getValue("N"));

									// actualUptake.setValue("N", optDemand_g);
									// updateNutrientStatusMap(newTree, "N", 1);

								}

								// Memo: NDrainage = pot - optDemand;

							} else { // pot_g < optDemand_g

								// Search the nutrientStatus which equalizes demand
								// and potential uptake
								double[] statusAndDemand = optimizeStatus("N",
										pot_g, refTree, newTree);
								double status = statusAndDemand[0];
								double demand = statusAndDemand[1];
								setNutrientStatus(newTree, "N", status);
								actualUptake.setValue("N", demand);

							}
						}
					}

					// (2) Elements other than Nitrogen, with a nutrient status
				} else if (nutrientStatusMap.contains(eName)) {

					double pot_g = potentialUptake.getValue(eName);
					double defDemand_g = deficientDemand.getValue(eName);
					double optDemand_g = optimalDemand.getValue(eName);

					// fc+mj-9.12.2016
					double currentDemand_g = demand.getValue(eName);

					if (pot_g < defDemand_g) {

						reducedGrowth = true;

						// Search the nppToGppRatio which equalizes
						// defDemand and potential uptake
						double[] nppToGppRatioAndDemand = optimizeNppToGppRatio(
								eName, pot_g, refTree);
						double nppToGppRatio = nppToGppRatioAndDemand[0];
						double demand = nppToGppRatioAndDemand[1];
						setNutrientStatus(newTree, eName, 0);
						actualUptake.setValue(eName, demand);

						minNppToGppRatio = Math.min(minNppToGppRatio,
								nppToGppRatio);

					} else { // pot_g >= defDemand_g

						if (pot_g >= optDemand_g) {

							if (currentDemand_g > optDemand_g) {

								if (pot_g > currentDemand_g) {

									actualUptake.setValue(eName,
											currentDemand_g);

								} else { // pot_g <= currentDemand_g

									// Search the nutrientStatus which equalizes
									// demand
									// and potential uptake
									double[] statusAndDemand = optimizeStatus(
											eName, pot_g, refTree, newTree);
									double status = statusAndDemand[0];
									setNutrientStatus(newTree, eName, status);
									actualUptake.setValue(eName, pot_g);

								}

							} else { // currentDemand_g <= optDemand_g

								// Search the nutrientStatus which equalizes
								// demand
								// and potential uptake
								double[] statusAndDemand = optimizeStatus(
										eName, pot_g, refTree, newTree);
								double status = statusAndDemand[0];

								status = Math.min(3d, status);
								setNutrientStatus(newTree, eName, status);

								HetElementState demand = estimateDemand(
										refTree, newTree,
										newTree.getNutrientStatusMap());
								actualUptake.setValue(eName,
										demand.getValue(eName));

								// actualUptake.setValue("N", optDemand_g);
								// updateNutrientStatusMap(newTree, "N", 1);

							}

							// Memo: NDrainage = pot - optDemand;

							// setNutrientStatus(newTree, eName, 1);
							// actualUptake.setValue(eName, optDemand);

						} else { // pot_g < optDemand_g

							// Search the nutrientStatus which equalizes demand
							// and potential uptake
							double[] statusAndDemand = optimizeStatus(eName,
									pot_g, refTree, newTree);
							double status = statusAndDemand[0];
							double demand = statusAndDemand[1];
							setNutrientStatus(newTree, eName, status);
							actualUptake.setValue(eName, demand);

						}
					}

					// (3) Elements other than Nitrogen, without nutrient status
				} else {

					double dem = demand.getValue(eName);
					double pot = potentialUptake.getValue(eName);

					if (Double.isNaN(dem))
						HetReporter.printInLog("ActualUptakeCalculator dem is *NaN* for eName: " + eName);
					if (Double.isNaN(pot))
						HetReporter.printInLog("ActualUptakeCalculator pot is *NaN* for eName: " + eName);

					actualUptake.setValue(eName, Math.min(dem, pot));

				}

			}

		}

	}

	/**
	 * Modifies the given LEAVES_UPPER_CURRENT compartment according to the
	 * given nutrient status map. Caution: the nutrient status map may not
	 * contain all the elements.
	 */
	public void updateLuc(HetInitialParameters ip, HetSpecies sp,
			HetTreeCompartment luc, HetElementState nutrientStatusMap) {
		String speciesName = sp.getName();

		for (String eName : nutrientStatusMap.getKeys()) {
			double status = nutrientStatusMap.getValue(eName);

			double def = ip.foliarChemistryThresholds
					.getDeficiencyConcentration(speciesName, eName);
			double opt = ip.foliarChemistryThresholds.getOptimumConcentration(
					speciesName, eName);
			double c1 = def + status * (opt - def);

			luc.setConcentration(eName, c1);

		}

	}

	private HetElementState estimateDemand(HetTree refTree, HetTree newTree,
			HetElementState nutrientStatus) {
		HetSpecies species = refTree.getSpecies();
		HetTreeCompartment refLuc = refTree
				.getTreeCompartment(HetTreeCompartment.LEAVES_UPPER_CURRENT);

		// Tree copy
		HetTree treeCopy = refTree.getCopy();
		HetTreeCompartment lucCopy = refLuc.getCopy();
		updateLuc(ip, species, lucCopy, nutrientStatus);
		treeCopy.addTreeCompartment(lucCopy);

		// Create tree and litter compartments based on lucCopy
		ip.createTreeCompartments(lucCopy, treeCopy);

		treeCopy.createLitterCompartments(refScene, ip);
//		ip.createLitterCompartments(refScene, treeCopy);

		NutrientDemandCalculator ndc = new NutrientDemandCalculator(ip, random,
				refScene, treeCopy, newTree);
		ndc.execute();
		HetElementState estimatedDemand = ndc.getDemand();

		return estimatedDemand;
	}

	/**
	 * Optimize nppToGppRatio to match demand and potential uptake. Returns 2
	 * doubles in an array: nppToGppRatio and corresponding demand.
	 * @throws Exception
	 */
	private double[] optimizeNppToGppRatio(String eName, double pot,
			HetTree refTree) throws Exception {

		HetInitialParameters ip2 = (HetInitialParameters) ip.clone();
		ip2.constantNppToGppRatio = true; // use nppToGppRatio during growth

		int max = 100;
		int i = 0;
		double inf = 0;
		double sup = 1;

		double dem = -1;
		double nppToGppRatio = -1;

		// fc-et-al-20.1.2017 not needed here
		int newYear = 0;
		HetScene newScene = null;

		double EPSILON = 0.0001;
		while (Math.abs(sup - inf) > EPSILON && i <= max) {
			i++;

			nppToGppRatio = (inf + sup) / 2d;

			// Tree growth
//			refTree.setNppToGppRatio (nppToGppRatio);

			HetTreeForwardGrower grower = new HetTreeForwardGrower(ip2, random,
					refScene, refTree, newYear, newScene, model, nppToGppRatio,
					yearlyTranspirationMemory, fruitLitterFall_kgC);
			HetTreeBuilder treeBuilder = new HetTreeBuilder(refTree, grower);
			HetTree newTree2 = treeBuilder.getNewTree();

			HetElementState candidateStatusMap = new HetElementState();
			candidateStatusMap.setValue(eName, 0);
			HetElementState demand = estimateDemand(refTree, newTree2,
					candidateStatusMap);

			dem = demand.getValue(eName);

			if (pot - dem > 0)
				inf = nppToGppRatio;
			else
				sup = nppToGppRatio;

		}

		if (i >= max) {
			System.out
					.println("ActualUptakeCalculator optimizeStatus() did not converge in "
							+ i
							+ " iterations, final nppToGppRatio: "
							+ nppToGppRatio);
		}

		return new double[] { nppToGppRatio, dem };

	}

	/**
	 * Optimize nutrient status to match demand and potential uptake. Returns 2
	 * doubles in an array: status and corresponding demand.
	 */
	private double[] optimizeStatus(String eName, double pot, HetTree refTree,
			HetTree newTree) {

		int max = 100;
		int i = 0;
		double inf = 0;
		double sup = 1;

		double dem = -1;
		double status = -1;

		double EPSILON = 0.0001;
		while (Math.abs(sup - inf) > EPSILON && i <= max) {
			i++;

			status = (inf + sup) / 2d;

			HetElementState candidateStatusMap = new HetElementState();
			candidateStatusMap.setValue(eName, status);
			HetElementState demand = estimateDemand(refTree, newTree,
					candidateStatusMap);

			dem = demand.getValue(eName);

			if (pot - dem > 0)
				inf = status;
			else
				sup = status;

		}

		if (i >= max) {
			System.out
					.println("ActualUptakeCalculator optimizeStatus() did not converge in "
							+ i + " iterations, final status: " + status);
		}

		return new double[] { status, dem };
	}

	public boolean isReducedGrowth() {
		return reducedGrowth;
	}

	public double getMinNppToGppRatio() {
		return minNppToGppRatio;
	}

	public HetElementState getActualUptake() {
		return actualUptake;
	}

}
