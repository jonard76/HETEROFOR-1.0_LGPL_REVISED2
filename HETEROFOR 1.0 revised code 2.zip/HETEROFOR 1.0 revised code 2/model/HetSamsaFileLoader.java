/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.model;

import java.io.Serializable;

import capsis.lib.samsaralight.SLBeamSet;
import capsis.lib.samsaralight.SLModel;
import capsis.lib.samsaralight.SLSettings;

/**
 * A file loader for SamsaraLight: loads the file and manages the slSettings.
 *
 * @author F. de Coligny - June 2017
 */
public class HetSamsaFileLoader implements Serializable {
	// Main variables
	protected SLModel slModel;
	protected SLSettings slSettings;

	protected String samsaraLightFileName;

	/**
	 * Constructor
	 */
	public HetSamsaFileLoader(String samsaraLightFileName) throws Exception {

		this.samsaraLightFileName = samsaraLightFileName;

		slModel = new SLModel();

		slSettings = slModel.getSettings();
		slSettings.setFileName(samsaraLightFileName);

		slModel.init1_loadSettingsFile();

	}

	public SLModel getSLModel() {
		return slModel;
	}

	public boolean isVegetationPeriod(int doy) {
		return doy >= getLeafOnDoy() && doy <= getLeafOffDoy();
	}

	public SLBeamSet getBeamSet() {
		return slModel.getBeamSet();
	}

	public void setLeafOnDoy(int v) {
		slSettings.setLeafOnDoy(v);
	}

	public int getLeafOnDoy() {
		return slSettings.getLeafOnDoy();
	}

	public void setLeafOffDoy(int v) {
		slSettings.setLeafOffDoy(v);
	}

	public int getLeafOffDoy() {
		return slSettings.getLeafOffDoy();
	}

	public boolean isTrunkInterception() {
		return slSettings.isTrunkInterception();
	}

	public void setPlotLatitude_deg(double v) {
		slSettings.setPlotLatitude_deg(v);
	}

	public double getPlotLatitude_deg() {
		return slSettings.getPlotLatitude_deg();
	}

	public void setPlotLongitude_deg(double v) {
		slSettings.setPlotLongitude_deg(v);
	}

	public double getPlotLongitude_deg() {
		return slSettings.getPlotLongitude_deg();
	}

	public void setPlotSlope_deg(double v) {
		slSettings.setPlotSlope_deg(v);
	}

	public double getPlotSlope_deg() {
		return slSettings.getPlotSlope_deg();
	}

	public void setPlotAspect_deg(double v) {
		slSettings.setPlotAspect_deg(v);
	}

	public double getPlotAspect_deg() {
		return slSettings.getPlotAspect_deg();
	}

	public void setNorthToXAngle_cw_deg(double v) {
		slSettings.setNorthToXAngle_cw_deg(v);
	}

	public double getNorthToXAngle_cw_deg() {
		return slSettings.getNorthToXAngle_cw_deg();
	}

	public int getGMT() {
		return slSettings.getGMT();
	}

	public boolean isSensorLightOnly() {
		return slSettings.isSensorLightOnly();
	}

	public boolean hasMonthlyRecords() {
		return slSettings.getMontlyRecords() != null && !slSettings.getMontlyRecords().isEmpty();
	}

	public boolean hasHourlyRecords() {
		return slSettings.getHourlyRecords() != null && !slSettings.getHourlyRecords().isEmpty();
	}

	public void setTurbidMedium(boolean v) { //fa-10.11.2017
		slSettings.setTurbidMedium(v);
	}

	public boolean isTurbidMedium() { //fa-10.11.2017
		return slSettings.isTurbidMedium();
	}

}
