/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.model;

import heterofor.model.fineresolutionradiativebalance.HetAverageRadiation;
import heterofor.model.fineresolutionradiativebalance.HetAverageRadiationLine;
import heterofor.model.meteorology.HetMeteorology;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;

import capsis.lib.samsaralight.SLHourlyRecord;
import capsis.lib.samsaralight.SLModel;

/**
 * A manager for the SamsaraLight radiative balance process in Heterofor: legacy
 * mode for standard processing.
 *
 * @author F. de Coligny - June 2017
 */
public class HetSamsaLegacyMode extends HetSamsaManager {

	/**
	 * Constructor
	 */
	public HetSamsaLegacyMode(HetSamsaFileLoader samsaFileLoader, int radiationCalculationTimeStep, HetScene scene,
			double treeMaxHeight, double maxCrownRadius, HetMeteorology meteo, TreeSet<Integer> thinningDates, int dateOfInitialScene, SLModel slModel) throws Exception { //fa-05.01.2018: added thinningDates & dateOfInitialScene

		// fc+fa+mj-27.7.2017 added meteorology to manage legacyWithMeteoFile option

		// Super constructor creates slModel and slSettings
		super(samsaFileLoader, radiationCalculationTimeStep, slModel);

		// fc+mj+fa-27.7.2017
		overwriteIrradiationRecords (scene, meteo, thinningDates, dateOfInitialScene); //fa-05.01.2018: added thinningDates & dateOfInitialScene

		// Create the legacy beamSet
		slModel.init2_createLegacyBeamSet();

		// Init neighbourhoods system
		double cellWidth = ((HetPlot) scene.getPlot()).getCellWidth();

		slModel.computeRelativeCellNeighbourhoods(scene, treeMaxHeight, cellWidth, maxCrownRadius);

	}

	private void overwriteIrradiationRecords (HetScene scene, HetMeteorology meteo, TreeSet<Integer> thinningDates, int dateOfInitialScene) throws Exception { //fa-05.01.2018: added trueThinningMap & dateOfInitialScene
		if (meteo == null)
			return;

		// fc+fa-27.4.2017 BeamSet creation in legacy mode
		// Create beamSet, valid for 3 years (if radiationCalculationTimeStep =
		// 3)
		// int startYear = scene.getDate();
		int startYear = scene.getDate() + 1; // fa-7.7.2017: +1 as processLighting occurs at the end of evolution loop, therefore for next year(s)
		int endYear = startYear + radiationCalculationTimeStep - 1; // default
		//fa-05.01.2018: the current date is not a multiple of radiationCalculationTimeStep (because true thinning or intervention occurred)
		if ((scene.getDate() - dateOfInitialScene) % radiationCalculationTimeStep != 0d) {
			double ellapsedTimeStepFraction = (double) (scene.getDate() - dateOfInitialScene) / radiationCalculationTimeStep - Math.floor((scene.getDate() - dateOfInitialScene) / radiationCalculationTimeStep);
			double remainingTimeStepFraction = 1.0 - ellapsedTimeStepFraction;
			endYear = (int) (startYear + remainingTimeStepFraction * radiationCalculationTimeStep - 1);
		}
		//fa-05.01.2018: if true thinning WILL occur within the current radiationCalculationTimeStep
		if (thinningDates != null && thinningDates.ceiling(startYear) != null && thinningDates.ceiling(startYear) <= endYear) {
			endYear = thinningDates.ceiling(startYear);
		}

//		System.out.println("HetSamsaLegacyMode, overwriting SamsaraLight irradiation records from "+startYear+" to "+endYear+"...");

		HetAverageRadiation averageRadiation = new HetAverageRadiation(startYear, endYear, meteo);

		Map<HetAverageRadiation.Key,HetAverageRadiationLine> map = averageRadiation.getRadiationMap();

		List<SLHourlyRecord> newRecords = new ArrayList<> ();

		int traceNb = 0;

		for (HetAverageRadiationLine line : map.values()) {
			SLHourlyRecord r = new SLHourlyRecord();

			// We need here a non bissextile year, with 365 days only
			GregorianCalendar cal = HetMeteorology.getGregorianCalendar(2017, line.doy);
			int day = cal.get(Calendar.DAY_OF_MONTH);

			r.month = line.month;
			r.day = day;
			r.hour = line.hour;
			r.global = line.globalRadiation_MJm2;
			r.diffuseToGlobalRatio = line.diffuseToGlobalRatio;

//			if (traceNb++ <= 1000)
//				System.out.println("HetSamsaLegacyMode "+r.toString ());

			newRecords.add(r);
		}

		slSettings.setHourlyRecords(newRecords);


	}

	// processLighting() is in HetSamsaManager superclass

}
