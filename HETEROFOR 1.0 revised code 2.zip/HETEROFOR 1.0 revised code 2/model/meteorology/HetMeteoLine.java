/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */
package heterofor.model.meteorology;

import java.io.Serializable;

import jeeb.lib.util.Record;

/**
 * A Meteorology line.
 *
 * @author M. Jonard, L. de Wergifosse, F. de Coligny - September 2016
 */
public class HetMeteoLine extends Record implements Serializable {

	public int year;
	public int month;
	public int day;
	public int hour;//GMT+1
	public double radiation; // (W/m2)
	public double airTemperature; // (Celsius)
	public double soilSurfaceTemperature; // (Celsius)
	public double rainfall; // (l/m2 or mm)
	public double relativeHumidity; // (% or hPa / 100 hPa)
	public double windSpeed; // (m/s)
	public double windDirection; // (degrees)
	public double diffuseToGlobalRatio; // [0, 1] // fc+fa-27.4.2017

	/**
	 * Constructor
	 */
	public HetMeteoLine() {
		super();
	}

	/**
	 * Copy constructor
	 */
	public HetMeteoLine(HetMeteoLine meteoLine) {

		year = meteoLine.year;
		month = meteoLine.month;
		day = meteoLine.day;
		hour = meteoLine.hour;
		radiation = meteoLine.radiation;
		airTemperature = meteoLine.airTemperature;
		soilSurfaceTemperature = meteoLine.soilSurfaceTemperature;
		rainfall = meteoLine.rainfall;
		relativeHumidity = meteoLine.relativeHumidity;
		windSpeed = meteoLine.windSpeed;
		windDirection = meteoLine.windDirection;
		diffuseToGlobalRatio = meteoLine.diffuseToGlobalRatio;
	}

	public HetMeteoLine(String line) throws Exception {
		super(line);
	}

	public int getDoy () {
		int doy = HetMeteorology.doy(year, month, day);
		return doy;
	}

}
