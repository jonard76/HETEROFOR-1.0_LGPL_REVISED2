 /*
  * The HETEROFOR model.
  *
  * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
  *
  * This file is part of the HETEROFOR model and is free software: you can redistribute it and/or
  * modifiy it under the terms of the GNU Lesser General Public License as published by the
  * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */
package heterofor.model.allometry;

import heterofor.model.HetPlot;
import heterofor.model.HetScene;
import heterofor.model.HetTree;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.Random;
import java.util.StringTokenizer;

import jeeb.lib.util.Check;
import capsis.defaulttype.plotofcells.RoundMask;

/**
 * A function for tree height growth, accepts param values for IPRFW and Baileux
 * (...) versions.
 *
 * @author M. Jonard, F. de Coligny - April 2015
 */
public class HeightGrowthFunction implements Serializable {
	public double a;
	public double b;
	public double c;
	public double d;
	public double e;
	public double f;
	public double g;
	public double h;
	public double i;
	public double residual; // standard deviation

	/**
	 * Constructor.
	 */
	public HeightGrowthFunction(String str) throws Exception { // e.g.
																// HeightGrowthFunction(0.112299;0.002982;0;-0.016800;0;0;0.656141;-0.449509;0.070420;0.139559)
		if (!str.startsWith("HeightGrowthFunction(")) {
			throw new Exception("HeightGrowthFunction error, string should start with \"HeightGrowthFunction(\": "
					+ str);
		}
		String s = str.replace("HeightGrowthFunction(", "");
		s = s.replace(')', ' ');
		s = s.trim();
		StringTokenizer st = new StringTokenizer(s, " ;");
		a = Check.doubleValue(st.nextToken());
		b = Check.doubleValue(st.nextToken());
		c = Check.doubleValue(st.nextToken());
		d = Check.doubleValue(st.nextToken());
		e = Check.doubleValue(st.nextToken());
		f = Check.doubleValue(st.nextToken());
		g = Check.doubleValue(st.nextToken());
		h = Check.doubleValue(st.nextToken());
		i = Check.doubleValue(st.nextToken());
		residual = Check.doubleValue(st.nextToken());

	}

	/**
	 * Calculates the function for the given value of light competition index.
	 */
	public double result(HetTree tree, HetScene scene, double deltaDbh2Height, double lightCompetitionIndex,
			Random random) {

		double dbh_cm = tree.getDbh();
		double dbh_m = dbh_cm / 100d;
		// double c130 = dbh_cm * Math.PI; // cm
		// double lnC130 = Math.log(c130);
		double height = tree.getHeight(); // m

		Collection neighbours = new ArrayList();
		// HetScene scene = (HetScene) getScene ();
		HetPlot plot = (HetPlot) scene.getPlot();

		RoundMask m18 = new RoundMask(plot, 18, false);
		Collection n18 = new ArrayList(m18.getTreesNear(tree));
		for (Iterator i1 = n18.iterator(); i1.hasNext();) {
			HetTree t = (HetTree) i1.next();
			if (t.getGirth() < 120)
				i1.remove();
		}
		neighbours.addAll(n18);

		RoundMask m9 = new RoundMask(plot, 9, false);
		Collection n9 = new ArrayList(m9.getTreesNear(tree));
		for (Iterator i1 = n9.iterator(); i1.hasNext();) {
			HetTree t = (HetTree) i1.next();
			if (t.getGirth() < 70)
				i1.remove();
		}
		neighbours.addAll(n9);

		RoundMask m4 = new RoundMask(plot, 4.5, false);
		Collection n4 = new ArrayList(m4.getTreesNear(tree));
		for (Iterator i1 = n4.iterator(); i1.hasNext();) {
			HetTree t = (HetTree) i1.next();
			if (t.getGirth() < 20)
				i1.remove();
		}
		neighbours.addAll(n4);

		double localMeanHeight = 0;
		if (!neighbours.isEmpty()) {
			for (Object o : neighbours) {
				HetTree t = (HetTree) o;
				localMeanHeight += t.getHeight();
			}
			int n = neighbours.size();
			localMeanHeight /= n;
		} else {
			localMeanHeight = height / 1.5d;
		}

		// Residual standard deviation
		double error = random.nextGaussian() * residual;

		double k = deltaDbh2Height / (dbh_m * dbh_m);

		k = Math.min(k,2);

//		double deltaHeight = a + b * height + c * height * height + d * lightCompetitionIndex + e * k + f * k * k ; //fa-31.01.2019
		double deltaHeight = a + b * dbh_cm + c * dbh_cm * dbh_cm + d * height + e * height / localMeanHeight + f
			* lightCompetitionIndex + g * k + h * k * k + i * k * k * k + error;
//		double deltaHeight = a + b * height + c * dbh_cm + d * dbh_cm * dbh_cm + e * lightCompetitionIndex;
//		double deltaHeight = a + b * Math.log(height) + c * lightCompetitionIndex + d * k + e * k * k;

//		double deltaHeight = a + b * height + c * height * height + d*k + e*k*k + f* lightCompetitionIndex;

		// fc+mj-30.4.2015 deltaHeight was bounded, to be adapted later with
		// species specific parameters

		if (deltaHeight > k) {
			deltaHeight = k;
		}

//		if (deltaHeight < -0.4) {
//			deltaHeight = -0.4;
//		}
		//mj+fa-06.06.2019
		if (deltaHeight < 0d) {
			deltaHeight = 0d;
		}
		if (deltaHeight > 0.8) {
			deltaHeight = 0.8;
		}

		// double deltaHeight = 0.08 - 0.05 * height - 0.26 *
		// lightCompetitionIndex
		// + 0.46 * k + (k - 0.56) * (k - 0.56) * -0.18 ;

		return deltaHeight;

	}

	public String toString() {
		return "HeightGrowthFunction(" + a + ";" + b + ";" + c + ";" + d + ";" + e + ";" + f + ";" + g + ";" + h + ";"
				+ i + ";" + residual + ")";
	}

}
