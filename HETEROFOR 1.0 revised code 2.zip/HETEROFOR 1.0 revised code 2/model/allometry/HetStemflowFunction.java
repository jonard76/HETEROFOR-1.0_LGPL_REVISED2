/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.model.allometry;

import java.util.StringTokenizer;

import jeeb.lib.util.Check;

/**
 * A function computing the fraction of small branch biomass based on total
 * branch biomass.
 *
 * @author M. Jonard, L. de Wergifosse, F. de Coligny - September 2016
 */
public class HetStemflowFunction extends HetFunction2Variables {

	private double c;
	private double d;

	public HetStemflowFunction(String str) throws Exception { // e.g.
		// leaflessStemflow(-9.08;0.16)

		// fc+mj+lw-17.10.2016 added leavedStemflow
		if (!str.startsWith("leaflessStemflow(")
				&& !str.startsWith("leavedStemflow(")) {
			throw new Exception(
					"HetStemflowFunction error, string should start with \"leaflessStemflow(\" OR \"leavedStemflow(\": " + str);
		}
		String s = null;
		if (str.startsWith("leaflessStemflow(")) {
			s = str.replace("leaflessStemflow(", "");
		} else {
			s = str.replace("leavedStemflow(", "");
		}
		s = s.replace(')', ' ');
		s = s.trim();
		StringTokenizer st = new StringTokenizer(s, " ;");
		c = Check.doubleValue(st.nextToken());
		d = Check.doubleValue(st.nextToken());

	}

	/**
	 * c130 (cm), rainfall (mm)
	 */
	@Override
	public double result(double c130, double rainfall) {

		double y = c * rainfall + d * c130 * rainfall;

		y = Math.max(0,  y);

		return y;
	}

	public String toString() {
		return "leaflessStemflow(" + c + ";" + d + ")";
	}

}
