package heterofor.model.allometry;

import java.io.Serializable;
import java.util.StringTokenizer;

import jeeb.lib.util.Check;

/**
 * A function computing the soil water content modifier for stomatal conductance from soil pF
 * Return the soil water content modifier (-)
 * 
 * @author F. Andr� June 2019
 */
public class HetSwcModifier implements Serializable {

	public double a;
	public double b;

	/**
	 * Constructor.
	 */
	public HetSwcModifier(String str) throws Exception {

		// e.g. swcModifier(3,3)

		if (!str.startsWith("swcModifier(")) {
			throw new Exception(
					"HetSwcModifier error, string should start with \"swcModifier(\": "
							+ str);
		}
		String s = str.replace("swcModifier(", "");
		s = s.replace(')', ' ');
		s = s.trim();
		StringTokenizer st = new StringTokenizer(s, " ;");
		a = Check.doubleValue(st.nextToken());
		b = Check.doubleValue(st.nextToken());
		
	}

	/**
	 * Returns radiationModifier.
	 */
	public double result(double soilPF) {
		
		double swcModifier = 1d;
		
		if (soilPF > 2.5)
			swcModifier = Math.exp(-a * Math.pow(soilPF - 2.5, b));

		return swcModifier;

	}
	
	public String toString() {
		return "swcModifier(" + a + ";" + b + ")";
	}

} 
