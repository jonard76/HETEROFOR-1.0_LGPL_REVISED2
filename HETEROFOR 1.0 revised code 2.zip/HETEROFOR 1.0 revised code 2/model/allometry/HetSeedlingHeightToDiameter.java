package heterofor.model.allometry;

import java.util.StringTokenizer;

import jeeb.lib.util.Check;

/**
 * A function computing seedling diameter from height and transmittance
 * Return the diameter (cm)
 * 
 * @author M. Jonard, B. Ryelandt, F. de Coligny - October 2018
 */
public class HetSeedlingHeightToDiameter extends HetFunction2Variables {


	private double a;
	private double b;
	private double threshold; //threshold
	private double a2;
	private double b0;
	private double b1;
	private double c;

	/**
	 * Constructor.
	 */
	public HetSeedlingHeightToDiameter(String str) throws Exception {

		// e.g. seedlingHeightToDiameterRatio(80.1122;-7.80176;0)

		if (!str.startsWith("seedlingHeightToDiameter(")) {
			throw new Exception(
					"HetSeedlingHeightToDiameter error, string should start with \"seedlingHeightToDiameter(\": "
							+ str);
		}
		String s = str.replace("seedlingHeightToDiameter(", "");
		s = s.replace(')', ' ');
		s = s.trim();
		StringTokenizer st = new StringTokenizer(s, " ;");
		a = Check.doubleValue(st.nextToken());
		b = Check.doubleValue(st.nextToken());
		threshold = Check.doubleValue(st.nextToken());
		a2 = Check.doubleValue(st.nextToken());
		b0 = Check.doubleValue(st.nextToken());
		b1 = Check.doubleValue(st.nextToken());
		c = Check.doubleValue(st.nextToken());

	}

	/**
	 * Returns seedlingHeightToDiameterRatio.
	 */
	public double result(double transmittance, double height_m) {

		if (height_m < threshold){

			return a + b * height_m;		

		} else {

			return a2 + (b0 + b1 * transmittance) * (height_m - threshold) + c * (height_m - threshold) * (height_m - threshold);

		}

	}

	public String toString() {
		return "seedlingHeightToDiameter(" + a + ";" + b + ";" + threshold + ";" + a2 + ";" + b0 + ";" + b1 + ";" + c + ")";
	}

}
