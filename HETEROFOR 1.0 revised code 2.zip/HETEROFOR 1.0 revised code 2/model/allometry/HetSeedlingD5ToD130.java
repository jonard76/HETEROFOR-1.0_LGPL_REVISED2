package heterofor.model.allometry;

import java.util.StringTokenizer;

import jeeb.lib.util.Check;

/**
 * A function computing seedling d130 from d5
 * Return the dbh (cm)
 * 
 * @author B. Ryelandt - April 2019
 */
public class HetSeedlingD5ToD130 extends HetSimpleFunction {

	private double a;
	private double b;

	/**
	 * Constructor.
	 */
	public HetSeedlingD5ToD130(String str) throws Exception {

		// e.g. seedlingDiameterToHeight(80.1122;-7.80176;0)

		if (!str.startsWith("seedlingD5ToD130(")) {
			throw new Exception(
					"HetSeedlingD5ToD130 error, string should start with \"seedlingD5ToD130(\": "
							+ str);
		}
		String s = str.replace("seedlingD5ToD130(", "");
		s = s.replace(')', ' ');
		s = s.trim();
		StringTokenizer st = new StringTokenizer(s, " ;");
		a = Check.doubleValue(st.nextToken());
		b = Check.doubleValue(st.nextToken());

		if (b == 0)
			throw new Exception ("HetSeedlingD5ToD130 does not accept a zero value for b");
		
	}

	/**
	 * Returns seedlingHeightToDiameterRatio.
	 */
	public double result(double d5_cm) {

		return a + b * d5_cm;

	}

	/**
	 * Reverse function
	 */
	public double reverse (double d130_cm) {
		// b must be != 0
		return (d130_cm - a) / b;
	}
	
	
	public String toString() {
		return "seedlingDiameterToHeight(" + a + ";" + b + ")";
	}

} 
