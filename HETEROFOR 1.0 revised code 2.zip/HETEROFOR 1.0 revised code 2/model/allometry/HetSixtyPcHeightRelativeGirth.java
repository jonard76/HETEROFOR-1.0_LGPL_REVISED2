package heterofor.model.allometry;

import java.io.Serializable;
import java.util.StringTokenizer;

import jeeb.lib.util.Check;

/**
 * A function to compute the relative girth (to 10% height girth) at 60% of the tree
 * height. Dagnelie et al. 1999
 * 
 * @author M. Jonard - November 2017
 */
public class HetSixtyPcHeightRelativeGirth implements Serializable {

	public double a;
	public double b;
	public double c;

	/**
	 * Constructor.
	 */
	public HetSixtyPcHeightRelativeGirth(String str) throws Exception { // e.g.
																// sixtyPcHeightRelativeGirth(0.4838;14.667;-405.67)
		if (!str.startsWith("sixtyPcHeightRelativeGirth(")) {
			throw new Exception("sixtyPcHeightRelativeGirth error, string should start with \"sixtyPcHeightRelativeGirth(\": " + str);
		}
		String s = str.replace("sixtyPcHeightRelativeGirth(", "");
		s = s.replace(')', ' ');
		s = s.trim();
		StringTokenizer st = new StringTokenizer(s, " ;");
		a = Check.doubleValue(st.nextToken());
		b = Check.doubleValue(st.nextToken());
		c = Check.doubleValue(st.nextToken());

	}

	/**
	 * Calculates the function
	 */
	public double result(double tenPcHeightGirth) {

		double res = a + b / tenPcHeightGirth + c / (tenPcHeightGirth * tenPcHeightGirth);

		return res;
	}

	public String toString() {
		return "sixtyPcHeightRelativeGirth(" + a + ";" + b + ";" + c + ")";
	}

}
