/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.model.allometry;

import java.io.Serializable;
import java.util.StringTokenizer;

import jeeb.lib.util.Check;


/**
 * An allometry to calculate initial biomass for some tree compartments.
 *
 * @author M. Jonard - November 2013
 */
public class InitBiomassAllometry4p implements Serializable {

	public double a;
	public double b;
	public double c;
	public double d;

	/**
	 * Constructor.
	 */
	public InitBiomassAllometry4p (String str) throws Exception { // e.g. initBiomassAllometry4p(1.2;2.23;0.04;-1.25)
		if (!str.startsWith ("initBiomassAllometry4p(")) {
			throw new Exception ("InitBiomassAllometry4p error, string should start with \"initBiomassAllometry4p(\": "+str);
		}
		String s = str.replace ("initBiomassAllometry4p(", "");
		s= s.replace (')', ' ');
		s = s.trim ();
		StringTokenizer st = new StringTokenizer (s, " ;");
		a = Check.doubleValue (st.nextToken ());
		b = Check.doubleValue (st.nextToken ());
		c = Check.doubleValue (st.nextToken ());
		d = Check.doubleValue (st.nextToken ());

	}

	/**
	 * Calculates the allometry for the given values.
	 */
	public double result (double dbh_cm, double height, double mean2CrownRadius_m) {
		return a / 1000000d * Math.pow (dbh_cm,  b) * Math.pow (height, c) * Math.pow ((2 * mean2CrownRadius_m) / (dbh_cm / 100d), d);
	}

	public String toString() {
		return "initBiomassAllometry4p(" + a + ";" + b + ";" + c  + ";" + d + ")";
	}

}
