/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.model.allometry;

import java.util.StringTokenizer;

import jeeb.lib.util.Check;

/**
 * A function computing bark thickness.
 *
 * @author M. Jonard, L. de Wergifosse, F. de Coligny - October 2016
 */
public class HetBarkThicknessFunction extends HetSimpleFunction {

	private double a;
	private double b;
	private double c;
	private double d;

	/**
	 * Constructor.
	 */
	public HetBarkThicknessFunction(String str) throws Exception { // e.g.
																	// barkThicknessFunction(0.08;-0.26;0.32478;0.32478)
		if (!str.startsWith("barkThicknessFunction(")) {
			throw new Exception("HetBarkThicknessFunction error, string should start with \"barkThicknessFunction(\": "
					+ str);
		}
		String s = str.replace("barkThicknessFunction(", "");
		s = s.replace(')', ' ');
		s = s.trim();
		StringTokenizer st = new StringTokenizer(s, " ;");
		a = Check.doubleValue(st.nextToken());
		b = Check.doubleValue(st.nextToken());
		c = Check.doubleValue(st.nextToken());
		d = Check.doubleValue(st.nextToken());

	}

	/**
	 * The diameter: of the stem or of branch compartments.
	 */
	@Override
	public double result(double diameter) { // cm

		double girth = diameter * Math.PI;

		double thickness = a + b * girth + c * girth * girth + d * girth * girth * girth;

		thickness = Math.max(0.1, thickness); // at least 0.1 mm, to be reviewed

		return thickness;

	}

	public String toString() {
		return "barkThicknessFunction(" + a + ";" + b + ";" + c + ";" + d + ")";
	}

}
