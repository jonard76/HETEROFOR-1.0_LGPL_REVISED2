package heterofor.model.allometry;

import java.util.StringTokenizer;

import jeeb.lib.util.Check;

/**
 * A function computing seedling height to diameter ratio
 * 
 * @author M. Jonard, B. Ryelandt, F. de Coligny - October 2018
 */
public class HetSeedlingHeightToDiameterRatio extends HetFunction2Variables {

	private double a;
	private double b;
	private double c;

	/**
	 * Constructor.
	 */
	public HetSeedlingHeightToDiameterRatio(String str) throws Exception {

		// e.g. seedlingHeightToDiameterRatio(80.1122;-7.80176;0)

		if (!str.startsWith("seedlingHeightToDiameterRatio(")) {
			throw new Exception(
					"HetSeedlingHeightToDiameterRatio error, string should start with \"seedlingHeightToDiameterRatio(\": "
							+ str);
		}
		String s = str.replace("seedlingHeightToDiameterRatio(", "");
		s = s.replace(')', ' ');
		s = s.trim();
		StringTokenizer st = new StringTokenizer(s, " ;");
		a = Check.doubleValue(st.nextToken());
		b = Check.doubleValue(st.nextToken());
		c = Check.doubleValue(st.nextToken());

	}

	/**
	 * Returns seedlingHeightToDiameterRatio.
	 */
	public double result(double transmittance, double height_m) {

		return a + b * Math.log(transmittance) + c * height_m;

	}

	public String toString() {
		return "seedlingHeightToDiameterRatio(" + a + ";" + b + ";" + c + ")";
	}

}
