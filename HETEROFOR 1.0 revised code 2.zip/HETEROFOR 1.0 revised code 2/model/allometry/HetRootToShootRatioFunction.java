package heterofor.model.allometry;

import java.util.StringTokenizer;

import jeeb.lib.util.Check;

/**
 * A function computing seedling height to diameter ratio
 * 
 * @author B.Ryelandt - May 2019
 */
public class HetRootToShootRatioFunction extends HetSimpleFunction {

	private double a;
	private double b;
	private double c;

	/**
	 * Constructor.
	 */
	public HetRootToShootRatioFunction(String str) throws Exception {

		// e.g. rootToShootRatioFunction(80.1122;-7.80176;0)

		if (!str.startsWith("rootToShootRatioFunction(")) {
			throw new Exception(
					"HetRootToShootRatioFunction error, string should start with \"rootToShootRatioFunction(\": "
							+ str);
		}
		String s = str.replace("rootToShootRatioFunction(", "");
		s = s.replace(')', ' ');
		s = s.trim();
		StringTokenizer st = new StringTokenizer(s, " ;");
		a = Check.doubleValue(st.nextToken());
		b = Check.doubleValue(st.nextToken());
		c = Check.doubleValue(st.nextToken());

	}

	/**
	 * Returns rootToShootRatioFunction.
	 */
	public double result(double age) {

		return a + b * Math.exp(-c * age);

	}

	public String toString() {
		return "rootToShootRatioFunction(" + a + ";" + b + ";" + c + ")";
	}

} 
