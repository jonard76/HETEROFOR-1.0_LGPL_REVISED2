/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.model.allometry;

import java.io.Serializable;

/**
 * A superclass for f(x1, x2) functions.
 *
 * @author F. de Coligny - September 2016
 */
public abstract class HetFunction2Variables implements Serializable {

	/**
	 * A convenient method to decode a HetFunction2Variables
	 */
	static public HetFunction2Variables getFunction(String encodedFunction) throws Exception {
		if (encodedFunction.startsWith("leaflessStemflow")
				|| encodedFunction.startsWith("leavedStemflow")) { // fc+mj+lw-17.10.2016
			return new HetStemflowFunction(encodedFunction);

		} else if (encodedFunction.startsWith("seedlingHeightToDiameter")) {
			return new HetSeedlingHeightToDiameter(encodedFunction);

		} else if (encodedFunction.startsWith("seedlingDiameterToHeight")) {
			return new HetSeedlingDiameterToHeight(encodedFunction);
//
//		} else if (encodedFunction.startsWith("seedlingD5ToD130")) {
//			return new HetSeedlingD5toD130(encodedFunction);

		} else if (encodedFunction.startsWith("seedlingGetBiomass")) {
			return new HetSeedlingGetBiomass(encodedFunction);

		} else if (encodedFunction.startsWith("seedlingHeightGrowth")) {
			return new HetSeedlingHeightGrowth(encodedFunction);

		} else {
			throw new Exception("HetFunction2Variables, unknown function: " + encodedFunction);
		}

	}

	/**
	 * A f(x1, x2) method, returns y.
	 */
	public abstract double result(double x1, double x2);

}
