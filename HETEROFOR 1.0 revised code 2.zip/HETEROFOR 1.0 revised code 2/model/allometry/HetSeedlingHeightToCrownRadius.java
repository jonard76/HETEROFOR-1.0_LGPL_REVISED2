package heterofor.model.allometry;

import java.util.StringTokenizer;

import jeeb.lib.util.Check;

/**
 * A function computing seedling crown radius (m).
 * 
 * @author B. Ryelandt - May 2018
 */
public class HetSeedlingHeightToCrownRadius extends HetSimpleFunction {
	
	private double a;
	private double b;

	/**
	 * Constructor.
	 */
	public HetSeedlingHeightToCrownRadius(String str) throws Exception { 
		
		// e.g. seedlingHeightToCrownRadius(80.1122;-7.80176)
		
		if (!str.startsWith("seedlingHeightToCrownRadius(")) {
			throw new Exception("HetSeedlingHeightToCrownRadius error, string should start with \"seedlingHeightToCrownRadius(\": "
					+ str);
		}
		String s = str.replace("seedlingHeightToCrownRadius(", "");
		s = s.replace(')', ' ');
		s = s.trim();
		StringTokenizer st = new StringTokenizer(s, " ;");
		a = Check.doubleValue(st.nextToken());
		b = Check.doubleValue(st.nextToken());

	}
	
	
	
	/**
	 * Returns height increment, m.
	 */
	public double result(double height_m) {
		
		return (a + b * height_m)/2d;
		
	}
	
	
	
	

	public String toString() {
		return "seedlingHeightToCrownRadius(" + a + ";" + b + ")";
	}
	
	

} 
