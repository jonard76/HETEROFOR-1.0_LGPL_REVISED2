 /*
  * The HETEROFOR model.
  *
  * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
  *
  * This file is part of the HETEROFOR model and is free software: you can redistribute it and/or
  * modifiy it under the terms of the GNU Lesser General Public License as published by the
  * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.model.allometry;

import java.io.Serializable;
import java.util.StringTokenizer;

import jeeb.lib.util.Check;

/**
 * An estimation function for the par use efficency of a tree.
 *
 * @author F. de Coligny - December 2014
 */
public class ParUseEfficiencyFunction /* extends HetSimpleFunction */implements Serializable {
	public double a;
	public double b;
	public double c;
	public double d;
	public double e;
	public double f;

	/**
	 * Constructor.
	 */
	public ParUseEfficiencyFunction(String str) throws Exception { // e.g.
																	// ParUseEfficiencyFunction()
		if (!str.startsWith("ParUseEfficiencyFunction(")) {
			throw new Exception(
					"ParUseEfficiencyFunction error, string should start with \"ParUseEfficiencyFunction(\": " + str);
		}
		String s = str.replace("ParUseEfficiencyFunction(", "");
		s = s.replace(')', ' ');
		s = s.trim();
		StringTokenizer st = new StringTokenizer(s, " ;");
		a = Check.doubleValue(st.nextToken());
		b = Check.doubleValue(st.nextToken());
		c = Check.doubleValue(st.nextToken());
		d = Check.doubleValue(st.nextToken());
		e = Check.doubleValue(st.nextToken());
		f = Check.doubleValue(st.nextToken());

	}

	/**
	 * Calculates the function for the given value of light competition index.
	 */
	// public double result (double lightCompetitionIndex) {

	// double res = a * Math.pow(lightCompetitionIndex, b);

	// return res;
	// }

	// public double result(double lightCompetitionIndex) {

	// double res = a + b * Math.pow(lightCompetitionIndex, -1) + c *
	// lightCompetitionIndex;

	// return res;

	// public double result(double lightCompetitionIndex) {

	// double res = a + b * Math.exp(c*Math.pow(lightCompetitionIndex,d))+
	// e*lightCompetitionIndex;

	// return res;// Added by Mj (26/04/2016)

	// public double result(double lightCompetitionIndex, double
	// interceptedParRadiation, double dbh) {
	//
	// double res = 1/(a + b * lightCompetitionIndex + c *
	// Math.log(lightCompetitionIndex));
	//
	// return res;// Added by Mj (03/05/2016)
	//
	// }


	// fc+mj-13.9.2017
	public double result(double lightCompetitionIndex, double interceptedParRadiation, double dbh) {

//		double res = 1 / (a + b * lightCompetitionIndex + c * Math.log(lightCompetitionIndex) + d * dbh + e
//				* interceptedParRadiation + f * interceptedParRadiation * dbh);
		double res = a + b / lightCompetitionIndex ; //mj+fa-13.12.2018

		if (res < 0.00006) {
//			System.out.println("ParUseEfficiencyFunction res: "+res+" was bounded to LOW value: 0.00006");
			res = 0.00006;
		}

		if (res > 0.004) {
//			System.out.println("ParUseEfficiencyFunction res: "+res+" was bounded to HIGH value: 0.004");
			res = 0.004;
		}

		return res;

	}




/** fc+mj-13.9.2017 REMOVED, restored the version of revision 10456 (see upper)

//		public double result(double lightCompetitionIndex, double interceptedParRadiation, double dbh) {
	public double result(double sunlitLeaf, double shadedLeaf) { //mj+fa-21.6.2017
//
//		double res = 1 / (a + b * lightCompetitionIndex + c * Math.log(lightCompetitionIndex) + d * dbh + e
//		* interceptedParRadiation + f * interceptedParRadiation * dbh);

		double res = (sunlitLeaf * a + shadedLeaf * b) / (sunlitLeaf + shadedLeaf); //mj+fa-21.6.2017
		if (res < 0.00006) {
//			System.out.println("ParUseEfficiencyFunction res: "+res+" was bounded to LOW value: 0.00006");
			res = 0.00006;
		}

		if (res > 0.004) {
//			System.out.println("ParUseEfficiencyFunction res: "+res+" was bounded to HIGH value: 0.004");
			res = 0.004;
		}

		return res;

	}

*/

	public String toString() {
		return "ParUseEfficiencyFunction(" + a + ";" + b + ";" + c + ";" + d + ";" + e + ";" + f + ")";
	}

}
