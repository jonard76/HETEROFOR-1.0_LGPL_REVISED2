/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.model;

import java.awt.Color;
import java.io.Serializable;
import java.util.Map;

import capsis.lib.regeneration.RGSpecies;
import capsis.util.EnumProperty;
import heterofor.model.allometry.CrownToStemDiameterEstimation;
import heterofor.model.allometry.HeightGrowthFunction;
import heterofor.model.allometry.HetFunction2Variables;
import heterofor.model.allometry.HetSapwoodArea;
import heterofor.model.allometry.HetSimpleFunction;
import heterofor.model.allometry.HetSixtyPcHeightRelativeGirth;
import heterofor.model.allometry.HetTenPcHeightGirth;
import heterofor.model.allometry.HetTreeHeightLigot;
import heterofor.model.allometry.InitBiomassAllometry4p;
import heterofor.model.allometry.LeafBiomassAllometry;
import heterofor.model.allometry.ParUseEfficiencyFunction;
import heterofor.model.allometry.PotentialModifiersHeightGrowth;
import heterofor.model.allometry.HetRadiationModifier;
import heterofor.model.allometry.HetVpdModifier;
import heterofor.model.allometry.HetSwcModifier;
import heterofor.model.treechemistry.HetNutrientGrowthSensitivity;
import heterofor.model.treechemistry.HetTreeCompartment;
import heterofor.model.treechemistry.HetTreeElement;

/**
 * A species in the heterofor model.
 *
 * @author M. Jonard, F. Herman - January 2012
 */
public class HetSpecies extends EnumProperty implements RGSpecies, Serializable {

	public static final String SPECIES_PROPERTY_NAME = "HetSpecies.species";

	// LADoption possible values
	public static final int MEAN_LAD = 0;
	public static final int MEAN_SLA = 1;
	public static final int SLA_MODEL = 2;
	public static final int QUERGUS_LAD = 3;

	// Toption possible values
	public static final int MEAN_T = 0;
	public static final int QUERGUS_T = 1;

	// Variables from species file.

	// fc+nb-9.6.2017 value is in superclass
	// private int value;

	public String name; // do not change, known by Heterofor
	public String niceName; // for graphs...
	public boolean isConiferous; // fa-06.01.2020
	public double maxHeight; // m
	public double maxCrownRadius; // m
	public Color color;
	public String crownForm;

	// fc+mj-30.4.2015
	public int LADoption; // MEAN_LAD, MEAN_SLA, SLA_MODEL or QUERGUS_LAD
	public int Toption; // MEAN_T, QUERGUS_T

	public double LAD; // (m2/m3)
	public double LADup; // (m2/m3)
	public double LADdown; // (m2/m3)

	public double SLAtop; // (m2/kg of GREEN leaves)
	public double SLAbottom; // (m2/kg of GREEN leaves)

	public double UFLB; // ]0,1]

	public double extinctionCoefficient; // for turbid medium model
	public double crownTransmissivity; // for porous envelop model

	// Default values for Quercus, temporary, will be read in inventory file
	
	public double meanLeafWidth = 0.04; // fa-16.12.2019

	public InitBiomassAllometry4p initBranchBiomassAllometry;
	public InitBiomassAllometry4p initStemBiomassAllometry;
	public LeafBiomassAllometry leafBiomassAllometry;
	public CrownToStemDiameterEstimation crownToStemDiameterEstimation;

	public double leafRelativeLossRate = 1;
	public double leafRetranslocationRate = 0.40; // kg / tree : proportion of
													// carbon retranslocated
													// from green leaves

	public double branchRelativeLossRate = 0.03;
	public double branchLivingFraction = 1;

	public double stemFormFactor = 0.52; // based on a Delevoy height
	public double stemVolumetricMass = 559.74; // kg/m3

	public double rootRelativeLossRate = 0.03;
	public double rootToShootRatio = 0.24;
	public double rootLivingFraction = 1;

	public double fineRootRelativeLossRate = 1; // kgC/kgC
	public double fineRootRetranslocationRate = 0.40; // kg / tree : proportion
														// of carbon
														// retranslocated from
														// living fine roots

	public double defaultDeltaDbh = 0.32; // cm/year
	public double parUseEfficiency = 0.000513; // kgC/mol, Makela et al. 2008

	// public double specificRespirationRate = 0.04; // kgC/kgC/(mg N / g),
	// roughly approximated, Rasse et al. 2001 ; Grote & Pretzsch, 2002

	public int sapwoodYearNumber = 20;
	public double sapwoodToLeafAreaRatio; // fc+mj+lw-19.10.2016
	public HetSimpleFunction sapwoodArea; // fc+mj+lw-19.10.2016

	public double aboveBiomassAlpha = 0;
	public double aboveBiomassBeta = 263.4;
	public double aboveBiomassGamma = 0.969;

	public HetTreeHeightLigot treeHeight; // fc+mj+br-2.10.2018

	public double hlceHeightProportion = 0.81;
	public double hcbHeightProportion = 0.7;

	public double defoliationThreshold = 0.9;

	public double deltaHlceMax = 0.5;
	public double deltaHlceMin = -0.5;
	// Ratio between the sum of the crown radius and the distance between pairs
	// of trees
	public double crownOverlappingRatio = 1;
	public double crownToStemDiameterShift = 1.2;

	// Added this function, request by M. Jonard, 18.12.2014, see
	// HetTree.processGrowth ()
	public ParUseEfficiencyFunction parUseEfficiencyFunction; // fc-18.12.2014

	public double sunlitPUE; // fc+mj-13.9.2017
	public double shadedPUE; // fc+mj-13.9.2017

	// fc+mj-29.4.2015
	public HeightGrowthFunction iprfwHeightGrowthFunction;
	public HeightGrowthFunction baileuxHeightGrowthFunction;
	// fc+mj-6.12.2016
	public PotentialModifiersHeightGrowth potentialModifiersHeightGrowth;

	// fc+mj-2.3.2016
	public HetSimpleFunction smallBranchFracFunction;
	public HetSimpleFunction coarseBranchFracFunction;
	public HetSimpleFunction smallRootFracFunction;
	public HetSimpleFunction coarseRootFracFunction;
	public double maxFineRootToFoliageRatio;
	public double minFineRootToFoliageRatio;
	public double minSRL; // m/g
	public double maxSRL; // m/g
	public double rootVolumetricMass; // kg/m3
	public double hyphaToRootLengthRatio;
	public double specificHyphaLength; // km/g
	public double hyphaDiameter; // micro m

	public HetNutrientGrowthSensitivity nutrientGrowthSensitivity;

	// fc+mj+lw-8.9.2016 Additional params for water content process
	public double leaflessRainfallThreshold; // (mm)
	public HetFunction2Variables leaflessStemflowFunction;
	public double leavedRainfallThreshold; // (mm) // fc+mj+lw-17.10.2016
	public HetFunction2Variables leavedStemflowFunction; // fc+mj+lw-17.10.2016
	public double foliageStorageCapacity_m2leaf; // (l/leaf m2)

	public HetSimpleFunction barkProportionFunction; // fc+mj+lw-18.10.2016
	public HetSimpleFunction barkThicknessFunction; // fc+mj+lw-18.10.2016
	public double barkBulkDensity; // fc+mj+lw-18.10.2016

	public double minBarkConductance; // m/s
	public double maxBarkConductance; // m/s

	public double referenceMaintenanceRespiration; // TODO: unit
	public double nppToGppRatio_intercept; // TODO: unit //fa-29.10.2018
	public double nppToGppRatio_slope; // TODO: unit //fa-29.10.2018
	public double basicCanopyStomatalConductance; // m/s
	public HetRadiationModifier radiationModifier; // fa+mj-17.06.2019
	public HetVpdModifier vpdModifier; // fa+mj-17.06.2019
	public HetSwcModifier swcModifier; // fa+mj-17.06.2019

	public HetTenPcHeightGirth tenPcHeightGirth;
	public HetSixtyPcHeightRelativeGirth sixtyPcHeightRelativeGirth;

	public double transpirationModifierCorrection;

	public double branchLitterP1;
	public double branchLitterP2;
	public double fruitLitterFallP1;
	public double fruitLitterFallP2;
	public double fruitProdMinDbh; // cm

	// Other variables

	public HetModel model;

	// [0,1] mj+nb-15.09.2017
	// Initialized to 0 and then calculated in
	// HetWaterBalanceCalculator.updateWaterBalance()
	public double meanLightCompetitionIndex = 0.5;
//	public double leafArea_sp = 0; // m2 //fa+mj-04.12.2017 // fa-17.12.2019: commented, moved to HetScene
	public Map<Integer, Double> optimizedFruitLitterFallP1Map_mainSp; // fa-05.12.2017
	public Map<Integer, Double[]> standFruitLitterFallComparisonMap_mainSp; // fa-05.12.2017
	
	// fc+mj+fa-12.11.2019 unused
//	public double meanHcb = 0; // mj+fa-23.10.2017
//	public double nTrees = 0; // mj+fa-23.10.2017

	// fc+mj+nd+br-2.10.2018
	private double heightToTree;

	// fc+mj+br-3.10.2018
	public HetFunction2Variables seedlingHeightGrowth;
	public HetFunction2Variables seedlingHeightToDiameter;
	public HetFunction2Variables seedlingDiameterToHeight;
	public HetSimpleFunction seedlingD5ToD130;
	public HetFunction2Variables seedlingGetBiomass;
	public HetSimpleFunction seedlingHeightToLAI;
	public HetSimpleFunction seedlingTransmittanceToSLA;
	public HetSimpleFunction rootToShootRatioFunction;
	public HetSimpleFunction seedlingHeightToCrownRadius;

	// fc+mj+br-4.10.2018 Not available at constructor time, must be set at
	// trees loading time
	private HetTreeCompartment initialLeavesUpperCurrentCompartment;

	/**
	 * Constructor
	 */
	public HetSpecies(HetSpecies speciesSpecimen, HetModel model, int id, String name, String niceName, boolean isConiferous,
			double maxHeight, double maxCrownRadius, Color color, String crownForm, int LADoption, int Toption,
			double LAD, double LADup, double LADdown, double SLAtop, double SLAbottom, double UFLB,
			double extinctionCoefficient, double crownTransmissivity, double meanLeafWidth, InitBiomassAllometry4p initBranchBiomassAllometry,
			InitBiomassAllometry4p initStemBiomassAllometry, LeafBiomassAllometry leafBiomassAllometry,
			CrownToStemDiameterEstimation crownToStemDiameterEstimation, double leafRelativeLossRate,
			double leafRetranslocationRate, double branchRelativeLossRate, double branchLivingFraction,
			double stemFormFactor, double stemVolumetricMass, double rootRelativeLossRate, double rootToShootRatio,
			double rootLivingFraction, double fineRootRelativeLossRate, double fineRootRetranslocationRate,
			double defaultDeltaDbh, double parUseEfficiency, int sapwoodYearNumber, double sapwoodToLeafAreaRatio,
			HetSapwoodArea sapwoodArea, double aboveBiomassAlpha, double aboveBiomassBeta, double aboveBiomassGamma,
			HetTreeHeightLigot treeHeight, double hlceHeightProportion, double hcbHeightProportion,
			double defoliationThreshold, double deltaHlceMax, double deltaHlceMin, double crownOverlappingRatio,
			double crownToStemDiameterShift, ParUseEfficiencyFunction parUseEfficiencyFunction, double sunlitPUE,
			double shadedPUE, HeightGrowthFunction iprfwHeightGrowthFunction,
			HeightGrowthFunction baileuxHeightGrowthFunction,
			PotentialModifiersHeightGrowth potentialModifiersHeightGrowth, HetSimpleFunction smallBranchFracFunction,
			HetSimpleFunction coarseBranchFracFunction, HetSimpleFunction smallRootFracFunction,
			HetSimpleFunction coarseRootFracFunction, double maxFineRootToFoliageRatio,
			double minFineRootToFoliageRatio, double minSRL, double maxSRL, double rootVolumetricMass,
			double hyphaToRootLengthRatio, double specificHyphaLength, double hyphaDiameter,
			HetNutrientGrowthSensitivity nutrientGrowthSensitivity, double leaflessRainfallThreshold,
			HetFunction2Variables leaflessStemflowFunction, double leavedRainfallThreshold,
			HetFunction2Variables leavedStemflowFunction, double foliageStorageCapacity_m2leaf,
			HetSimpleFunction barkProportionFunction, HetSimpleFunction barkThicknessFunction, double barkBulkDensity,
			double minBarkConductance, double maxBarkConductance, double referenceMaintenanceRespiration,
			double nppToGppRatio_intercept, double nppToGppRatio_slope, double basicCanopyStomatalConductance,
			HetRadiationModifier radiationModifier, HetVpdModifier vpdModifier, HetSwcModifier swcModifier,
			HetTenPcHeightGirth tenPcHeightGirth, HetSixtyPcHeightRelativeGirth sixtyPcHeightRelativeGirth,
			double transpirationModifierCorrection, double branchLitterP1, double branchLitterP2,
			double fruitLitterFallP1, double fruitLitterFallP2, double fruitProdMinDbh, double heightToTree,
			HetFunction2Variables seedlingHeightGrowth, HetFunction2Variables seedlingHeightToDiameter,
			HetFunction2Variables seedlingDiameterToHeight, HetSimpleFunction seedlingD5ToD130,
			HetFunction2Variables seedlingGetBiomass, HetSimpleFunction seedlingHeightToLAI,
			HetSimpleFunction seedlingTransmittanceToSLA, HetSimpleFunction rootToShootRatioFunction,
			HetSimpleFunction seedlingHeightToCrownRadius) {

		// speciesSpecimen is for Species chaining (Enum property, automatic
		// groups)
		super(id, name, speciesSpecimen, SPECIES_PROPERTY_NAME);

		this.model = model;
		// this.value = value;

		this.name = name;
		this.niceName = niceName;
		// this.trunkFormFactor = trunkFormFactor;
		this.isConiferous = isConiferous; // fa-06.01.2020 
		this.maxHeight = maxHeight;
		this.maxCrownRadius = maxCrownRadius;
		this.color = color;
		this.crownForm = crownForm;
		this.LADoption = LADoption;
		this.Toption = Toption;
		this.LAD = LAD;
		this.LADup = LADup;
		this.LADdown = LADdown;
		// this.SLAup = SLAup;
		// this.SLAdown = SLAdown;
		this.SLAtop = SLAtop;
		this.SLAbottom = SLAbottom;
		// this.SLAintercept = SLAintercept;
		this.UFLB = UFLB;
		this.extinctionCoefficient = extinctionCoefficient;
		this.crownTransmissivity = crownTransmissivity;
		this.meanLeafWidth = meanLeafWidth; // fa-16.12.2019
		this.initBranchBiomassAllometry = initBranchBiomassAllometry;
		this.initStemBiomassAllometry = initStemBiomassAllometry;
		this.leafBiomassAllometry = leafBiomassAllometry;
		this.crownToStemDiameterEstimation = crownToStemDiameterEstimation;
		// this.leafNConcentration = leafNConcentration;
		this.leafRelativeLossRate = leafRelativeLossRate;
		this.leafRetranslocationRate = leafRetranslocationRate;
		// this.leafCarbonConcentration = leafCarbonConcentration;
		// this.branchNConcentration = branchNConcentration;
		this.branchRelativeLossRate = branchRelativeLossRate;
		this.branchLivingFraction = branchLivingFraction;
		// this.stemNConcentration = stemNConcentration;
		this.stemFormFactor = stemFormFactor;
		this.stemVolumetricMass = stemVolumetricMass;
		// this.stemGirthTaperA = stemGirthTaperA;
		// this.rootNConcentration = rootNConcentration;
		this.rootRelativeLossRate = rootRelativeLossRate;
		this.rootToShootRatio = rootToShootRatio;
		this.rootLivingFraction = rootLivingFraction;
		// this.fineRootNConcentration = fineRootNConcentration;
		this.fineRootRelativeLossRate = fineRootRelativeLossRate;
		this.fineRootRetranslocationRate = fineRootRetranslocationRate;
		this.defaultDeltaDbh = defaultDeltaDbh;
		this.parUseEfficiency = parUseEfficiency;
		// this.specificRespirationRate = specificRespirationRate;
		this.sapwoodYearNumber = sapwoodYearNumber;
		this.sapwoodToLeafAreaRatio = sapwoodToLeafAreaRatio;
		this.sapwoodArea = sapwoodArea;
		this.aboveBiomassAlpha = aboveBiomassAlpha;
		this.aboveBiomassBeta = aboveBiomassBeta;
		this.aboveBiomassGamma = aboveBiomassGamma;
		this.treeHeight = treeHeight;
		// this.heightA = heightA;
		// this.heightB = heightB;
		// this.heightC = heightC;
		// this.heightD = heightD;
		this.hlceHeightProportion = hlceHeightProportion;
		this.hcbHeightProportion = hcbHeightProportion;
		this.defoliationThreshold = defoliationThreshold;
		// this.hlcePotA = hlcePotA;
		// this.hlcePotB = hlcePotB;
		// this.rPotA = rPotA;
		// this.rPotB = rPotB;
		this.deltaHlceMax = deltaHlceMax;
		this.deltaHlceMin = deltaHlceMin;
		this.crownOverlappingRatio = crownOverlappingRatio;
		this.crownToStemDiameterShift = crownToStemDiameterShift;
		// this.hcbA = hcbA;
		// this.hcbB = hcbB;

		// fc-18.12.2014
		this.parUseEfficiencyFunction = parUseEfficiencyFunction;
		this.sunlitPUE = sunlitPUE;
		this.shadedPUE = shadedPUE;

		// fc+mj-29.4.2015
		this.iprfwHeightGrowthFunction = iprfwHeightGrowthFunction;
		this.baileuxHeightGrowthFunction = baileuxHeightGrowthFunction;
		this.potentialModifiersHeightGrowth = potentialModifiersHeightGrowth;

		// fc+mj-2.3.2016
		this.smallBranchFracFunction = smallBranchFracFunction;
		this.coarseBranchFracFunction = coarseBranchFracFunction;
		this.smallRootFracFunction = smallRootFracFunction;
		this.coarseRootFracFunction = coarseRootFracFunction;
		this.maxFineRootToFoliageRatio = maxFineRootToFoliageRatio;
		this.minFineRootToFoliageRatio = minFineRootToFoliageRatio;
		this.minSRL = minSRL;
		this.maxSRL = maxSRL;
		this.rootVolumetricMass = rootVolumetricMass;
		this.hyphaToRootLengthRatio = hyphaToRootLengthRatio;
		this.specificHyphaLength = specificHyphaLength;
		this.hyphaDiameter = hyphaDiameter;

		this.nutrientGrowthSensitivity = nutrientGrowthSensitivity;
		this.leaflessRainfallThreshold = leaflessRainfallThreshold;
		this.leaflessStemflowFunction = leaflessStemflowFunction;
		this.leavedRainfallThreshold = leavedRainfallThreshold;
		this.leavedStemflowFunction = leavedStemflowFunction;
		this.foliageStorageCapacity_m2leaf = foliageStorageCapacity_m2leaf;
		this.barkProportionFunction = barkProportionFunction;
		this.barkThicknessFunction = barkThicknessFunction;
		this.barkBulkDensity = barkBulkDensity;
		this.minBarkConductance = minBarkConductance;
		this.maxBarkConductance = maxBarkConductance;
		this.referenceMaintenanceRespiration = referenceMaintenanceRespiration;
		this.nppToGppRatio_intercept = nppToGppRatio_intercept; // fa-29.10.2018
		this.nppToGppRatio_slope = nppToGppRatio_slope; // fa-29.10.2018
		this.basicCanopyStomatalConductance = basicCanopyStomatalConductance;
		this.radiationModifier = radiationModifier;
		this.vpdModifier = vpdModifier;
		this.swcModifier = swcModifier;
		this.tenPcHeightGirth = tenPcHeightGirth;
		this.sixtyPcHeightRelativeGirth = sixtyPcHeightRelativeGirth;
		this.transpirationModifierCorrection = transpirationModifierCorrection;
		this.branchLitterP1 = branchLitterP1;
		this.branchLitterP2 = branchLitterP2;
		this.fruitLitterFallP1 = fruitLitterFallP1;
		this.fruitLitterFallP2 = fruitLitterFallP2;
		this.fruitProdMinDbh = fruitProdMinDbh;

		this.heightToTree = heightToTree;
		this.seedlingHeightToDiameter = seedlingHeightToDiameter;
		this.seedlingDiameterToHeight = seedlingDiameterToHeight;
		this.seedlingD5ToD130 = seedlingD5ToD130;
		this.seedlingGetBiomass = seedlingGetBiomass;
		this.seedlingHeightToLAI = seedlingHeightToLAI;
		this.seedlingTransmittanceToSLA = seedlingTransmittanceToSLA;
		this.rootToShootRatioFunction = rootToShootRatioFunction;
		this.seedlingHeightGrowth = seedlingHeightGrowth;
		this.seedlingHeightToCrownRadius = seedlingHeightToCrownRadius;

	}

	// Now commented and to be completely deleted if no more used. nb-21.12.2017
	// /**
	// * A second constructor used with simplified species in the inventory
	// loader
	// */
	// public HetSpecies(int id, String name, HetSpecies speciesSpecimen, String
	// niceName, HetModel model, Color color,
	// String crownForm) throws Exception {
	//
	// // speciesSpecimen is for Species chaining (Enum property, automatic
	// // groups)
	// super(id, name, speciesSpecimen, SPECIES_PROPERTY_NAME);
	//
	//// this.value = value;
	//
	// this.name = name;
	// this.niceName = niceName;
	// this.color = color;
	// this.crownForm = crownForm;
	// this.model = model;
	// setMissingDataFromSimplifiedSpecies();
	// }

	// Now commented and to be completely deleted if no more used. nb-21.12.2017
	// /**
	// * A method to call if simplified species are loaded
	// *
	// * @author GL MJ 7/3/13
	// */
	// public void setMissingDataFromSimplifiedSpecies() throws Exception {
	//
	// // fc-30.4.2015 some properties have been added and were not yet copied
	// // here :
	// // parUseEfficiencyFunction, iprfwHeightGrowthFunction,
	// // baileuxHeightGrowthFunction,LADoption, Toption
	// // See species input file to get correct functions
	//
	// switch (getId()) {
	// case 1: // oak
	// this.trunkFormFactor = 0.7;
	// this.maxHeight = 35;
	// this.maxCrownRadius = 15;
	// this.LAD = 0.73;
	// this.LADup = 1.07;
	// this.LADdown = 0.28;
	// this.SLAup = 14.02;
	// this.SLAdown = 15.62;
	// this.SLAtop = 14;
	// this.SLAbottom = 22;
	// this.SLAintercept = 5;
	// this.UFLB = 0.85;
	//
	// // this.leafLitterAmountAlpha = 1.06;
	// // this.leafLitterAmountBeta = 1.96;
	// initBranchBiomassAllometry = new
	// InitBiomassAllometry4p("initBiomassAllometry4p(1.1;3.246;0.905;1.303)");
	// initStemBiomassAllometry = new
	// InitBiomassAllometry4p("initBiomassAllometry4p(26000;1.842;0.888;0)");
	// leafBiomassAllometry = new
	// LeafBiomassAllometry("leafBiomassAllometry(0.003;1.96;1.96;520)");
	//
	// this.extinctionCoefficient = 0.5;
	// this.crownTransmissivity = 0.1103;
	// break;
	// case 2: // beech
	// this.trunkFormFactor = 0.7;
	// this.maxHeight = 35;
	// this.maxCrownRadius = 15;
	// this.LAD = 0.92;
	// this.LADup = 1.21;
	// this.LADdown = 0.58;
	// this.SLAup = 24.74;
	// this.SLAdown = 30.48;
	// this.SLAtop = 24;
	// this.SLAbottom = 85;
	// this.SLAintercept = -10;
	// this.UFLB = 0.75;
	//
	// // this.leafLitterAmountAlpha = 0.18;
	// // this.leafLitterAmountBeta = 2.33;
	// initBranchBiomassAllometry = new
	// InitBiomassAllometry4p("initBiomassAllometry4p(1.1;3.246;0.905;1.303)");
	// initStemBiomassAllometry = new
	// InitBiomassAllometry4p("initBiomassAllometry4p(26000;1.842;0.888;0)");
	// leafBiomassAllometry = new
	// LeafBiomassAllometry("leafBiomassAllometry(0.003;1.96;1.96;520)");
	//
	// this.extinctionCoefficient = 0.5;
	// this.crownTransmissivity = 0.0178;
	// break;
	// case 3: // hornbeam
	// this.trunkFormFactor = 0.7;
	// this.maxHeight = 35;
	// this.maxCrownRadius = 15;
	// this.LAD = 0.36;
	// this.LADup = 0.38;
	// this.LADdown = 0.33;
	// this.SLAup = 39.01;
	// this.SLAdown = 44.91;
	// this.SLAtop = 35;
	// this.SLAbottom = 55;
	// this.SLAintercept = 10;
	// this.UFLB = 0.75;
	//
	// // this.leafLitterAmountAlpha = 0.18;
	// // this.leafLitterAmountBeta = 2.33;
	// initBranchBiomassAllometry = new
	// InitBiomassAllometry4p("initBiomassAllometry4p(1.1;3.246;0.905;1.303)");
	// initStemBiomassAllometry = new
	// InitBiomassAllometry4p("initBiomassAllometry4p(26000;1.842;0.888;0)");
	// leafBiomassAllometry = new
	// LeafBiomassAllometry("leafBiomassAllometry(0.003;1.96;1.96;520)");
	//
	// this.extinctionCoefficient = 0.5;
	// this.crownTransmissivity = 0.0809;
	// break;
	// case 4: // birch
	// this.trunkFormFactor = 0.7;
	// this.maxHeight = 35;
	// this.maxCrownRadius = 15;
	// this.LAD = 0.5;
	// this.LADup = 0.5;
	// this.LADdown = 0.5;
	// this.SLAup = 20;
	// this.SLAdown = 20;
	// this.SLAtop = 20;
	// this.SLAbottom = 20;
	// this.SLAintercept = 20;
	// this.UFLB = 0.85;
	//
	// // this.leafLitterAmountAlpha = 0.18;
	// // this.leafLitterAmountBeta = 2.33;
	// initBranchBiomassAllometry = new
	// InitBiomassAllometry4p("initBiomassAllometry4p(1.1;3.246;0.905;1.303)");
	// initStemBiomassAllometry = new
	// InitBiomassAllometry4p("initBiomassAllometry4p(26000;1.842;0.888;0)");
	// leafBiomassAllometry = new
	// LeafBiomassAllometry("leafBiomassAllometry(0.003;1.96;1.96;520)");
	//
	// this.extinctionCoefficient = 0.5;
	// this.crownTransmissivity = 0.1121;
	// break;
	// case 5: // other broadleaved
	// this.trunkFormFactor = 0.7;
	// this.maxHeight = 35;
	// this.maxCrownRadius = 15;
	// this.LAD = 0.5;
	// this.LADup = 0.5;
	// this.LADdown = 0.5;
	// this.SLAup = 20;
	// this.SLAdown = 20;
	// this.SLAtop = 20;
	// this.SLAbottom = 20;
	// this.SLAintercept = 20;
	// this.UFLB = 0.75;
	//
	// // this.leafLitterAmountAlpha = 0.18;
	// // this.leafLitterAmountBeta = 2.33;
	// initBranchBiomassAllometry = new
	// InitBiomassAllometry4p("initBiomassAllometry4p(1.1;3.246;0.905;1.303)");
	// initStemBiomassAllometry = new
	// InitBiomassAllometry4p("initBiomassAllometry4p(26000;1.842;0.888;0)");
	// leafBiomassAllometry = new
	// LeafBiomassAllometry("leafBiomassAllometry(0.003;1.96;1.96;520)");
	//
	// this.extinctionCoefficient = 0.5;
	// this.crownTransmissivity = 0.05;
	// break;
	// case 6: // other coniferous
	// this.trunkFormFactor = 0.7;
	// this.maxHeight = 35;
	// this.maxCrownRadius = 15;
	// this.LAD = 0.5;
	// this.LADup = 0.5;
	// this.LADdown = 0.5;
	// this.SLAup = 8;
	// this.SLAdown = 8;
	// this.SLAtop = 8;
	// this.SLAbottom = 8;
	// this.SLAintercept = 8;
	// this.UFLB = 0.75;
	//
	// // this.leafLitterAmountAlpha = 0.18;
	// // this.leafLitterAmountBeta = 2.33;
	// initBranchBiomassAllometry = new
	// InitBiomassAllometry4p("initBiomassAllometry4p(1.1;3.246;0.905;1.303)");
	// initStemBiomassAllometry = new
	// InitBiomassAllometry4p("initBiomassAllometry4p(26000;1.842;0.888;0)");
	// leafBiomassAllometry = new
	// LeafBiomassAllometry("leafBiomassAllometry(0.003;1.96;1.96;520)");
	//
	// this.extinctionCoefficient = 0.5;
	// this.crownTransmissivity = 0.05;
	// break;
	// default:
	// this.trunkFormFactor = 0.7;
	// this.maxHeight = 35;
	// this.maxCrownRadius = 15;
	// this.LAD = 0.5;
	// this.LADup = 0.5;
	// this.LADdown = 0.5;
	// this.SLAup = 20;
	// this.SLAdown = 20;
	// this.SLAtop = 20;
	// this.SLAbottom = 20;
	// this.SLAintercept = 20;
	// this.UFLB = 0.75;
	//
	// // this.leafLitterAmountAlpha = 0.18;
	// // this.leafLitterAmountBeta = 2.33;
	// initBranchBiomassAllometry = new
	// InitBiomassAllometry4p("initBiomassAllometry4p(1.1;3.246;0.905;1.303)");
	// initStemBiomassAllometry = new
	// InitBiomassAllometry4p("initBiomassAllometry4p(26000;1.842;0.888;0)");
	// leafBiomassAllometry = new
	// LeafBiomassAllometry("leafBiomassAllometry(0.003;1.96;1.96;520)");
	//
	// this.extinctionCoefficient = 0.5;
	// this.crownTransmissivity = 0.05;
	// break;
	// }
	//
	// }

	/**
	 * Each species must have a different id.
	 */
	public int getId() {
		return super.getValue();
	}

	/**
	 * Two species are equal if they have same class and same value.
	 */
	public boolean equals(Object otherSpecies) {
		return this.getClass().equals(otherSpecies.getClass()) && getId() == ((HetSpecies) otherSpecies).getId();
	}

	@Override
	public String toString() {
		return "HetSpecies id: " + getId() + " name: " + name;
	}

	/**
	 * Returns the height at which a tree is recruited.
	 */
	public double getHeightToTree() {
		return heightToTree;
	}

	public HetTreeCompartment getInitialLeavesUpperCurrentCompartment() {
		return initialLeavesUpperCurrentCompartment;
	}

	public void setInitialLeavesUpperCurrentCompartment(HetTreeCompartment initialLeavesUpperCurrentCompartment) {
		if (this.initialLeavesUpperCurrentCompartment != null)
			return; // Only once is enough
		this.initialLeavesUpperCurrentCompartment = initialLeavesUpperCurrentCompartment;
	}

	// mg/g
	public double getInitialLeafCarbonConcentration() {
		return this.initialLeavesUpperCurrentCompartment.getConcentration(HetTreeElement.C);
	}

	// mg/g
	public double getInitialLeafNitrogenConcentration() {
		return this.initialLeavesUpperCurrentCompartment.getConcentration(HetTreeElement.N);
	}

}
