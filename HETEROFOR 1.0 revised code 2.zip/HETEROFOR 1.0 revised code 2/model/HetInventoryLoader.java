/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import capsis.defaulttype.plotofcells.SquareCell;
import capsis.kernel.GModel;
import capsis.kernel.GScene;
import capsis.lib.regeneration.RGVegetationLayer;
import capsis.lib.samsaralight.SLSensor;
import capsis.util.StandRecordSet;
import heterofor.model.treechemistry.HetLitterCompartment;
import heterofor.model.treechemistry.HetTreeCompartment;
import jeeb.lib.maps.geom.Point2;
import jeeb.lib.maps.geom.Polygon2;
import jeeb.lib.util.AmapTools;
import jeeb.lib.util.Check;
import jeeb.lib.util.Import;
import jeeb.lib.util.ListMap;
import jeeb.lib.util.Log;
import jeeb.lib.util.Record;
import jeeb.lib.util.TicketDispenser;
import jeeb.lib.util.Translator;
import jeeb.lib.util.Vertex3d;

/**
 * HetInventoryLoader loads a file and creates an initial scene. It is a Capsis
 * extension and may also be used as an exporter.
 *
 * @author M. Jonard, F. Herman - January 2012
 */
public class HetInventoryLoader extends StandRecordSet implements Serializable {

	// Extension properties
	// Seems to be a simpler loader, no matchWith() method. nb-13.08.2018
	// static public String NAME = Translator.swap("HetInventoryLoader");
	// static public String AUTHOR = "M. Jonard, F. Herman";
	// static public String VERSION = "1.0";
	// static public String DESCRIPTION =
	// Translator.swap("HetInventoryLoader.description");

	// Generic keyword record is described in superclass: key = value
	
	// fa-06.01.2020
	// Used at load time to manage NA (String) values in the file, will be
	// replaced by NOT_SET (double), allowed for hlce of coniferous species
	public static final double NOT_SET = -999999;
	
	// fa-06.01.2020
	/**
	* Replaces on the fly "NA" by 0.
	*/
	protected String correctLine(String line) {
		return line.replace("NA", ""+HetInventoryLoader.NOT_SET);
	}

	// A record class for the vertex of inventory zones
	@Import
	static public class InventoryZone extends Record implements Serializable {

		public InventoryZone() {
			super();
		}

		public InventoryZone(String line) throws Exception {
			super(line);
		}

		public String inventoryType; // R2, E2, E3, or E4, Jonard
		public double x;
		public double y;

	}

	// A plot line in the file
	@Import
	static public class PlotLine extends Record implements Serializable {

		public PlotLine() {
			super();
		}

		public PlotLine(String line) throws Exception {
			super(line);
		}

		public double plotLatitude_deg; // North
		public double plotLongitude_deg; // East
		public double plotSlope_deg;
		public double plotAspect_deg;
		public double northToXAngle_cw_deg;

	}

	// A sensor line in the file
	@Import
	static public class SensorLine extends Record implements Serializable {

		public SensorLine() {
			super();
		}

		public SensorLine(String line) throws Exception {
			super(line);
		}

		public int id;
		public double x;
		public double y;
		public double h;
		public double paclTotal;
		public double paclDiffuse;
		public double paclDirect;
	}

	// A sapling line in the file (from Quergus but unused in Heterofore)
	@Import
	static public class SaplingLine extends Record implements Serializable {

		public SaplingLine() {
			super();
		}

		public SaplingLine(String line) throws Exception {
			super(line);
		}

		public double x;
		public double y;
		public int speciesId;
		public double height;
		public double dg;
		public double N;
		public int subplotID;
		public String note;
	}

	// Now commented and to be completely deleted if no more used. nb-21.12.2017
	// // A species line in the file
	// @Import
	// static public class SimplifiedSpeciesLine extends Record {
	//
	// public SimplifiedSpeciesLine() {
	// super();
	// }
	//
	// public SimplifiedSpeciesLine(String line) throws Exception {
	// super(line);
	// }
	//
	// // public String getSeparator () {return ";";} // to change default "\t"
	// // separator
	// public int code; // must be unique
	// public String name; // must be unique
	// public String color;
	// public String crownForm;
	// }

	// A line for TREE compartment nutrient concentrations
	@Import
	static public class TreeConcentrationLine extends Record implements Serializable {

		public TreeConcentrationLine() {
			super();
		}

		public TreeConcentrationLine(String line) throws Exception {
			super(line);
		}

		public String speciesName; // must be known in the species file
		public String compartmentName; // See HetTreeCompartment
		public double concentration_C;
		public double concentration_N;
		public double concentration_P;
		public double concentration_S;
		public double concentration_Ca;
		public double concentration_Mg;
		public double concentration_K;
		public double concentration_Na;
		public double concentration_Al;
		public double concentration_Mn;
		public double concentration_Fe;
		public double concentration_Cl;
		public double concentration_Si;

		/**
		 * Returns a HetTreeCompartment matching the concentration line.
		 */
		public HetTreeCompartment getTreeCompartment() {
			HetTreeCompartment tc = new HetTreeCompartment(compartmentName);

			tc.setConcentration("C", concentration_C);
			tc.setConcentration("N", concentration_N);
			tc.setConcentration("P", concentration_P);
			tc.setConcentration("S", concentration_S);
			tc.setConcentration("Ca", concentration_Ca);
			tc.setConcentration("Mg", concentration_Mg);
			tc.setConcentration("K", concentration_K);
			tc.setConcentration("Na", concentration_Na);
			tc.setConcentration("Al", concentration_Al);
			tc.setConcentration("Mn", concentration_Mn);
			tc.setConcentration("Fe", concentration_Fe);
			tc.setConcentration("Cl", concentration_Cl);
			tc.setConcentration("Si", concentration_Si);

			return tc;
		}
	}

	// A line for LITTER compartment nutrient concentrations
	@Import
	static public class LitterConcentrationLine extends Record implements Serializable {

		public LitterConcentrationLine() {
			super();
		}

		public LitterConcentrationLine(String line) throws Exception {
			super(line);
		}

		public String LITTER; // "LITTER"
		public String speciesName; // must be known in the species file
		public String compartmentName; // See HetLitterCompartment
		public double concentration_C;
		public double concentration_N;
		public double concentration_P;
		public double concentration_S;
		public double concentration_Ca;
		public double concentration_Mg;
		public double concentration_K;
		public double concentration_Na;
		public double concentration_Al;
		public double concentration_Mn;
		public double concentration_Fe;
		public double concentration_Cl;
		public double concentration_Si;

		/**
		 * Returns a HetLitterCompartment matching the concentration line.
		 */
		public HetLitterCompartment getLitterCompartment(HetTree tree) {
			HetLitterCompartment tc = new HetLitterCompartment(compartmentName);

			tc.setConcentration("C", concentration_C);
			tc.setConcentration("N", concentration_N);
			tc.setConcentration("P", concentration_P);
			tc.setConcentration("S", concentration_S);
			tc.setConcentration("Ca", concentration_Ca);
			tc.setConcentration("Mg", concentration_Mg);
			tc.setConcentration("K", concentration_K);
			tc.setConcentration("Na", concentration_Na);
			tc.setConcentration("Al", concentration_Al);
			tc.setConcentration("Mn", concentration_Mn);
			tc.setConcentration("Fe", concentration_Fe);
			tc.setConcentration("Cl", concentration_Cl);
			tc.setConcentration("Si", concentration_Si);

			return tc;
		}
	}

	// TODO GL ----------------- reorder the field
	// A tree line in the file
	@Import
	static public class TreeLine extends Record implements Serializable {

		public TreeLine() {
			super();
		}

		public TreeLine(String line) throws Exception {
			super(line);
		}

		// public String getSeparator () {return ";";} // to change default "\t"
		// separator
		public int id; // must be unique
		public int speciesCode; // 3 = oak; 4 = beech; 5 = Hornbeam; 6 = birch;
								// 7 = spruce; 8 = douglas; 9 = Scots pine;
								// 10 = silver fir; 11 = sycamore maple;
								// 1 = Other broadleaved; 2 =
								// other coniferous
		public double x; // m
		public double y; // m
		public double z; // m
		public double gbh; // girth at 1.3m (cm)
		public double htot; // total tree height (m)
		public double hlce; // height at the largest crown extension (m)
		public double hcb; // height of the crown base (m)
		public double rnorth; // crown radius in the North direction (m)
		public double reast; // crown radius in the East direction (m)
		public double rsouth; // crown radius in the South direction (m)
		public double rwest; // crown radius in the West direction (m)
		// fa-19.12.2019: tree characteristics may be either measured during inventories, or estimated through dendrometric relationships if not measured
		public boolean isMeasuredHtot;
		public boolean isMeasuredHlce;
		public boolean isMeasuredHcb;
		public boolean isMeasuredCrownRadii;

	}

	// Regeneration vegetation layer record
	@Import
	static public class VegetationLayerRecord extends Record implements Serializable {
		public VegetationLayerRecord() {
			super();
		}

		public VegetationLayerRecord(String line) throws Exception {
			super(line);
		}

		// public String getSeparator () {return ";";} // to change default "\t"
		// separator
		public char v;
		public int i;
		public int j;
		public String speciesName;
		public double height;
		public double cover;
	}

	// Regeneration cohort record
	@Import
	static public class CohortRecord extends Record implements Serializable {
		public CohortRecord() {
			super();
		}

		public CohortRecord(String line) throws Exception {
			super(line);
		}

		public int i;
		public int j;
		public int speciesId;
		public int year;
		public Collection classes;

		@Override
		protected Object parseToken(String token) throws Exception { // fc-12.9.2011
			return new Token(token);
		}

		/**
		 * The tokens in the collection: 4 commas separated values
		 */
		public class Token implements Serializable {
			public double b;
			public double c;
			public double d;

			public Token(String v) throws Exception {
				// remove leading and trailing spaces
				v = v.trim();
				// check ( and ) are here
				if (!v.startsWith("[") || !v.endsWith("]")) {
					throw new Exception();
				}
				// remove ( and )
				v = v.replace('[', ' ').replace(']', ' ').trim();

				StringTokenizer st = new StringTokenizer(v, ", ");
				b = Check.doubleValue(st.nextToken());
				c = Check.doubleValue(st.nextToken());
				d = Check.doubleValue(st.nextToken());

				// In case a token is missing / not a double, an exception will
				// be thrown: allright

			}

			public String toString() {
				return "Token[" + b + "," + c + "," + d + "]";
			}
		}

	}
	
	// fa-18.09.2018: Tree with sapflow record
	@Import
	static public class TreeWithSapflowRecord extends Record implements Serializable {
		public TreeWithSapflowRecord() {
			super();
		}

		public TreeWithSapflowRecord(String line) throws Exception {
			super(line);
		}

		// public String getSeparator () {return ";";} // to change default "\t"
		// separator
		public int treeId;
	}

	/**
	 * Constructor
	 */
	public HetInventoryLoader() {
		super();

		// fc-3.6.2019
		keepCommentsAndBlankLines = true;
	}

	/**
	 * Constructor 2, for scripts. Loads the given file, turn it into a
	 * collection of records. The load method must be called after to finish the
	 * reading.
	 */
	public HetInventoryLoader(String fileName) throws Exception {

		// fc-3.6.2019
		keepCommentsAndBlankLines = true;

		createRecordSet(fileName);
	}

	@Override
	public String getName() {
		return Translator.swap("HetInventoryLoader.name");
	}

	@Override
	public String getAuthor() {
		return "M. Jonard, F. Herman";
	}

	@Override
	public String getDescription() {
		return Translator.swap("HetInventoryLoader.description");
	}

	@Override
	public String getVersion() {
		return "1.0";
	}

	/**
	 * For export: turns the given Scene into a collection of records, in script
	 * mode, save (fileName) must be called after.
	 */
	@Override
	public void createRecordSet(GScene s) throws Exception {

		// Not implemented yet

	}

	/**
	 * Interprets all the records and creates the initial scene.
	 */
	public GScene load(GModel m) throws Exception {
		HetModel model = (HetModel) m;
		HetInitialParameters ip = model.getSettings();
		// SLModel samsaralightModel = model.getSLModel();
		// SLSettings slSettings = model.getSLModel().getSettings();

		// Initialisations
		HetScene initScene = new HetScene(ip);
		initScene.setSourceName(source); // generally a fileName
		int maxId = 0;
		// ip.speciesMap = new HashMap<Integer,HetSpecies> ();

		int value = 0;
		double cellWidth = 0;

		List<String> expectedFields = new ArrayList<>();
		expectedFields.add("plotName");
		expectedFields.add("date");
		expectedFields.add("cellWidth");
		expectedFields.add("ecosystemLAI");

		HetReporter.printInLog("HetInventoryLoader.load (): number of records: " + size());

		// list of polygon (inventory zone) points
		List<Point2> ptsJonard = new ArrayList<Point2>();
		List<Point2> ptsR2 = new ArrayList<Point2>();
		List<Point2> ptsE2 = new ArrayList<Point2>();
		List<Point2> ptsE3 = new ArrayList<Point2>();
		List<Point2> ptsE4 = new ArrayList<Point2>();

		double maxX = -10000000;
		double minX = 10000000;
		double maxY = -10000000;
		double minY = 10000000;

		HetSpecies speciesSpecimen = null;

		// fc+mj+br-4.10.2018 key is sp name, needed lower
		Map<String, HetSpecies> spNameMap = new HashMap<>();
		for (HetSpecies sp : ip.speciesMap.values()) {
			spNameMap.put(sp.getName(), sp);
		}

		ip.treeConcentrationLines = new ArrayList<>();
		Map<String, HetInventoryLoader.LitterConcentrationLine> litterConcentrationMap = new HashMap<>();

		List<VegetationLayerRecord> vegetationLayerRecords = new ArrayList<>();
		List<CohortRecord> cohortRecords = new ArrayList<>();
		
		//fa-18.09.2019
		List<Integer> treeWithSapflowRecords = new ArrayList<>();

		for (Iterator i = this.iterator(); i.hasNext();) {
			Record record = (Record) i.next();

			if (record instanceof HetInventoryLoader.KeyRecord) {
				// A keyword record
				HetInventoryLoader.KeyRecord r = (HetInventoryLoader.KeyRecord) record; // cast
																						// to
				// precise
				// type

				if (r.hasKey("plotName")) {
					try {
						ip.plotName = r.value;
						expectedFields.remove("plotName");
					} catch (Exception e) {
						Log.println(Log.ERROR, "HetInventoryLoader.load ()", "Trouble with plotName", e);
					}
				} else if (r.hasKey("date")) {
					try {
						initScene.setDate(r.getIntValue());
						expectedFields.remove("date");
					} catch (Exception e) {
						Log.println(Log.ERROR, "HetInventoryLoader.load ()", "Trouble with date", e);
					}
				} else if (r.hasKey("cellWidth")) {
					try {
						cellWidth = r.getDoubleValue();
						expectedFields.remove("cellWidth");
					} catch (Exception e) {
						Log.println(Log.ERROR, "HetInventoryLoader.load ()", "Trouble with cellWidth", e);
					}

					// } else if (r.hasKey ("sensorHeight")) { // optional
					// try {
					// ip.sensorHeight = r.getDoubleValue ();
					// } catch (Exception e) {
					// Log.println (Log.ERROR, "HetInventoryLoader.load ()",
					// "Trouble with sensorHeight", e);
					// }

					// fc-29.6.2017 MOVED in SamsaraLight file, corrected
					// SLSettingsloader
					// } else if (r.hasKey("sensorLightOnly")) { // optional
					// try {
					// samsaralightModel.getSettings().setSensorLightOnly(r.getBooleanValue());
					// ip.sensorLightOnly = r.getBooleanValue(); // TO DO
					// // ...
					// // this
					// // is
					// // probably
					// // non
					// // necessary
					// } catch (Exception e) {
					// Log.println(Log.ERROR, "HetInventoryLoader.load ()",
					// "Trouble with sensorLightOnly", e);
					// }

				} else if (r.hasKey("inventoryType")) { // optional (by default
														// = no buffer)
					try {
						ip.bufferType = r.value;
					} catch (Exception e) {
						Log.println(Log.ERROR, "HetInventoryLoader.load ()", "Trouble with inventoryType", e);
					}

				} else if (r.hasKey("yearlyRegenerationCohortsEmergence")) {
					// optional (by default if not found: false)
					try {
						ip.yearlyRegenerationCohortsEmergence = r.getBooleanValue();
					} catch (Exception e) {
						Log.println(Log.ERROR, "HetInventoryLoader.load ()",
								"Trouble with yearlyRegenerationCohortsEmergence", e);
					}

				} else if (r.hasKey("massLeafLitter_ha")) {
					try {
						ip.massLeafLitter_ha = r.getDoubleValue();
					} catch (Exception e) {
						Log.println(Log.ERROR, "HetInventoryLoader.load ()", "Trouble with massLeafLitter_ha", e);
					}

				} else if (r.hasKey("massBranchLitter_ha")) {
					try {
						ip.massBranchLitter_ha = r.getDoubleValue();
					} catch (Exception e) {
						Log.println(Log.ERROR, "HetInventoryLoader.load ()", "Trouble with massBranchLitter_ha", e);
					}

				} else if (r.hasKey("massRootLitter_ha")) {
					try {
						ip.massRootLitter_ha = r.getDoubleValue();
					} catch (Exception e) {
						Log.println(Log.ERROR, "HetInventoryLoader.load ()", "Trouble with massRootLitter_ha", e);
					}

				} else if (r.hasKey("massFineRootLitter_ha")) {
					try {
						ip.massFineRootLitter_ha = r.getDoubleValue();
					} catch (Exception e) {
						Log.println(Log.ERROR, "HetInventoryLoader.load ()", "Trouble with massFineRootLitter_ha", e);
					}

				} else if (r.hasKey("massSlowDecompositionPool_ha")) {
					try {
						ip.massSlowDecompositionPool_ha = r.getDoubleValue();
					} catch (Exception e) {
						Log.println(Log.ERROR, "HetInventoryLoader.load ()",
								"Trouble with massSlowDecompositionPool_ha", e);
					}

				} else if (r.hasKey("ecosystemLAI")) {
					try {
						ip.ecosystemLAI = r.getDoubleValue();
						expectedFields.remove("ecosystemLAI");
					} catch (Exception e) {
						Log.println(Log.ERROR, "HetInventoryLoader.load ()", "Trouble with ecosystemLAI", e);
					}

				}

			} else if (record instanceof HetInventoryLoader.InventoryZone) {
				// A Rectangle line
				HetInventoryLoader.InventoryZone ri = (HetInventoryLoader.InventoryZone) record;

				maxX = Math.max(ri.x, maxX);
				minX = Math.min(ri.x, minX);
				maxY = Math.max(ri.y, maxY);
				minY = Math.min(ri.y, minY);

				if (ri.inventoryType.equals("R2")) {
					ptsR2.add(new Point2(ri.x, ri.y));
				} else if (ri.inventoryType.equals("E2")) {
					ptsE2.add(new Point2(ri.x, ri.y));
				} else if (ri.inventoryType.equals("E3")) {
					ptsE3.add(new Point2(ri.x, ri.y));
				} else if (ri.inventoryType.equals("E4")) {
					ptsE4.add(new Point2(ri.x, ri.y));
				} else if (ri.inventoryType.equals("Jonard")) {
					ptsJonard.add(new Point2(ri.x, ri.y));
				} else {
					HetReporter.printInStandardOutput(
							"HetInitialParameters load() - Inventory record with wrong inventory type");
				}

				// Iterator it = r.points.iterator ();
				//
				// List<Vertex2d> re = new ArrayList<Vertex2d> ();
				// re.add ((Vertex2d) it.next ());
				// re.add ((Vertex2d) it.next ());
				// re.add ((Vertex2d) it.next ());
				// re.add ((Vertex2d) it.next ());
				//
				// initScene.setMainRectangle (re);

			} else if (record instanceof HetInventoryLoader.PlotLine) {
				// A PlotOfCells line
				HetInventoryLoader.PlotLine r = (HetInventoryLoader.PlotLine) record;

				// Report fields in samsaraFileLoader
				ip.samsaFileLoader.setPlotLatitude_deg(r.plotLatitude_deg);
				ip.samsaFileLoader.setPlotLongitude_deg(r.plotLongitude_deg);
				ip.samsaFileLoader.setPlotSlope_deg(r.plotSlope_deg);
				ip.samsaFileLoader.setPlotAspect_deg(r.plotAspect_deg);
				ip.samsaFileLoader.setNorthToXAngle_cw_deg(r.northToXAngle_cw_deg);

			} else if (record instanceof HetInventoryLoader.SensorLine) { // optional
				// A Sensor line
				HetInventoryLoader.SensorLine rs = (HetInventoryLoader.SensorLine) record;
				SLSensor sensor = new SLSensor(rs.id, rs.x, rs.y, rs.h);

				if (rs.paclTotal >= 0 && rs.paclTotal <= 1) {
					sensor.set_measuredRelativeEnergy(rs.paclTotal * 100);
				} else {
					HetReporter.printInLog(
							"QGInventoryLoader.load() - paclTotal was not between 0 and 1. No information recorded in the sensor.");
				}
				if (rs.paclDiffuse >= 0 && rs.paclDiffuse <= 1) {
					sensor.set_measuredRelativeEnergyDiffuse(rs.paclDiffuse * 100);
				} else {
					HetReporter.printInLog(
							"QGInventoryLoader.load() - paclDiffuse was not between 0 and 1. No information recorded in the sensor.");
				}
				if (rs.paclDirect >= 0 && rs.paclDirect <= 1) {
					sensor.set_measuredRelativeEnergyDirect(rs.paclDirect * 100);
				} else {
					HetReporter.printInLog(
							"QGInventoryLoader.load() - paclDirect was not between 0 and 1. No information recorded in the sensor.");
				}

				initScene.addSensor(sensor);

				// HetSensor s = new HetSensor (r.id, r.x, r.y);
				// model.addSensor (s);

			} else if (record instanceof HetInventoryLoader.SaplingLine) {

				// do nothing in heterofor, this is quergus business!!!!

			}
			// Now commented and to be completely deleted if no more used.
			// nb-21.12.2017
			// else if (record instanceof
			// HetInventoryLoader.SimplifiedSpeciesLine) {
			// // A tree line
			// HetInventoryLoader.SimplifiedSpeciesLine r =
			// (HetInventoryLoader.SimplifiedSpeciesLine) record; // cast
			//
			// StringTokenizer st = new StringTokenizer(r.color, ",");
			// int red = new Integer(st.nextToken()).intValue();
			// int green = new Integer(st.nextToken()).intValue();
			// int blue = new Integer(st.nextToken()).intValue();
			// Color speciesColor = new Color(red, green, blue);
			//
			// String speciesNameFromCode;
			// switch (r.code) {
			// case 1:
			// speciesNameFromCode = "quercus";
			// break;
			// case 2:
			// speciesNameFromCode = "fagus";
			// break;
			// case 3:
			// speciesNameFromCode = "carpinus";
			// break;
			// case 4:
			// speciesNameFromCode = "betulus";
			// break;
			// case 5:
			// speciesNameFromCode = "broadleaved";
			// break;
			// case 6:
			// speciesNameFromCode = "coniferous";
			// break;
			// default:
			// speciesNameFromCode = "broadleaved";
			// System.out.println("HetInventoryLoader.load() - unrecognized
			// species (broadleaved have been used)");
			// Log.println("HetInventoryLoader.load() - unrecognized species");
			// break;
			// }
			//
			// HetSpecies species = new HetSpecies(r.code, speciesNameFromCode,
			// speciesSpecimen, speciesNameFromCode, model,
			// speciesColor, r.crownForm);
			//
			// // fc-4.3.2016
			// // For species chaining (EnumProperty / automatic groups
			// if (speciesSpecimen == null)
			// speciesSpecimen = species;
			//
			// ip.speciesMap.put(r.code, species);
			//
			// }

			else if (record instanceof HetInventoryLoader.TreeConcentrationLine) {

				HetInventoryLoader.TreeConcentrationLine r = (HetInventoryLoader.TreeConcentrationLine) record;
				ip.treeConcentrationLines.add(r);

				// fc+mj+br-4.10.2018 keep init luc in species to later find
				// initial concentrations
				if (r.compartmentName.equals(HetTreeCompartment.LEAVES_UPPER_CURRENT)) {
					HetSpecies sp = spNameMap.get(r.speciesName);
					// sp will keep only the first passed one
					sp.setInitialLeavesUpperCurrentCompartment(r.getTreeCompartment());
				}

			} else if (record instanceof HetInventoryLoader.LitterConcentrationLine) {

				HetInventoryLoader.LitterConcentrationLine r = (HetInventoryLoader.LitterConcentrationLine) record;

				// System.out.println("HetInventoryLoader read a
				// LitterConcentrationLine: "+r);

				String key = r.speciesName + '.' + r.compartmentName;
				litterConcentrationMap.put(key, r);

			} else if (record instanceof HetInventoryLoader.TreeLine) {
				// A tree line
				HetInventoryLoader.TreeLine r = (HetInventoryLoader.TreeLine) record; // cast
																						// to
				// precise
				// type
				if (r.id > maxId) {
					maxId = r.id;
				}

				HetSpecies species = ip.speciesMap.get(r.speciesCode);

				if (species == null)
					throw new Exception("Could not find the species matching species code: " + r.speciesCode
							+ " to build tree: " + r.id
							+ ", check the species file (Heterofor inventory) or the species section (Quergus inventory).");

				double dbh = r.gbh / Math.PI;

				// fc+mj-21.11.2012 radii: do not check if 0, will be considered
				// later, see HetTree
				// ()

				// fc-29.6.2012 Check the crown radii and main heights
				if (r.reast + r.rwest <= 0)
					throw new Exception("Error for tree " + r.id + ": crown (reast + rwest) must be strictly positive");
				if (r.rnorth + r.rsouth <= 0)
					throw new Exception(
							"Error for tree " + r.id + ": crown (rnorth + rsouth) must be strictly positive");
				if (r.htot <= r.hcb)
					throw new Exception("Error for tree " + r.id + ": htot must be greater than hcb");
				if (r.htot < r.hlce)
					throw new Exception("Error for tree " + r.id + ": htot must be greater or equal than hlce");
//				if (r.hlce < r.hcb)
				if (r.hlce < r.hcb && !(species.isConiferous && r.hlce == HetInventoryLoader.NOT_SET)) // fa-06.01.2020: hlce is not required for coniferous species
					throw new Exception("Error for tree " + r.id + ": hlce must be greater or equal than hcb");
				
				// fa-10.01.2020:
				if (r.hlce == HetInventoryLoader.NOT_SET && (species.crownForm == "Ec" || species.crownForm == "Ed" || species.crownForm == "Bc" || species.crownForm == "Bd" || species.crownForm == "M"))
					throw new Exception("Error for tree " + r.id + ": hlce must be provided for crownForm " + species.crownForm);

				double slope_rad = Math.toRadians(ip.samsaFileLoader.getPlotSlope_deg());
				double aspect_rad = Math.toRadians(ip.samsaFileLoader.getPlotAspect_deg());
				// GL 13/05/2013 - we do not read z coordinates from the file!
				double z = HetModel.getZCoordinate(r.x, r.y, slope_rad, aspect_rad);

				// Create a tree
				// fc+mj-30.4.2015 LAD and T options now in species
				HetTree tree = new HetTree(r.id, initScene, species, dbh, r.htot, r.hlce, r.hcb, r.rnorth, r.reast,
						r.rsouth, r.rwest, r.x, r.y, z, species.crownForm, ip.treeChemistryDistribution,
						ip.foliarChemistryThresholds, ip.treeConcentrationLines);

				// fc+mj-12.9.2017 nppToGppRatio is managed differently
				// if (ip.constantNppToGppRatio)
				// tree.setNppToGppRatio(ip.nppToGppRatio);
				// else
				// tree.setNppToGppRatio(-1);

				// mj+fc-3.3.2016 MOVED in HetTree constructor
				// for (TreeConcentrationLine l : concentrationLines) {
				// if (l.speciesName.equals(species.getName())) {
				// tree.addCompartment(l.getTreeCompartment(tree));
				// }
				// }

				// Add the tree in the scene
				initScene.addTree(tree);

			} else if (record instanceof HetInventoryLoader.VegetationLayerRecord) {

				HetInventoryLoader.VegetationLayerRecord r = (HetInventoryLoader.VegetationLayerRecord) record;

				// Store records, see below
				vegetationLayerRecords.add(r);

			} else if (record instanceof HetInventoryLoader.CohortRecord) {

				HetInventoryLoader.CohortRecord r = (HetInventoryLoader.CohortRecord) record;

				// Store records, see below
				cohortRecords.add(r);

			} else if (record instanceof HetInventoryLoader.TreeWithSapflowRecord) { // fa-18.09.2019

				HetInventoryLoader.TreeWithSapflowRecord r = (HetInventoryLoader.TreeWithSapflowRecord) record;

				// Store records, see below
				treeWithSapflowRecords.add(r.treeId);

			} else if (record instanceof HetInventoryLoader.FreeRecord) {

				// fc-3.6.2019 added keepCommentsAndBlankLines in RecordSet ->
				// FreeRecords
				continue;

			} else {
				throw new Exception("Unrecognized record : " + record);
			}
		}

		// fc+mj-13.9.2017
		if (!expectedFields.isEmpty()) {
			throw new Exception("Missing expected fields in inventory: " + AmapTools.toString(expectedFields));
		}

		// Store the litter site level data in the InitialParameters for later
		// processing
		ip.litterConcentrationMap = litterConcentrationMap;

		// fc-12.5.2016
		// Memo which tree compartments were provided for each species
		ip.providedTreeCompartmentNames = new ListMap<>();
		for (TreeConcentrationLine l : ip.treeConcentrationLines) {
			ip.providedTreeCompartmentNames.addObject(l.speciesName, l.compartmentName);
		}

		// fc-12.5.2016
		// Memo which litter compartments were provided for each species
		ip.providedLitterCompartmentNames = new ListMap<>();
		for (LitterConcentrationLine l : litterConcentrationMap.values()) {
			ip.providedLitterCompartmentNames.addObject(l.speciesName, l.compartmentName);
		}

		// correct plot grid that was creating with only the coordinates of the
		// trees
		double xSize = maxX - minX;
		double ySize = maxY - minY;
		Vertex3d origin = new Vertex3d(minX, minY, 0);

		// plot, scene and cells creation
		try {
			initScene.setOrigin(origin);
			initScene.setXSize(xSize);
			initScene.setYSize(ySize);

			HetPlot initPlot = new HetPlot(initScene, cellWidth, ip.samsaFileLoader.getPlotSlope_deg(),
					ip.samsaFileLoader.getPlotAspect_deg());
			initScene.setPlot(initPlot);

			// Init the carbon stock variables in the cells
			for (SquareCell c : initPlot.getCells()) {
				HetCell hc = (HetCell) c;

				hc.setMassLeafLitter_ha(ip.massLeafLitter_ha);
				hc.setMassBranchLitter_ha(ip.massBranchLitter_ha);
				hc.setMassRootLitter_ha(ip.massRootLitter_ha);
				hc.setMassFineRootLitter_ha(ip.massFineRootLitter_ha);
				hc.setMassSlowDecompositionPool_ha(ip.massSlowDecompositionPool_ha);
			}

			// Update the tree list in each cell
			initScene.makeTreesPlotRegister();

		} catch (Exception e) {
			Log.println(Log.ERROR, "HetInventoryLoader.load () -", "Trouble creating initial plot and scene", e);
			// if (!cellWidthFound) {
			// Log.println(Log.ERROR, "HetInventoryLoader.load () -", "Missing
			// cellWidth from the inventory file.", e);
			// }
		}

		// Regeneration lib objects
		for (VegetationLayerRecord r : vegetationLayerRecords) {

			HetPlot plot = (HetPlot) initScene.getPlot();
			HetCell cell = (HetCell) plot.getCell(r.i, r.j);

			// fc+nd-26.2.2014
			RGVegetationLayer vl = RGVegetationLayer.getUnderstorey(r.speciesName, r.height, r.cover);

			cell.addVegetationLayer(vl);

		}

		// Create the cohortsManager in ip
		ip.cohortsManager = new HetRegenerationCohortsManager(ip.yearlyRegenerationCohortsEmergence, cohortRecords);

		// Run it on initScene
		ip.cohortsManager.run(ip, initScene);
		
		// fa-18.09.2019
		ip.treesWithSapflow = treeWithSapflowRecords;

		// Init treeIdDispenser (to get new ids for regeneration)
//		model.getTreeIdDispenser().setCurrentValue(maxId); // fa-21.01.2020: commented: now set to 5000 (see HetModel constructor)

		// create inventory polygons if needed
		if (!ptsJonard.isEmpty()) {
			
			// fa-16.01.2020: check that the corners of the inventory zone form a convex polygon, 
			// otherwise problems may occur later when translating trees in HetModel.fillGaps()
			for (int i = 0; i < ptsJonard.size(); i++) {
				List<Point2> tmpList = new ArrayList(ptsJonard);
				tmpList.remove(i); // remove one vertex => quadrilateral -> triangle
				// Check if the removed vertex is included within the triangle area delimited by the three remaining ones,
				// if yes => non-convex quadrilateral
				Polygon2 triangle = new Polygon2(tmpList);
				boolean isConcaveInventoryZone = triangle.contains(ptsJonard.get(i));
//				boolean isConcaveInventoryZone = isInTriangle(ptsJonard.get(i), tmpList);
				if (isConcaveInventoryZone)
					throw new Exception("HetInventoryLoader(): corners provided for the inventory zone should form a convex quadrilateral. "
							+ " \n Point with x-coordinate = " + ptsJonard.get(i).getX() + " and y-coordinate = " + ptsJonard.get(i).getY() + " is inner vertex.");
			}
			
			// fa-16.01.2020: ensure that the 4 plot corners are sorted clockwise, as requested below for Polygon2 class
			List<Point2> ptsJonardCwSorted = new ArrayList<Point2>();
			sortPointsClockwise(ptsJonard, ptsJonardCwSorted);
			
//			ip.setInventoryZoneJonard(new Polygon2(ptsJonard));
			ip.setInventoryZoneJonard(new Polygon2(ptsJonardCwSorted)); // fa-16.01.2020
		}
		if (!ptsR2.isEmpty())
			ip.setInventoryZoneR2(new Polygon2(ptsR2));
		if (!ptsE2.isEmpty())
			ip.setInventoryZoneE2(new Polygon2(ptsE2));
		if (!ptsE3.isEmpty())
			ip.setInventoryZoneE3(new Polygon2(ptsE3));
		if (!ptsE4.isEmpty())
			ip.setInventoryZoneE4(new Polygon2(ptsE4));

		// Set origin height
		// initScene.getOrigin ().z = ip.sensorHeight;
		HetReporter.printInStandardOutput("HetInventoryLoader.load() - inventory file has been loaded.");

		return initScene;
	}
	
	// fa-16.01.2020
	private void sortPointsClockwise (List<Point2> pointsList, List<Point2> pointsListSorted) {
		
		// Calculate center of points
		double xCenter = 0;
		double yCenter = 0;
		for (int i = 0; i < pointsList.size(); i++) {
			xCenter += pointsList.get(i).getX();
			yCenter += pointsList.get(i).getY();
		}
		Point2 center = new Point2(xCenter / (double) pointsList.size(), yCenter / (double) pointsList.size());
		
		// Determine angle for each point: '-'y to be clockwise, start angle (-179.999) is in the negative x-axis direction
		List<HetPoint2WithAngle> pointsWithAngleList = new ArrayList<HetPoint2WithAngle>();
		for (int i = 0; i < pointsList.size(); i++) {
			double xCentered = pointsList.get(i).getX() - center.getX();
			double yCentered = pointsList.get(i).getY() - center.getY();
			double ang = Math.atan2(xCentered, -yCentered);
			pointsWithAngleList.add(new HetPoint2WithAngle(pointsList.get(i).getX(), pointsList.get(i).getY(), ang));
		}
		
		Collections.sort(pointsWithAngleList, new Comparator<HetPoint2WithAngle>() {
			
			public int compare(HetPoint2WithAngle p1, HetPoint2WithAngle p2) {
				return Double.compare(p1.getAngle(), p2.getAngle());
			}
		});
		
//		List<Point2> sortedPointsList = new ArrayList<Point2>();
		for (int i = 0; i < pointsWithAngleList.size(); i++) {
			pointsListSorted.add(new Point2(pointsWithAngleList.get(i).getX(), pointsWithAngleList.get(i).getY(), i)); // last argument is point id
		}
		
//		return sortedPointsList;
	}
	
	//fa-16.01.2020
	private class HetPoint2WithAngle extends Point2 {
		private double angle;
		
		/**
		 * Constructor
		 */
		public HetPoint2WithAngle(double x, double y, double angle) {
			super(x, y);
			this.angle = angle;
		}
		
		public void setAngle(double angle) {
			this.angle = angle;
		}
		
		public double getAngle() {
	    	return angle;
	    }
	}

	/**
	 * A way to add record at export time, see the
	 * VirtualUnderstoreyRegeneration tool.
	 */
	public void addFreeRecord(String s) {
		add(new FreeRecord(s));
	}

	/**
	 * A way to add record at export time, see the
	 * VirtualUnderstoreyRegeneration tool.
	 */
	public void addRecord (Record r) {
		super.add (r);
	}

}
