/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.model.vegetationperiod;

import heterofor.model.HetReporter;
import heterofor.model.phenology.HetPhenology;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * A vegetation period with characteristic dates and key doys.
 *
 * @author F. André, F. de Coligny - March 2016
 */
public class HetVegetationPeriod implements Serializable {

	// 3 main phases in the vegetation period
	public HetPhase leafDevelopmentPhase;
	public HetPhase completeDevelopmentPhase;
	public HetPhase yellowingPhase;
	
	public HetPhase singleDayPhase; // fa-31.01.2020: for fine resolution radiative balance on single days

	private List<HetPhase> phases;

	/**
	 * Constructor. phenologyMap key: species id, value: phenology.
	 */

	public HetVegetationPeriod(HashMap<Integer, HetPhenology> phenologyMap) throws Exception {

		phases = new ArrayList<>();

		// 1. leafDevelopmentPhase
		int startDate = Integer.MAX_VALUE;
		int endDate = Integer.MIN_VALUE;

		for (HetPhenology pheno : phenologyMap.values()) {
			startDate = Math.min(startDate, pheno.getT2a_standBudburstStartingDate().getDoy());
			endDate = Math.max(endDate, pheno.getT2c_completeLeafDevelopmentDate().getDoy());
		}
		HetReporter.printInStandardOutput("startDate_t2= " + startDate + " endDate_t2= " + endDate); // fa-31.05.2017

		int numberOfKeyDoy = 2;
		leafDevelopmentPhase = new HetPhase("LD", startDate, endDate, numberOfKeyDoy, phenologyMap);
		phases.add(leafDevelopmentPhase);

		// 3. yellowingPhase
		startDate = Integer.MAX_VALUE;
		endDate = Integer.MIN_VALUE;

		for (HetPhenology pheno : phenologyMap.values()) {
			startDate = Math.min(startDate, pheno.getT4a_yellowingStartingDate().getDoy());
			endDate = Math.max(endDate, pheno.getT4b_yellowingEndingDate().getDoy());
		}
		HetReporter.printInStandardOutput("startDate_t4a= " + startDate + " endDate_t4b= " + endDate); // fa-31.05.2017

		// int yellowingPhaseStartDate = startDate; // TMP
		numberOfKeyDoy = 2;
		yellowingPhase = new HetPhase("LY", startDate, endDate, numberOfKeyDoy, phenologyMap);
		phases.add(yellowingPhase);

		// 2. completeDevelopmentPhase
		// fc+mj+fa added +1 and -1 below
		completeDevelopmentPhase = new HetPhase("LEAVED_PERIOD", leafDevelopmentPhase.endDoy + 1,
				yellowingPhase.startDoy - 1, 0, null);
		completeDevelopmentPhase.setCompleteDevelopmentPhase(true);
		// completeDevelopmentPhase = new HetPhase(leafDevelopmentPhase.endDate,
		// yellowingPhase.startDate);// LATER
		phases.add(completeDevelopmentPhase);

		// fc+fa-27.4.2017 BeamSet creation in fine resolution mode
		// Create beamSet for root step, valid for 3 years (if
		// radiationCalculationTimeStep = 3)
		// int startYear = initScene.getDate();
		// int endYear = startYear + ip.radiationCalculationTimeStep - 1;
		// int leavedPeriodStartDoy = 135;
		// int leavedPeriodEndDoy = 257;
		//
		// List<HetKeyDoy> keyDoys = new ArrayList<>();
		//
		// HetKeyDoy d1 = new HetKeyDoy(119, "LD1");
		// d1.addLadProportion(1, 0.58);
		// d1.addLadProportion(2, 0.14);
		// d1.addLadProportion(3, 0.14);
		// d1.addLadProportion(4, 0.14);
		// d1.addLadProportion(5, 0.14);
		// d1.addLadProportion(6, 0.14);
		// keyDoys.add(d1);
		//
		// HetKeyDoy d2 = new HetKeyDoy(130, "LD2");
		// d2.addLadProportion(1, 1);
		// d2.addLadProportion(2, 0.8);
		// d2.addLadProportion(3, 0.8);
		// d2.addLadProportion(4, 0.8);
		// d2.addLadProportion(5, 0.8);
		// d2.addLadProportion(6, 0.8);
		// keyDoys.add(d2);

	}
	
	// fa-31.01.2020
	/**
	 * Constructor for fine resolution radiative balance on single days
	 */
	public HetVegetationPeriod(int[] doys) throws Exception {
		
		phases = new ArrayList<>();
		
		singleDayPhase = new HetPhase("SINGLE_DAY", doys);
		phases.add(singleDayPhase);
	}

	/**
	 * Returns true if the given doy is in the vegetation period, i.e. in a
	 * phase.
	 */
	public boolean isVegetationPeriod(int doy) {

		HetPhase p = getPhase(doy);

		// before bud burst date or after leaf senescence date
		return p != null;

	}

	/**
	 * Returns the phase containing the given doy or null.
	 *
	 * @param doy
	 * @return
	 */
	public HetPhase getPhase(int doy) {
		for (HetPhase p : phases) {
			if (p.contains(doy))
				return p;
		}
		// No phase containing the given doy
		return null;
	}

	public List<HetPhase> getPhases() {
		return phases;
	}

}
