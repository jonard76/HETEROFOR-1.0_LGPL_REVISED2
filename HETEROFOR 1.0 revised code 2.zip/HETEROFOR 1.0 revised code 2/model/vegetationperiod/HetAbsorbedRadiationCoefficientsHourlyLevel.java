/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.model.vegetationperiod;

import heterofor.model.HetScene;
import heterofor.model.HetTree;
import heterofor.model.meteorology.HetMeteoLine;

import java.util.List;

import jeeb.lib.util.ListMap;
import jeeb.lib.util.Log;
import capsis.lib.samsaralight.tag.SLTag;
import capsis.lib.samsaralight.tag.SLTagTreeResult;

/**
 * Computes the equivalent surfaces for diffuse and direct radiation for a given
 * tree from a hourly radiation balance (tagMode in SamsaraLight).
 *
 * @author F. André, F. de Coligny - May 2017
 *
 */
public class HetAbsorbedRadiationCoefficientsHourlyLevel {

//	private HetScene newScene;
//	private HetScene refScene;
//	private HetTree refTree;
//	private HetMeteoLine line;
//	private int doy;
//	private int hour;
//
//	private ListMap<String, SLTagTreeResult> tagResultMap;
//	private HetVegetationPeriod vegetationPeriod;
//
//	// Results
//	private double treeLeafAbsorbedDirectRadiationCoefficient = 0;
//	private double treeLeafAbsorbedDiffuseRadiationCoefficient = 0;
//
//	/**
//	 * Constructor. The given tree has tag results (cf. SamsaraLight tagMode) in
//	 * his slTreeLight, the given meteo line if for one hour.
//	 */
//	public HetAbsorbedRadiationCoefficientsHourlyLevel(HetScene newScene, HetScene refScene, HetTree refTree,
//			HetMeteoLine line, int doy) {
//
//		this.newScene = newScene;
//		this.refScene = refScene;
//		this.refTree = refTree;
//		this.line = line;
//		this.doy = doy;
//		this.hour = line.hour; // [0, 23]
//
//		tagResultMap = refTree.getTreeLight().getTagResultMap();
//		vegetationPeriod = refScene.getVegetationPeriod();
//
//		HetPhase phase = vegetationPeriod.getPhase(doy);
//
//		// Should only be called within vegetation period. If no phase found,
//		// return and leave the results = 0
//		if (phase == null) {
//			Log.println(Log.ERROR, "HetAbsorbedRadiationCoefficientsHourlyLevel.c ()",
//					"Error, this method should be called only in vegetation period, could not find a phase covering doy: "
//							+ doy);
//			return; // we are before bud burst or after senecence
//		}
//
//		double[] direcEnergy_H_diffuseEnergy_H = evaluateEnergy_H(phase, line.radiation);
//
//		double direcEnergy_H = direcEnergy_H_diffuseEnergy_H[0];
//		double diffuseEnergy_H = direcEnergy_H_diffuseEnergy_H[1];
//
//		double standIncidentRadiation_H = line.radiation; // TMP
//
//		// Calculation of yearly leaf PAR interception coefficient: DIRECT
//		double treeBranchAbsorbedDirectRadiation = newScene.getBarkAbsorbedDirectRadiation()
//				* refTree.getBranchBarkArea();
//		double treeCrownAbsorbedDirectRadiation = direcEnergy_H * (1 - 0.11);
//		double treeLeafAbsorbedDirectRadiation = treeCrownAbsorbedDirectRadiation - treeBranchAbsorbedDirectRadiation;
//
//		// MJ/tree/year / MJ/tree/year
//		treeLeafAbsorbedDirectRadiationCoefficient = treeLeafAbsorbedDirectRadiation / standIncidentRadiation_H;
//
//		// Calculation of yearly leaf PAR interception coefficient: DIFFUSE
//		double treeBranchAbsorbedDiffuseRadiation = newScene.getBarkAbsorbedDiffuseRadiation()
//				* refTree.getBranchBarkArea();
//		double treeCrownAbsorbedDiffuseRadiation = diffuseEnergy_H * (1 - 0.11);
//		double treeLeafAbsorbedDiffuseRadiation = treeCrownAbsorbedDiffuseRadiation
//				- treeBranchAbsorbedDiffuseRadiation;
//
//		// MJ/tree/year / MJ/tree/year
//		treeLeafAbsorbedDiffuseRadiationCoefficient = treeLeafAbsorbedDiffuseRadiation / standIncidentRadiation_H;
//
//	}
//
//	private double[] evaluateEnergy_H(HetPhase phase, double radiation) {
//		double[] direcEnergy_H_diffuseEnergy_H = new double[2];
//
//		double directEnergySum = 0;
//		double diffuseEnergySum = 0;
//
//		String beamTagName = phase.getName() + "_" + hour;
//
//		List<SLTagTreeResult> results = tagResultMap.get(beamTagName);
//
//		if (results != null) { // e.g. LD1_0 (night)
//
//			for (SLTagTreeResult r : results) {
//
//				// We ignore energyTags CROWN_POTENTIAL and
//				// LOWER_CROWN_POTENTIAL
//
//				if (r.energyTag.equals(SLTag.DIRECT)) {
//					directEnergySum += r.energy_MJ;
//
//				} else if (r.energyTag.equals(SLTag.DIFFUSE)) {
//					diffuseEnergySum += r.energy_MJ;
//
//				}
//
//			}
//
//		}
//
//		direcEnergy_H_diffuseEnergy_H[0] = directEnergySum;
//		direcEnergy_H_diffuseEnergy_H[1] = diffuseEnergySum;
//
//		return direcEnergy_H_diffuseEnergy_H;
//	}
//
//	public double getTreeLeafAbsorbedDirectRadiationCoefficient() {
//		return treeLeafAbsorbedDirectRadiationCoefficient;
//	}
//
//	public double getTreeLeafAbsorbedDiffuseRadiationCoefficient() {
//		return treeLeafAbsorbedDiffuseRadiationCoefficient;
//	}

}
