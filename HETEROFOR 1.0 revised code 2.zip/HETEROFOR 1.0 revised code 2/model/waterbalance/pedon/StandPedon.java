package heterofor.model.waterbalance.pedon;

import java.util.ArrayList;
import java.util.Collection;

import heterofor.model.HetScene;
import heterofor.model.HetTree;

/**
 * A single list of soil horizons in a soil for a whole stand.
 * 
 * @author F. de Coligny - November 2019
 */
public class StandPedon extends Pedon {

	/**
	 * Constructor
	 */
	public StandPedon() {
		super();
	}

	/**
	 * Copy constructor, see getCopy ()
	 */
	protected StandPedon(StandPedon original) {
		super(original);
	}

	public StandPedon getPedonCopy() {
		return new StandPedon(this);
	}

	/**
	 * Convention: pedon id is -1 for a StandPedon, 0 for a RemainingPedon and
	 * treeId for a TreePedon.
	 */
	public int getPedonId() {
		return -1;
	}

	/**
	 * Returns a list of trees matching this pedon: all the scene's trees for a
	 * StandPedon, the single tree with same id matching a TreePedon and an
	 * empty list for a RemainingPedon.
	 */
	public Collection<HetTree> getTrees(HetScene scene) {
		return new ArrayList(scene.getTrees());
	}

	
	
}
