package heterofor.model.waterbalance.pedon;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import heterofor.model.HetScene;
import heterofor.model.HetTree;

/**
 * A single of soil horizons in a soil for a particular tree.
 * 
 * @author F. de Coligny - November 2019
 */
public class TreePedon extends Pedon {

	private int treeId;

	/**
	 * Constructor
	 */
	public TreePedon(int treeId) {
		super();
		this.treeId = treeId;
	}

	/**
	 * Copy constructor, see getCopy ()
	 */
	protected TreePedon(TreePedon original) {
		super(original);
		this.treeId = original.treeId;
	}

	public TreePedon getPedonCopy() {
		return new TreePedon(this);
	}

	public int getTreeId() {
		return treeId;
	}

	/**
	 * Convention: pedon id is -1 for a StandPedon, 0 for a RemainingPedon and
	 * treeId for a TreePedon.
	 */
	public int getPedonId() {
		return treeId;
	}

	/**
	 * Returns a list of trees matching this pedon: all the scene's trees for a
	 * StandPedon, the single tree with same id matching a TreePedon and an
	 * empty list for a RemainingPedon.
	 */
	public Collection<HetTree> getTrees(HetScene scene) {
		List<HetTree> list = new ArrayList<> ();
		// The pedonId is the id of the matching tree
		list.add((HetTree) scene.getTree(getPedonId ()));
		return list;
		
	}

}
