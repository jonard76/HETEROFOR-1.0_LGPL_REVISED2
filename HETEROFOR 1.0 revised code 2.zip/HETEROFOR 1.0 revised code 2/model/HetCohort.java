package heterofor.model;

import java.io.Serializable;

import capsis.lib.regeneration.RGCell;
import capsis.lib.regeneration.RGCohort;
import capsis.lib.regeneration.RGCohortSizeClass;
import capsis.lib.regeneration.RGModel;
import capsis.lib.regeneration.RGSpecies;
import capsis.lib.regeneration.RGStand;

/**
 * A regeneration cohort
 *
 * @author M. Jonard, B. Ryelandt, N. Donès, F. de Coligny - October 2018
 */
public class HetCohort extends RGCohort implements Serializable {

	/**
	 * Constructor
	 */
	public HetCohort(RGSpecies species, int year) {
		super(species, year);
	}

	/**
	 * Runs the growth process for all class sizes in this cohort.
	 */
	@Override
	public HetCohort understoreyGrowth() throws Exception {

		HetCohort newCohort = new HetCohort(species, year + 1);

		for (RGCohortSizeClass c : sizeClasses) {

			// fc+mj+fa-28.5.2019 warning: newClass.getCohort () == null until
			// newCohort.addSizeClass () below
			HetCohortSizeClass newClass = (HetCohortSizeClass) c.understoreyGrowth(this, cell);

			if (newClass.getNumber() > 0)
				newCohort.addSizeClass(newClass); // sets newClass.getCohort ()

		}

		return newCohort;
	}

	/**
	 * Evaluate if some cohortSize are to be recruited, process their
	 * recruitment and return the remaining size classes in a remaining cohort
	 * to be added in the cell.
	 */
	@Override
	public HetCohort recruitmentProcess(RGModel model, RGStand scene, RGCell cell) throws Exception {

		HetCohort remainingCohort = new HetCohort(getSpecies(), getYear());

		if (sizeClasses != null)
			for (RGCohortSizeClass c : sizeClasses) {

				// Recruitment test
				if (c.getHeight_m() > getSpecies().getHeightToTree()) {

					// The sizeClass is turned into adult trees
					((HetCohortSizeClass) c).recruit(this, (HetModel) model, (HetScene) scene, (HetCell) cell);

				} else {
					remainingCohort.addSizeClass(c);
				}
			}

		// if the cohort is empty (all was turned into adult trees), return null
		return remainingCohort.getNbClass() > 0 ? remainingCohort : null;
	}

	public HetSpecies getSpecies() {
		return (HetSpecies) species;
	}

	public String toString() {
		String nbClasses = "" + (sizeClasses == null ? 0 : sizeClasses.size());
		return "HetCohort, year:" + getYear() + " sizeClasses: " + nbClasses;
	}

}
