/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.model;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import heterofor.model.allometry.CrownToStemDiameterEstimation;
import heterofor.model.allometry.HeightGrowthFunction;
import heterofor.model.allometry.HetBarkProportionFunction;
import heterofor.model.allometry.HetBarkThicknessFunction;
import heterofor.model.allometry.HetFunction2Variables;
import heterofor.model.allometry.HetSapwoodArea;
import heterofor.model.allometry.HetSimpleFunction;
import heterofor.model.allometry.HetSixtyPcHeightRelativeGirth;
import heterofor.model.allometry.HetTenPcHeightGirth;
import heterofor.model.allometry.HetTreeHeightLigot;
import heterofor.model.allometry.InitBiomassAllometry4p;
import heterofor.model.allometry.LeafBiomassAllometry;
import heterofor.model.allometry.ParUseEfficiencyFunction;
import heterofor.model.allometry.PotentialModifiersHeightGrowth;
import heterofor.model.allometry.HetRadiationModifier;
import heterofor.model.allometry.HetVpdModifier;
import heterofor.model.allometry.HetSwcModifier;
import heterofor.model.phenology.HetPhenology;
import heterofor.model.phenology.HetPhenologyModel;
import heterofor.model.treechemistry.HetFoliarChemistryThresholds;
import heterofor.model.treechemistry.HetLitterChemistryDistribution;
import heterofor.model.treechemistry.HetLitterCompartment;
import heterofor.model.treechemistry.HetNutrientGrowthSensitivity;
import heterofor.model.treechemistry.HetTreeChemistryDistribution;
import heterofor.model.treechemistry.HetTreeCompartment;
import heterofor.model.treechemistry.HetTreeElement;
import jeeb.lib.util.Import;
import jeeb.lib.util.Log;
import jeeb.lib.util.Record;
import jeeb.lib.util.fileloader.FileLoader;

/**
 * A file loader for the Heterofor species file.
 *
 * @author F. de Coligny - April 2015
 */
public class HetSpeciesFileLoader extends FileLoader {

	public List<SpeciesLine> speciesLines;
	public List<TreeChemistryDistribution> treeChemistryDistributions;
	public List<FoliarChemistryThresholds> foliarChemistryThresholds;
	public List<LitterChemistryDistribution> litterChemistryDistributions;

	/**
	 * Constructor
	 */
	public HetSpeciesFileLoader() throws Exception {
		super();
	}

	/**
	 * Loads the species file and stores the species in the given map.
	 */
	public void load(String fileName, HetModel model, Map<Integer, HetSpecies> speciesMap) throws Exception {

		HetInitialParameters ip = model.getSettings();

		// 1. Load the file
		super.load(fileName);

		// 2. Clear the species/ set them in the map
		HetSpecies speciesSpecimen = null;

		try {
			speciesMap.clear();

			for (SpeciesLine spLine : speciesLines) {

				StringTokenizer st = new StringTokenizer(spLine.color, ",");
				int red = new Integer(st.nextToken()).intValue();
				int green = new Integer(st.nextToken()).intValue();
				int blue = new Integer(st.nextToken()).intValue();
				Color speciesColor = new Color(red, green, blue);

				String speciesNameFromCode;
				switch (spLine.code) {
//				case 1:
//					speciesNameFromCode = "quercus";
//					break;
//				case 2:
//					speciesNameFromCode = "fagus";
//					break;
//				case 3:
//					speciesNameFromCode = "carpinus";
//					break;
//				case 4:
//					speciesNameFromCode = "betulus";
//					break;
//				case 5:
//					speciesNameFromCode = "broadleaved";
//					break;
//				case 6:
//					speciesNameFromCode = "coniferous";
//					break;
				// fa-19.12.2018
				case 1:
					speciesNameFromCode = "broadleaved";
					break;
				case 2:
					speciesNameFromCode = "coniferous";
					break;
				case 3:
					speciesNameFromCode = "quercus";
					break;
				case 4:
					speciesNameFromCode = "fagus";
					break;
				case 5:
					speciesNameFromCode = "carpinus";
					break;
				case 6:
					speciesNameFromCode = "betulus";
					break;
				case 7:
					speciesNameFromCode = "picea";
					break;
				case 8:
					speciesNameFromCode = "pseudotsuga";
					break;
				case 9:
					speciesNameFromCode = "pinus";
					break;
				case 10:
					speciesNameFromCode = "abies";
					break;
				case 11:
					speciesNameFromCode = "acer";
					break;
				default:
					speciesNameFromCode = "broadleaved";
					System.out
							.println("HetSpeciesFileLoader.load() - unrecognized species (broadleaved have been used)");
					HetReporter.printInLog(Log.WARNING, "HetSpeciesFileLoader.load ()",
							"Unrecognized species code: " + spLine.code + " (broadleaved have been used)");
					break;
				}

				// fc+mj+fa-14.11.2017 Allowing NA for
				// initBranchBiomassAllometry and initStemBiomassAllometry
				// -> both functions are set to null and specific default code
				// will be used
				InitBiomassAllometry4p initBranchBiomassAllometry = null;
				InitBiomassAllometry4p initStemBiomassAllometry = null;
				if (spLine.initBranchBiomassAllometry.equals("NA") && spLine.initStemBiomassAllometry.equals("NA")) {
					// Keep null for both functions
				} else {
					// If one single NA or other error, an exception will be
					// reported
					initBranchBiomassAllometry = new InitBiomassAllometry4p(spLine.initBranchBiomassAllometry);
					initStemBiomassAllometry = new InitBiomassAllometry4p(spLine.initStemBiomassAllometry);
				}

				LeafBiomassAllometry leafBiomassAllometry = new LeafBiomassAllometry(spLine.leafBiomassAllometry);
				CrownToStemDiameterEstimation crownToStemDiameterEstimation = new CrownToStemDiameterEstimation(
						spLine.crownToStemDiameterEstimation);

				HetSapwoodArea sapwoodArea = new HetSapwoodArea(spLine.sapwoodArea);

				HetTreeHeightLigot treeHeight = new HetTreeHeightLigot(spLine.treeHeight);

				// fc-18.12.2014
				ParUseEfficiencyFunction parUseEfficiencyFunction = new ParUseEfficiencyFunction(
						spLine.parUseEfficiencyFunction);

				// fc+mj-29.4.2015
				HeightGrowthFunction iprfwHeightGrowthFunction = new HeightGrowthFunction(
						spLine.iprfwHeightGrowthFunction);
				HeightGrowthFunction baileuxHeightGrowthFunction = new HeightGrowthFunction(
						spLine.baileuxHeightGrowthFunction);
				PotentialModifiersHeightGrowth potentialModifiersHeightGrowth = new PotentialModifiersHeightGrowth(
						spLine.potentialModifiersHeightGrowth);

				HetSimpleFunction smallBranchFracFunction = HetSimpleFunction
						.getFunction(spLine.smallBranchFracFunction);
				HetSimpleFunction coarseBranchFracFunction = HetSimpleFunction
						.getFunction(spLine.coarseBranchFracFunction);
				HetSimpleFunction smallRootFracFunction = HetSimpleFunction.getFunction(spLine.smallRootFracFunction);
				HetSimpleFunction coarseRootFracFunction = HetSimpleFunction.getFunction(spLine.coarseRootFracFunction);
				HetNutrientGrowthSensitivity nutrientGrowthSensitivity = new HetNutrientGrowthSensitivity(
						spLine.nutrientGrowthSensitivity);

				// fc-mj-lw-8.9.2016
				HetFunction2Variables leaflessStemflowFunction = HetFunction2Variables
						.getFunction(spLine.leaflessStemFlowFunction);
				// fc+mj+lw-17.10.2016
				HetFunction2Variables leavedStemflowFunction = HetFunction2Variables
						.getFunction(spLine.leavedStemFlowFunction);

				// fc+mj+lw-18.10.2016
				HetBarkProportionFunction barkProportionFunction = new HetBarkProportionFunction(
						spLine.barkProportionFunction);
				HetBarkThicknessFunction barkThicknessFunction = new HetBarkThicknessFunction(
						spLine.barkThicknessFunction);

				HetRadiationModifier radiationModifier = new HetRadiationModifier(spLine.radiationModifier); // fa+mj-17.06.2019
				HetVpdModifier vpdModifier = new HetVpdModifier(spLine.vpdModifier); // fa+mj-17.06.2019
				HetSwcModifier swcModifier = new HetSwcModifier(spLine.swcModifier); // fa+mj-17.06.2019

				HetTenPcHeightGirth tenPcHeightGirth = new HetTenPcHeightGirth(spLine.tenPcHeightGirth);
				HetSixtyPcHeightRelativeGirth sixtyPcHeightRelativeGirth = new HetSixtyPcHeightRelativeGirth(
						spLine.sixtyPcHeightRelativeGirth);

				HetFunction2Variables seedlingHeightGrowth = HetFunction2Variables
						.getFunction(spLine.seedlingHeightGrowth);

				HetFunction2Variables seedlingHeightToDiameter = HetFunction2Variables
						.getFunction(spLine.seedlingHeightToDiameter);

				HetFunction2Variables seedlingDiameterToHeight = HetFunction2Variables
						.getFunction(spLine.seedlingDiameterToHeight);

				HetSimpleFunction seedlingD5ToD130 = HetSimpleFunction.getFunction(spLine.seedlingD5ToD130);

				HetFunction2Variables seedlingGetBiomass = HetFunction2Variables.getFunction(spLine.seedlingGetBiomass);

				HetSimpleFunction seedlingHeightToLAI = HetSimpleFunction.getFunction(spLine.seedlingHeightToLAI);

				HetSimpleFunction seedlingTransmittanceToSLA = HetSimpleFunction
						.getFunction(spLine.seedlingTransmittanceToSLA);

				HetSimpleFunction rootToShootRatioFunction = HetSimpleFunction
						.getFunction(spLine.rootToShootRatioFunction);

				HetSimpleFunction seedlingHeightToCrownRadius = HetSimpleFunction
						.getFunction(spLine.seedlingHeightToCrownRadius);

				HetSpecies species = new HetSpecies(speciesSpecimen, model, spLine.code, speciesNameFromCode,
						spLine.niceName, spLine.isConiferous, spLine.maxHeight, spLine.maxCrownRadius, speciesColor, spLine.crownForm,
						spLine.LADoption, spLine.Toption, spLine.LAD, spLine.LADup, spLine.LADdown, spLine.SLAtop,
						spLine.SLAbottom, spLine.UFLB, spLine.extinctionCoefficient, spLine.crownTransmissivity,
						spLine.meanLeafWidth, initBranchBiomassAllometry, initStemBiomassAllometry, leafBiomassAllometry,
						crownToStemDiameterEstimation, spLine.leafRelativeLossRate, spLine.leafRetranslocationRate,
						spLine.branchRelativeLossRate, spLine.branchLivingFraction, spLine.stemFormFactor,
						spLine.stemVolumetricMass, spLine.rootRelativeLossRate, spLine.rootToShootRatio,
						spLine.rootLivingFraction, spLine.fineRootRelativeLossRate, spLine.fineRootRetranslocationRate,
						spLine.defaultDeltaDbh, spLine.parUseEfficiency, spLine.sapwoodYearNumber,
						spLine.sapwoodToLeafAreaRatio, sapwoodArea, spLine.aboveBiomassAlpha, spLine.aboveBiomassBeta,
						spLine.aboveBiomassGamma, treeHeight, spLine.hlceHeightProportion, spLine.hcbHeightProportion,
						spLine.defoliationThreshold, spLine.deltaHlceMax, spLine.deltaHlceMin,
						spLine.crownOverlappingRatio, spLine.crownToStemDiameterShift, parUseEfficiencyFunction,
						spLine.sunlitPUE, spLine.shadedPUE, iprfwHeightGrowthFunction, baileuxHeightGrowthFunction,
						potentialModifiersHeightGrowth, smallBranchFracFunction, coarseBranchFracFunction,
						smallRootFracFunction, coarseRootFracFunction, spLine.maxFineRootToFoliageRatio,
						spLine.minFineRootToFoliageRatio, spLine.minSRL, spLine.maxSRL, spLine.rootVolumetricMass,
						spLine.hyphaToRootLengthRatio, spLine.specificHyphaLength, spLine.hyphaDiameter,
						nutrientGrowthSensitivity, spLine.leaflessRainfallThreshold, leaflessStemflowFunction,
						spLine.leavedRainfallThreshold, leavedStemflowFunction, spLine.foliageStorageCapacity_m2leaf,
						barkProportionFunction, barkThicknessFunction, spLine.barkBulkDensity,
						spLine.minBarkConductance, spLine.maxBarkConductance, spLine.referenceMaintenanceRespiration,
						spLine.nppToGppRatio_intercept, spLine.nppToGppRatio_slope,
						spLine.basicCanopyStomatalConductance, radiationModifier, vpdModifier, swcModifier,
						tenPcHeightGirth, sixtyPcHeightRelativeGirth, spLine.transpirationModifierCorrection,
						spLine.branchLitterP1, spLine.branchLitterP2, spLine.fruitLitterFallP1,
						spLine.fruitLitterFallP2, spLine.fruitProdMinDbh, spLine.heightToTree, seedlingHeightGrowth,
						seedlingHeightToDiameter, seedlingDiameterToHeight, seedlingD5ToD130, seedlingGetBiomass,
						seedlingHeightToLAI, seedlingTransmittanceToSLA, rootToShootRatioFunction,
						seedlingHeightToCrownRadius);

				speciesMap.put(spLine.code, species);

				if (speciesSpecimen == null)
					speciesSpecimen = species;

				// nb+lw-24.01.2017
				if (ip.phenologyActivated) {
					HetPhenologyModel phenologyModel = HetPhenologyModel.getModel(spLine.phenologyParameters);
					ip.addPhenology(species.getValue(), new HetPhenology(phenologyModel));
				}

			}

			// fc+mj-1.3.2016 Tree chemistry distribution from the species file

			// Species names list
			List<String> speciesNames = new ArrayList<>();
			for (HetSpecies sp : speciesMap.values()) {
				speciesNames.add(sp.getName());
			}

			// Init the tree chemistry distribution
			ip.treeChemistryDistribution = new HetTreeChemistryDistribution(speciesNames,
					HetTreeCompartment.compartmentTypes, HetTreeCompartment.compartmentNames,
					HetTreeElement.elementNames);

			for (TreeChemistryDistribution tcd : treeChemistryDistributions) {
				ip.treeChemistryDistribution.add(tcd.speciesName, tcd.compartmentType, tcd.compartmentName,
						tcd.elementName, tcd.distributionFunction);
			}

			// Init the foliar chemistry thresholds
			ip.foliarChemistryThresholds = new HetFoliarChemistryThresholds();

			for (FoliarChemistryThresholds fct : foliarChemistryThresholds) {
				ip.foliarChemistryThresholds.add(fct.speciesName, fct.elementName, fct.foliarDeficiencyConcentration,
						fct.foliarOptimumConcentration);
			}

			// Init the litter chemistry distribution
			ip.litterChemistryDistribution = new HetLitterChemistryDistribution(speciesNames,
					HetLitterCompartment.compartmentNames, HetTreeElement.elementNames);

			for (LitterChemistryDistribution tcd : litterChemistryDistributions) {
				ip.litterChemistryDistribution.add(tcd.speciesName, tcd.compartmentName, tcd.elementName,
						tcd.distributionFunction);
			}

		} catch (Exception e) {
			Log.println(Log.ERROR, "HetSpeciesFileLoader.load ()", "An error occurred during species file loading", e);
			throw new Exception(
					"An error occurred during species file loading: " + e + ", see the Log for further information", e);
		}

		// return report;
	}

	@Override
	protected void checks() throws Exception {
		// // Each treeId must be found only once in the file
		// Set<Integer> treeIds = new HashSet<Integer> ();
		// for (Line l : lines) {
		// if (treeIds.contains(l.treeId))
		// throw new Exception
		// ("Error in file: found a treeId several times: "+l.treeId);
		// }

	}

	// A tree chemistry distribution line in the file
	// fc+mj-1.3.2016
	@Import
	static public class TreeChemistryDistribution extends Record {

		public TreeChemistryDistribution() {
			super();
		}

		public TreeChemistryDistribution(String line) throws Exception {
			super(line);
		}

		public String speciesName; // a speciesName or ALL
		public String compartmentType; // a compartmentType or ALL
		public String compartmentName; // a compartmentName or ALL
		public String elementName; // an elementName or ALL
		public String distributionFunction; // an encoded function

	}

	// A foliar chemistry thresholds line in the file
	// fc+mj-2.3.2016
	@Import
	static public class FoliarChemistryThresholds extends Record {

		public FoliarChemistryThresholds() {
			super();
		}

		public FoliarChemistryThresholds(String line) throws Exception {
			super(line);
		}

		public String speciesName; // a speciesName
		public String elementName; // an elementName
		public double foliarDeficiencyConcentration; // mg/g
		public double foliarOptimumConcentration; // mg/g

	}

	// A litter chemistry distribution line in the file
	// fc+mj-3.3.2016
	@Import
	static public class LitterChemistryDistribution extends Record {

		public LitterChemistryDistribution() {
			super();
		}

		public LitterChemistryDistribution(String line) throws Exception {
			super(line);
		}

		public String speciesName; // a speciesName or ALL
		public String compartmentName; // a compartmentName or ALL
		public String elementName; // an elementName or ALL
		public String distributionFunction; // an encoded function

	}

	// A species line in the file
	@Import
	static public class SpeciesLine extends Record {

		public SpeciesLine() {
			super();
		}

		public SpeciesLine(String line) throws Exception {
			super(line);
		}

		// public String getSeparator () {return ";";} // to change default "\t"
		// separator
		public int code; // must be unique
		public String name; // must be unique
		public String niceName; // fc+mj-30.10.2015
		public boolean isConiferous; // fa-06.01.2020
		public double maxHeight;
		public double maxCrownRadius;
		public String color;
		public String crownForm;

		// fc+mj-30.4.2015
		public int LADoption; // 0:MEAN_LAD, 1:MEAN_SLA, 2:SLA_MODEL or
								// 3:QUERGUS_LAD
		public int Toption; // 0:MEAN_T, 1:QUERGUS_T

		public double LAD; // (m2/m3)
		public double LADup; // (m2/m3)
		public double LADdown; // (m2/m3)

		public double SLAtop; // (m2/kg)
		public double SLAbottom; // (m2/kg)

		public double UFLB; // ]0,1]

		public double extinctionCoefficient; // for turbid medium model
		public double crownTransmissivity; // for porous envelop model
		
		// fa-17.12.2019
		public double meanLeafWidth; // (m)

		// fc-26.11.2013 Added these species-level variables for M. Jonard
		public String initBranchBiomassAllometry;
		public String initStemBiomassAllometry;
		public String leafBiomassAllometry;
		public String crownToStemDiameterEstimation;

		public double leafRelativeLossRate;
		public double leafRetranslocationRate;

		public double branchRelativeLossRate;
		public double branchLivingFraction;

		public double stemFormFactor;
		public double stemVolumetricMass;

		public double rootRelativeLossRate;
		public double rootToShootRatio;
		public double rootLivingFraction;

		public double fineRootRelativeLossRate;
		public double fineRootRetranslocationRate;

		public double defaultDeltaDbh;
		public double parUseEfficiency;
		public int sapwoodYearNumber;
		public double sapwoodToLeafAreaRatio;
		public String sapwoodArea;

		public double aboveBiomassAlpha;
		public double aboveBiomassBeta;
		public double aboveBiomassGamma;

		public String treeHeight; // fc+mj+br-2.10.2018

		public double hlceHeightProportion;
		public double hcbHeightProportion;
		public double defoliationThreshold;

		public double deltaHlceMax;
		public double deltaHlceMin;

		public double crownOverlappingRatio;
		public double crownToStemDiameterShift;

		public String parUseEfficiencyFunction; // fc-18.12.2014

		public double sunlitPUE; // fc+mj-13.9.2017
		public double shadedPUE; // fc+mj-13.9.2017

		// fc+mj-29/4/2015
		public String iprfwHeightGrowthFunction;
		public String baileuxHeightGrowthFunction;
		// fc+mj-6.12.2016
		public String potentialModifiersHeightGrowth;

		// fc+mj-2.3.2016
		public String smallBranchFracFunction;
		public String coarseBranchFracFunction;
		public String smallRootFracFunction;
		public String coarseRootFracFunction;
		public double maxFineRootToFoliageRatio;
		public double minFineRootToFoliageRatio;
		public double minSRL; // m/g
		public double maxSRL; // m/g
		public double rootVolumetricMass; // kg/m3
		public double hyphaToRootLengthRatio;
		public double specificHyphaLength; // km/g
		public double hyphaDiameter; // micro m

		// e.g. nutrientGrowthSensitivity(1;0.8;0.1;0.15;0.25;0.4)
		public String nutrientGrowthSensitivity;

		// fc+mj+lw-8.9.2016 Additional params for water content process
		public double leaflessRainfallThreshold;
		public String leaflessStemFlowFunction;
		public double leavedRainfallThreshold; // fc+mj+lw-17.10.2016
		public String leavedStemFlowFunction; // fc+mj+lw-17.10.2016
		public double foliageStorageCapacity_m2leaf;

		public String barkProportionFunction; // fc+mj+lw-18.10.2016
		public String barkThicknessFunction; // fc+mj+lw-18.10.2016
		public double barkBulkDensity; // fc+mj+lw-18.10.2016

		public double minBarkConductance; // m/s
		public double maxBarkConductance; // m/s

		// nb+lw-20.01.2017
		public String phenologyParameters;

		public double referenceMaintenanceRespiration;
		public double nppToGppRatio_intercept; // fa-29.10.2018
		public double nppToGppRatio_slope; // fa-29.10.2018
		public double basicCanopyStomatalConductance; // m/s
		public String radiationModifier; // fa+mj-17.06.2019
		public String vpdModifier; // fa+mj-17.06.2019
		public String swcModifier; // fa+mj-17.06.2019

		// fc+mj+fa-14.11.2017
		public String tenPcHeightGirth;
		public String sixtyPcHeightRelativeGirth;

		public double transpirationModifierCorrection;

		public double branchLitterP1;
		public double branchLitterP2;
		public double fruitLitterFallP1;
		public double fruitLitterFallP2;
		public double fruitProdMinDbh; // cm

		public double heightToTree;
		public String seedlingHeightGrowth;
		public String seedlingHeightToDiameter;
		public String seedlingDiameterToHeight;
		public String seedlingD5ToD130;
		public String seedlingGetBiomass;
		public String seedlingHeightToLAI;
		public String seedlingTransmittanceToSLA;
		public String rootToShootRatioFunction;
		public String seedlingHeightToCrownRadius;

	}

}
