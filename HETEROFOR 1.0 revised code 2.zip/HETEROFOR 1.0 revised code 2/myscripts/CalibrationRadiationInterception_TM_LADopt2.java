/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.myscripts;

import heterofor.model.HetEvolutionParameters;
import heterofor.model.HetInitialParameters;
import heterofor.model.HetModel;
import heterofor.model.HetScene;
import heterofor.model.HetSpecies;
// import heterofor.model.HetSensor;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.FilenameFilter;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import jeeb.lib.util.Check;
import jeeb.lib.util.Log;
import capsis.app.C4Script;
import capsis.kernel.Project;
import capsis.kernel.Step;
import jeeb.lib.util.PathManager;
import jeeb.lib.util.StatusDispatcher;
import capsis.kernel.extensiontype.Intervener;
import capsis.lib.samsaralight.SLSensor;
import capsis.script.GScript;
import capsis.lib.samsaralight.SLModel;
import capsis.extension.intervener.*;
import gymnos.extension.intervener.*;
import capsis.extension.memorizer.DefaultMemorizer;


/**
 * A script for Heterofor. The script needs one parameter: a command file name (See
 * CommandFileReader_Test). To run the script from a windows terminal:
 *
 * <pre>
 * capsis -p script heterofor.myscripts.CommandScript <commandFileName>
 * </pre>
 *
 * @author F. Andre, November 2017
 */
public class CalibrationRadiationInterception_TM_LADopt2 {

	public static void main (String[] args) throws Exception {

		// args[0] is the name of this script: heterofor.myscripts.CommandScript (useless)
		// args[1] is workingDir
		// args[2] is exportFileName
		// args[3] is turbid medium activated (true or false)
		// args[4] is crownForm (Ec, Ed, Bc, Bd or M)
		// args[5] is ladOption
		// args[6-8] are extinction coefficients for oak, beech, carpinus
		// args[9-11] are SLAintercept for oak, beech, carpinus
		// args[12-14] are SLAdown for oak, beech, carpinus

		// Check the parameters
		List<String> argsList = Arrays.asList("workingDir", "exportFileName", "TM_activated", "crownForm", "ladOption", "ExtCoef_oak", "ExtCoef_beech", "ExtCoef_carpinus", "SLAintercept_oak", "SLAintercept_beech", "SLAintercept_carpinus", "SLAdown_oak", "SLAdown_beech", "SLAdown_carpinus");
		String errorMessage;
		boolean chkBoolean;
		int chkInt;
		double chkDouble;
		try {
			chkBoolean = Check.booleanValue(args[3]);
		} catch (Exception e) {
			errorMessage = "Wrong parameter, expecting boolean for " + argsList.get(3);
			StatusDispatcher.print(errorMessage);
		}
		try {
			chkInt = Check.intValue(args[5]);
		} catch (Exception e) {
			errorMessage = "Wrong parameter, expecting integer for " + argsList.get(5);
			StatusDispatcher.print(errorMessage);
		}
		for (int i = 6; i < args.length; i++){
			try {
				chkDouble = Check.doubleValue(args[i]);
			} catch (Exception e) {
				errorMessage = "Wrong parameter, expecting double for " + argsList.get(i);
				StatusDispatcher.print(errorMessage);
			}
		}


		String workingDir = args[1];
		String exportFileName = args[2];

		String inventoryDirectoryName = workingDir + "/data/heterofor/inventories/Ligot_Calib112017";
		File[] inventoryFiles = listInventoryFiles(inventoryDirectoryName);

		// Performs simulation for each inventory file
		int count = 0;
		System.out.println (inventoryDirectoryName);
		for(File inventoryFile : inventoryFiles) {
	        count++;
			runOneSimulation (inventoryFile, workingDir, exportFileName, count, args);
         }

		System.out.println ("wrote sensors energy in: " + exportFileName);
		System.out.println ("\n");
		System.out.println ("heterofor.myscripts.CallibrationRadiationInterception is over.");
		System.out.println ("\n");
		System.out.println ("######################################################################################");
		System.out.println ("\n");

	}

	/**
	 * Called for inventory file, runs one simulation and write the sensors in the export file.
	 */
	static private void runOneSimulation (File inventoryFile, String workingDir, String exportFileName, int count, String[] args) throws Exception {

		System.out.println ("Heterofor CalibrationScript, running simulation " + count
				+ " for the following inventory file:\n " + inventoryFile);


		C4Script s = new C4Script ("heterofor");

		// CrownForm, used to select the appropriate species file
		String crownForm_arg = args[4];

		// Simulation settings
		HetInitialParameters i = new HetInitialParameters ();
		i.speciesFileName = workingDir + "/data/heterofor/inventories/Ligot_Calib112017/heterofor_species_" + crownForm_arg + ".txt"; // specisFile specific for each crown form
		i.castaneaFileName = workingDir + "/data/heterofor/CastaneaSpecies3.txt"; //workingDir + "/" + line.castaneaFileName;
		i.inventoryFileName = inventoryFile.getPath();
		i.samsaraLightFileName = workingDir + "/data/heterofor/samsaralight/samsaraLight_settings_monthly.txt";
//		i.soilHorizonsFileName = workingDir + "/" + line.soilHorizonsFileName;
//		i.soilChemistryFileName = workingDir + "/" + line.soilChemistryFileName;
//		i.meteorologyFileName = workingDir + "/" + line.MeteorologyFileName;
		i.fineResolutionRadiativeBalanceActivated = false; //line.fineResolutionRadiativeBalanceActivated;
		i.radiationCalculationTimeStep = 3; //line.radiationCalculationTimeStep;
		i.phenologyActivated = false; //line.phenologyActivated;
		i.waterBalanceActivated = false; //line.waterBalanceActivated;
		i.waterBalance_treeLevelTranspiration = false; //line.waterBalance_treeLevelTranspiration;
		i.castaneaPhotosynthesisActivated = false; //line.castaneaPhotosynthesisActivated;
		i.pueEmpiricalMethod = true; //line.pueEmpiricalMethod;
		i.constantNppToGppRatio = true; //line.constantNppToGppRatio;
		i.mineralHorizonsTemperatureCalculationActivated = false; //line.mineralHorizonsTemperatureCalculationActivated;
		i.competitionAccountedForCrownGrowth = false; //line.competitionAccountedForGrowth;
		i.generalNutrientLimitation = false; //line.generalNutrientLimitation;
		i.nLimitation = false; //line.nLimitation;
		i.heightGrowthOption = "BAILEUX_SITE"; //line.heightGrowthOption; // "IPRFW", "BAILEUX_SITE", "POTENTIAL_MODIFIERS_HEIGHT_GROWTH"
		i.mortalityActivated = false; //line.mortalityActivated;


		// Init simulation
//		s.init (i);
		HetModel model = (HetModel) s.getModel ();
		i.buildInitScene(model); //  !!!!! crownForm of trees fixed at this stage from value in speciesFile !!!!!

		// Modify settings for optimized parameters
		boolean turbidMediumActivated_arg = Boolean.valueOf(args[3]);
		int LADoption_arg = Integer.valueOf(args[5]);

		i.samsaFileLoader.setTurbidMedium(turbidMediumActivated_arg);

		Map<Integer, HetSpecies> speciesMap = i.getSpeciesMap();
		for (int speciesId : speciesMap.keySet()) {

			speciesMap.get(speciesId).LADoption = LADoption_arg;
//			speciesMap.get(speciesId).setCrownForm(crownForm_arg); // crownForm is already set previously (buildInitScene), from speciesFile

			double[] extinctionCoefficient_arg = new double[3];
			extinctionCoefficient_arg[0] = Double.valueOf(args[6]);
			extinctionCoefficient_arg[1] = Double.valueOf(args[7]);
			extinctionCoefficient_arg[2] = Double.valueOf(args[8]);

			double[] slaIntercept_arg = new double[3];
			slaIntercept_arg[0] = Double.valueOf(args[9]);
			slaIntercept_arg[1] = Double.valueOf(args[10]);
			slaIntercept_arg[2] = Double.valueOf(args[11]);

			double[] slaDown_arg = new double[3];
			slaDown_arg[0] = Double.valueOf(args[12]);
			slaDown_arg[1] = Double.valueOf(args[13]);
			slaDown_arg[2] = Double.valueOf(args[14]);

			if (speciesId == 1) { // oak
				speciesMap.get(speciesId).extinctionCoefficient = extinctionCoefficient_arg[0];
				// fc+mj+br-1.10.2018 removed
//				speciesMap.get(speciesId).SLAintercept = slaIntercept_arg[0];
//				speciesMap.get(speciesId).SLAdown = slaDown_arg[0];

			} else if (speciesId == 3) { // carpinus
				speciesMap.get(speciesId).extinctionCoefficient = extinctionCoefficient_arg[2];
				// fc+mj+br-1.10.2018 removed
//				speciesMap.get(speciesId).SLAintercept = slaIntercept_arg[2];
//				speciesMap.get(speciesId).SLAdown = slaDown_arg[2];

			} else { // beech and others
				speciesMap.get(speciesId).extinctionCoefficient = extinctionCoefficient_arg[1];
				// fc+mj+br-1.10.2018 removed
//				speciesMap.get(speciesId).SLAintercept = slaIntercept_arg[1];
//				speciesMap.get(speciesId).SLAdown = slaDown_arg[1];
			}
		}

///////////		i.samsaFileLoader.setSensorLightOnly(true); // tmp: while bug is fixed in SL code

		// Create project
		String projectName = s.getClass ().getName ();
		Project project = s.createProject (projectName, model, i);
		try {
			s.setMemorizer (project, new DefaultMemorizer ());
		} catch (Exception e) {
			Log.println (Log.ERROR, "GScript2.init ()", "Memorizer error", e);
			throw new Exception ("Memorizer error", e);
		}

		HetScene initScene = (HetScene) s.getRoot ().getScene ();

		System.out.println ("Heterofor CalibrationScript, loaded " + initScene.getTrees ().size () + " trees");

		// Evolution
//		HetEvolutionParameters ep = new HetEvolutionParameters (2, trueThinningFileName);
//		Step step = model.processEvolution(s.getRoot(),ep);

		// Interventions
//		Intervener thinner;
/*
		// 1. Diameter, height or age class thinner
		int context = 2; //2: DBH, 3: Height, 4: Age
		float min = 20;
		float max = 50;
		thinner = new DHAThinner(context, min, max);
		step = s.runIntervener(thinner, step);
*/
/*
		// 2. Target basal area
		double targetGHA = 15; // m�/ha
		double type = 0.5; // [0,1], 0 for a from below thinning - 1 for a from above thinning
		boolean excludeTargetTrees = true;
		thinner = new GymnoGHAThinner2 (targetGHA, type, excludeTargetTrees);
		step = s.runIntervener(thinner, step);
*/

		// Exports results in text file
		int inventoryFileNameLength = i.inventoryFileName.length();
		String plotId = i.inventoryFileName.substring(inventoryFileNameLength - 6, inventoryFileNameLength - 4);
		String year = i.inventoryFileName.substring(inventoryFileNameLength - 14, inventoryFileNameLength - 10);
		try {
			File f = new File(exportFileName);
			if(f.exists() && count == 1) // delete existing exportFile if first simulation
				f.delete();

			BufferedWriter out = new BufferedWriter(new FileWriter(exportFileName, true)); // true to append at the end if file already exists

			if(count == 1){
				out.write("plotId" + "\t" + "year" + "\t" + "sensorId" + "\t" + "totalObs" + "\t" + "directObs" + "\t" + "diffuseObs" + "\t" + "totalPred" + "\t" + "directPred" + "\t" + "diffusePred");
				out.newLine();
			}

			for (SLSensor sensor : initScene.getSensors()) {
				out.write(plotId + "\t" + year+ "\t" + sensor.getId() + "\t" + sensor.get_measuredRelativeEnergy() + "\t" + sensor.get_measuredRelativeEnergyDirect() + "\t" + sensor.get_measuredRelativeEnergyDiffuse() + "\t" + sensor.getLightResult().get_horizontalRelativeEnergy() + "\t" + sensor.getLightResult().get_horizontalRelativeEnergyDirect() + "\t" + sensor.getLightResult().get_horizontalRelativeEnergyDiffuse());
				out.newLine();
			}

			out.close();
		} catch (Exception e) {
			Log.println(Log.ERROR, "HetModel.initializeModel ()", "Could not write in file: " + exportFileName, e);
		}


//		HetScene finalScene = (HetScene) step.getScene();

//		System.out.println("Heterofor CalibrationScript_Test, final scene has " + finalScene.getTrees().size() + " trees");

		// Close the project
		s.closeProject ();
	}

	static private File[] listInventoryFiles(String directoryPath) {
		File directory = null;
		File[] filePaths = null;
		try {
			directory = new File(directoryPath);

			// File name filter
			FilenameFilter fileNameFilter = new FilenameFilter() {

	            @Override
	            public boolean accept(File dir, String name) {
	               if(name.lastIndexOf('.')>0) {

	                  // get last index for '.' char
	                  int lastIndex = name.lastIndexOf('.');

	                  // get extension
	                  String str = name.substring(lastIndex);

	                  // match path name extension
	                  if(str.equals(".inv")) {
	                     return true;
	                  }
	               }

	               return false;
	            }
			};


			// returns pathnames for files and directory
	        filePaths = directory.listFiles(fileNameFilter);

		}
		catch(Exception e) {
			// if any error occurs
			e.printStackTrace();
		}
		return filePaths;

	}

}