/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.extension.modeltool.predictionassessmenttool;

import java.util.ArrayList;
import java.util.List;

/**
 * For a given girth class and a given species, this class allows to store in strings a set of values calculated
 * in the {@link PVOClassInc} class and to be printed in a floating table using the {@link PVOClassIncTableBuilder} class.
 * These calculated values are:
 * - the number of trees used for calculating the means of observed and simulated increases of a tree characteristic (girth,
 * basal area, height, ...) over the given girth class;
 * - the mean value of the observed increases of these tree characteristic values over the given girth class;
 * - the mean value of the simulated increases of these tree characteristic values over the given girth class.
 *
 * @author N. Beudez - November 2017
 */
public class PVOClassIncStore {

	/**
	 * The list of the simulated values.
	 */
	private List<Double> simulatedValuesList;

	/**
	 * The list of the observed values.
	 */
	private List<Double> observedValuesList;

	/**
	 * Mean of the simulated values.
	 */
	private double meanOfSimulatedValues;

	/**
	 * Mean of the observed values.
	 */
	private double meanOfObservedValues;

	/**
	 * The standard error of the simulated values.
	 */
	private double standardErrorOfSimulatedValues;

	/**
	 * The standard error of the observed values.
	 */
	private double standardErrorOfObservedValues;

	/**
	 * Constructor.
	 */
	public PVOClassIncStore() {

		// Creates empty lists.
		simulatedValuesList = new ArrayList<Double>();
		observedValuesList = new ArrayList<Double>();
	}

	/**
	 * Calculates the means and the standard errors of the lists of simulated and observed values.
	 *
	 * @throws Exception If the list of simulated and observed values do not have the same size or if this size is
	 * the same but equal to zero.
	 */
	public void calculate() throws Exception {

		// Gets the number of elements of the list of simulated values. It should be equal to the number of
		// elements of the list of observed values, an exception is sent if not.
		int numberOfElements = getNumberOfElements();

		// Nothing to do if the number of elements is 0.

		if (numberOfElements > 0) {

			// Means calculations.
			meanOfSimulatedValues = calculateArithmeticMean(simulatedValuesList);
			meanOfObservedValues = calculateArithmeticMean(observedValuesList);

			// Standard errors calculations.
			standardErrorOfSimulatedValues = calculateStandardError(simulatedValuesList, meanOfSimulatedValues);
			standardErrorOfObservedValues = calculateStandardError(observedValuesList, meanOfObservedValues);
		}
	}

	/**
	 * Calculates and returns the standard error of the elements of the given list whose arithmetic mean
	 * is also given.
	 * Be careful: this method does not calculate the arithmetic mean of the given list.
	 *
	 * @param list The list of elements.
	 * @param arithmeticMean The arithmetic mean of the elements of the list.
	 * @return The standard error of the elements of the given list.
	 */
	private double calculateStandardError(List<Double> list, double arithmeticMean) {

		int numberOfElements = list.size();

		return calculateStandardDeviation(list, arithmeticMean)/Math.sqrt(numberOfElements);
	}

	/**
	 * Calculates and returns the standard deviation of the elements of the given list whose arithmetic mean
	 * is also given.
	 * Be careful: this method does not calculate the arithmetic mean of the given list.
	 *
	 * @param list The list of elements.
	 * @param arithmeticMean The arithmetic mean of the elements of the list.
	 * @return The standard deviation of the elements of the given list.
	 */
	private double calculateStandardDeviation(List<Double> list, double arithmeticMean) {

		int numberOfElements = list.size();

		double variance = 0.0;
		for (double value : list) {
			variance += Math.pow(value-arithmeticMean, 2.0);
		}
		variance /= numberOfElements;

		return Math.sqrt(variance);
	}

	/**
	 * Calculates and returns the arithmetic mean of the elements of the given list.
	 *
	 * @param list The list of elements.
	 * @return The arithmetic mean of the elements of the given list.
	 */
	private double calculateArithmeticMean(List<Double> list) {

		int numberOfElements = list.size();

		double mean = 0.0;
		for (double value : list) {
			mean += value;
		}
		mean = mean/numberOfElements;

		return mean;
	}

	/**
	 * Returns the number of elements of the list of simulated values. The list of observed values should have
	 * the same number of elements. An exception is sent if these two lists do not have the same number of elements.
	 *
	 * @return The number of elements of the list of simulated values (should be equal to the number of elements
	 * of the list of observed values).
	 * @throws Exception If the list of simulated and observed values do not have the same number of elements.
	 */
	public int getNumberOfElements() throws Exception {

		if (simulatedValuesList.size() != observedValuesList.size()) {
			throw new Exception("The number of simulated and observed values are not the same.\n"
					+ "Number of simulated values: " + simulatedValuesList.size() + "\n"
					+ "Number of observed values: " + observedValuesList.size());
		}

		return simulatedValuesList.size();
	}

	/**
	 * Returns the list of the observed values.
	 *
	 * @return The list of the observed values.
	 */
	public List<Double> getObservedValuesList() {

		return observedValuesList;
	}

	/**
	 * Returns the list of the simulated values.
	 *
	 * @return The list of the simulated values.
	 */
	public List<Double> getSimulatedValuesList() {

		return simulatedValuesList;
	}

	/**
	 * Returns the mean of the observed values.
	 *
	 * @return The mean of the observed values.
	 */
	public double getMeanOfObservedValues() {

		return meanOfObservedValues;
	}

	/**
	 * Returns the mean of the simulated values.
	 *
	 * @return The mean of the simulated values.
	 */
	public double getMeanOfSimulatedValues() {

		return meanOfSimulatedValues;
	}

	/**
	 * Returns the standard error of the simulated values.
	 *
	 * @return The standard error of the simulated values.
	 */
	public double getStandardErrorOfSimulatedValues() {

		return standardErrorOfSimulatedValues;
	}

	/**
	 * Returns the standard error of the observed values.
	 *
	 * @return The standard error of the observed values.
	 */
	public double getStandardErrorOfObservedValues() {

		return standardErrorOfObservedValues;
	}
}
