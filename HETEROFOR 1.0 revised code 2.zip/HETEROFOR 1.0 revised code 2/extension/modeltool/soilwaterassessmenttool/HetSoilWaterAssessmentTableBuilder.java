/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.extension.modeltool.soilwaterassessmenttool;

import org.jfree.data.xy.XYSeriesCollection;

/**
 * This class allows to build a table containing the data of a XYSeriesCollection data set whose all series
 * have the same x-values.
 * Be careful: no check is done in this class so that it is the responsibility of the user to check that the
 * x-values of all the series in the data set are the same.
 *
 * @author N. Beudez - February 2019
 */
public class HetSoilWaterAssessmentTableBuilder {

	private final String separator = "\t";
	private final String newLine = "\n";

	// Number of lines if the dataMatrix 2-dimensional array
	private int numberOfLines;

	// Number of columns if the dataMatrix 2-dimensional array
	private int numberOfColumns;

	// Columns names (header of the table)
	private String columnsNames[];

	// 2-dimensional array containing the data of the XYSeriesCollection dataSet
	private String dataMatrix[][];

	/**
	 * Builds the table composed of the {@link #columnsNames} array (header of the table) and the
	 * {@link #dataMatrix} 2-dimensional array (the data of the table).
	 *
	 * @param dataSet The set of XYSeries in which x-values are common to all series.
	 * @param xName The name of the x-values (x-values are common to all the series)
	 * @param xUnit The unit of the x-values (x-values are common to all the series)
	 * @param yUnit The unit of the y-values
	 */
	public HetSoilWaterAssessmentTableBuilder(XYSeriesCollection dataSet, String xName, String xUnit, String yUnit) {

		// Calculates the number of series in the data set.
		int numberOfSeries = dataSet.getSeriesCount();

		// Calculates the number of columns: equal to the number of (x,y) series + 1 because
		// each (x,y) series is supposed to have the same x-values.
		numberOfColumns = numberOfSeries+1;

		// Calculates the number of lines. Considers the first series (series with id equal to 0) because
		// all series are supposed to have the same number of items.
		numberOfLines = dataSet.getSeries(0).getItemCount();

		// Creates array and matrix.
		columnsNames = new String[numberOfColumns];
		dataMatrix = new String[numberOfLines][numberOfColumns];

		// Fills in the first column (0-index) of the header.
		columnsNames[0] = xName + " (" + xUnit + ")";

		// Fills in the first column (0-index) of the matrix: it contains the x-values that
		// are common to all the series in data set.
		for (int i=0 ; i<dataSet.getSeries(0).getItemCount() ; ++i) {
			dataMatrix[i][0] = "" + dataSet.getSeries(0).getX(i);
		}

		// Fills in the following columns
		for (int j=0 ; j<dataSet.getSeriesCount() ; ++j) {

			// Number of items in the j-th series
			int numberOfItems = dataSet.getItemCount(j);

			columnsNames[j+1] = "" + dataSet.getSeriesKey(j) + " (" + yUnit + ")";

			for (int i=0 ; i<numberOfItems ; ++i) {

				Number y = dataSet.getY(j, i);

				if (y != null) {
					dataMatrix[i][j+1] = "" + y.doubleValue();
				} else {
					dataMatrix[i][j+1] = "NA";
				}
			}

		}

	}

	/**
	 * Returns the whole table in a single string, with tabs between columns and
	 * newline at each end of line.
	 */
	public String getTableInAString() {

		StringBuffer buffer = new StringBuffer();

		// Column headers
		for (int j=0 ; j<columnsNames.length ; ++j) {

			buffer.append(columnsNames[j]);
			buffer.append(separator);
		}

		buffer.append(newLine);

		// Matrix content
		for (int i=0 ; i<dataMatrix.length ; ++i) {

			for (int j=0 ; j<dataMatrix[i].length ; ++j) {

				String str = dataMatrix[i][j];
				if (str == null) str = "NA";

				buffer.append(str);
				buffer.append(separator);
			}

			buffer.append(newLine);
		}

		return buffer.toString();
	}

	/**
	 * Returns the columns separator used for building the table.
	 *
	 * @return The columns separator of the built table.
	 */
	public String getSeparator() {

		return separator;
	}

}
