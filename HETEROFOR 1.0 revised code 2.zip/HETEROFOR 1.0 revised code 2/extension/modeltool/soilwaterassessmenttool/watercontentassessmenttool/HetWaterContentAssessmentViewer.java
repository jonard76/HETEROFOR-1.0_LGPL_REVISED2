/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.extension.modeltool.soilwaterassessmenttool.watercontentassessmenttool;

import heterofor.extension.modeltool.soilwaterassessmenttool.HetSoilWaterAssessmentViewer;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Shape;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.AffineTransform;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JLabel;

import jeeb.lib.util.ColumnPanel;
import jeeb.lib.util.LinePanel;
import jeeb.lib.util.Log;
import jeeb.lib.util.MessageDialog;
import jeeb.lib.util.StatusDispatcher;
import jeeb.lib.util.Translator;
import jeeb.lib.util.task.Task;
import jeeb.lib.util.task.TaskManager;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

/**
 * This class allows to display the values of observed and simulated water contents for each horizon of the soil.
 * The horizons to take into account can be selected using the available check boxes.
 *
 * @author N. Beudez - October 2017
 */
public class HetWaterContentAssessmentViewer extends HetSoilWaterAssessmentViewer implements ActionListener {

	static {
		Translator.addBundle("heterofor.extension.modeltool.soilwaterassessmenttool.HetSoilWaterAssessmentTool");
	}

	// The water content assessment tool
	private HetWaterContentAssessmentTool tool;

	// List of the horizon ids contained in the observations file
	private List<Integer> observedHorizonIdList;

	// Map with key: horizon's id, value: corresponding checkbox
	private Map<Integer, JCheckBox> horizonIdCheckboxMap;

	// Graph part
	private JButton updateGraphButton;
	private JButton openFloatingTableButton;
	private ChartPanel chartPanel;

	/**
	 * Constructor.
	 *
	 * @param dataSet The set containing series of observed and simulated water content values
	 * @param observedHorizonIdList The list of the horizon ids contained in the observations file
	 * @param tool The reference to the water content assessment tool
	 */
	public HetWaterContentAssessmentViewer(XYSeriesCollection dataSet, List<Integer> observedHorizonIdList,
			HetWaterContentAssessmentTool tool) {

		// Initializations
		this.dataSet = dataSet;
		this.tool = tool;
		this.observedHorizonIdList = observedHorizonIdList;
		horizonIdCheckboxMap = new HashMap<Integer, JCheckBox>();

		createUI();
	}

	/**
	 * Creates the user interface.
	 */
	private void createUI() {

		ColumnPanel columnPanel = new ColumnPanel(8, 8);

		// Creates the label containing the name of the choosen observations file
		LinePanel observationFileNameLinePanel = new LinePanel();
		JLabel choosenObservationFileNameLabel = new JLabel(Translator.swap("HetSoilWaterAssessmentTool.observationFileName") + " : " + tool.getObservationFileName());
		observationFileNameLinePanel.add(choosenObservationFileNameLabel);
		observationFileNameLinePanel.addGlue();
		columnPanel.add(observationFileNameLinePanel);

		// Creates the chart: water content (observed and simulated values) over time per horizon
		JFreeChart chart = createXYLineChart(dataSet);
		chartPanel = new ChartPanel(chart);
		columnPanel.add(chartPanel);

		// Creates the horizons check boxes
		LinePanel horizonsLinePanel = new LinePanel(Translator.swap("HetWaterContentAssessmentViewer.choiceOfHorizons"), 2, 8);
		for (int horizonId : observedHorizonIdList) {
			JCheckBox horizonCheckBox = new JCheckBox(Translator.swap("HetWaterContentAssessmentViewer.horizon") + " " + horizonId);
			horizonCheckBox.setSelected(true);
			horizonIdCheckboxMap.put(horizonId, horizonCheckBox);
			horizonsLinePanel.add(horizonCheckBox);
		}
		updateGraphButton = new JButton(Translator.swap("HetWaterContentAssessmentViewer.updateGraph"));
		updateGraphButton.addActionListener(this);
		horizonsLinePanel.add(updateGraphButton);
		horizonsLinePanel.addGlue();
		columnPanel.add(horizonsLinePanel);

		// Creates the button allowing to see the values of the chart in a floating table
		LinePanel createFloatingTableLinePanel = new LinePanel();
		openFloatingTableButton = new JButton(Translator.swap("HetSoilWaterAssessmentTool.seeResultsInAFloatingTable"));
		openFloatingTableButton.addActionListener(this);
		createFloatingTableLinePanel.add(openFloatingTableButton);
		createFloatingTableLinePanel.addGlue();
		columnPanel.add(createFloatingTableLinePanel);
		columnPanel.addStrut0();

		// Adds the column panel in the north of the viewer panel. The BorderLayout.NORTH layout is chosen
		// in order the free space below the "Update graph" button can grow if the dialog box is enlarged
		// manually by the user.
		this.setLayout(new BorderLayout());
		this.add(columnPanel, BorderLayout.NORTH);
	}

	/**
	 * Creates a XY line chart given the data set.
	 *
	 * @param dataSet The set containing series of observed and simulated water content values
	 */
	private JFreeChart createXYLineChart(XYSeriesCollection dataSet) {

		// Creates chart
		JFreeChart chart = ChartFactory.createXYLineChart(
				   Translator.swap("HetWaterContentAssessmentViewer.graphTitle"), // title
				   Translator.swap("HetWaterContentAssessmentViewer.graphXAxisLabel"), // x-axis Label
				   Translator.swap("HetWaterContentAssessmentViewer.graphYAxisLabel"), // y-axis Label
				   dataSet, // dataset
				   PlotOrientation.VERTICAL, // plot orientation
				   true, // show legend
				   false, // configure chart to generate tool tips ?
				   false // configure chart to generate URLs ?
				);

		// Customizes renderer: displays the points of curves with a smaller size
		XYPlot plot = chart.getXYPlot();

		XYLineAndShapeRenderer renderer = new XYLineAndShapeRenderer() {

			/**
			 * Shape scaling (dynamic override)
			 */
			public Shape getItemShape(int row, int column) {

				Shape shape = super.getItemShape(row, column);

				double scale = 0.5;
				AffineTransform t = new AffineTransform();
				t.scale(scale, scale);

				Shape newShape = t.createTransformedShape(shape);

				return newShape;
			}

		};

		// Fixes colors in the case of a unique horizon (it means 2 series in the data set: a series for the
		// observed values and a series for the simulated values).
		// By default, observed values are displayed in red and simulated values are displayed in blue.
		if (dataSet.getSeries().size() == 2) {
			renderer.setSeriesPaint(0, Color.BLUE); // series #0: observed values
			renderer.setSeriesPaint(1, Color.RED);  // series #1: simulated values
		}

		plot.setRenderer(renderer);

		return chart;
	}

	/**
	 * Updates the current graph: only data from the selected horizons check boxes are displayed.
	 */
	private void updateGraph() {

		// Creates the data set containing for each selected horizon:
		// - a series of observed water content values per horizon
		// - a series of simulated water content values per horizon
		XYSeriesCollection dataSet = new XYSeriesCollection();

		// Creates a task
		Task<Object, Void> task = new Task<Object, Void>(Translator.swap("HetWaterContentAssessmentViewer.updateGraphOfObservedAndSimulatedWaterContentValues")) {

			@Override
			protected void doFirstInEDT() {

				// Deletes existing message in the left part of the status panel
				StatusDispatcher.print("");
			}

			@Override
			protected Object doInWorker() {

				// Writes in the right part of the status panel
				StatusDispatcher.print(Translator.swap("HetWaterContentAssessmentViewer.graphUpdateInProgress"));

				for (int horizonId : observedHorizonIdList) {

					// If checkbox corresponding to horizon with id = horizonId is selected
					if (horizonIdCheckboxMap.get(horizonId).isSelected()) {

						XYSeries observedWaterContentSeries = new XYSeries(Translator.swap("HetWaterContentAssessmentTool.observedWaterContentForHorizon")
																	+ " " + horizonId);
						XYSeries simulatedWaterContentSeries = new XYSeries(Translator.swap("HetWaterContentAssessmentTool.simulatedWaterContentForHorizon")
																	+ " " + horizonId);

						dataSet.addSeries(observedWaterContentSeries);
						dataSet.addSeries(simulatedWaterContentSeries);

						// Fills in the series of observed and simulated water content values
						tool.fillInSeriesOfObservedAndSimulatedWaterContentValues(observedWaterContentSeries,
								simulatedWaterContentSeries, horizonId);
					}
				}

				// Creates a new chart and replaces the existing one
				JFreeChart chart = createXYLineChart(dataSet);

				return chart;
			}

			@Override
			protected void doInEDTafterWorker() {

				JFreeChart chart;
				try {
					chart = (JFreeChart) get();
					chartPanel.setChart(chart);

					// Writes in the left part of the status panel
					// TODO: to be improved. Indeed this message sometimes appears before the viewer is displayed.
					StatusDispatcher.print(Translator.swap("HetWaterContentAssessmentViewer.graphUpdateTerminated"));

				} catch (InterruptedException | ExecutionException e) {

					Log.println(Log.ERROR, "HetWaterContentAssessmentViewer.updateGraph()",
							"Problem occurs when updating observed/simulated data curves", e);
					MessageDialog.print(this, e.getMessage());
				}
			}
		};

		// Allows to see a moving bar in the progress bar instead of a growing percentage
		task.setIndeterminate();

		// Executes the created task
		TaskManager.getInstance().add(task);
	}

	/**
	 * From ActionListener interface.
	 */
	@Override
	public void actionPerformed(ActionEvent evt) {

		if (evt.getSource().equals(updateGraphButton)) {
			updateGraph();
		}

		if (evt.getSource().equals(openFloatingTableButton)) {
			openFloatingTableAction(Translator.swap("HetWaterContentAssessmentViewer.tableTitle"),
									Translator.swap("HetWaterContentAssessmentViewer.xName"),
									Translator.swap("HetWaterContentAssessmentViewer.xUnit"),
									Translator.swap("HetWaterContentAssessmentViewer.yUnit"));
		}
	}
}
