/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.extension.dataextractor;

import heterofor.model.HetModel;
import heterofor.model.HetScene;
import heterofor.model.HetTree;
import jeeb.lib.util.Translator;
import capsis.extension.dataextractor.superclass.DETimeYsTrees;
import capsis.kernel.GModel;
import capsis.kernel.GScene;

/**
 * A graph 'biomass for 5 compartments' over time for a given list of trees.
 *
 * @author F. de Coligny, M. Jonard - November 2013
 */

public class DETimeBiomass extends DETimeYsTrees {

	static {
		Translator.addBundle ("heterofor.extension.dataextractor.DELabels");
	}

	// nb-13.08.2018
	//public static final String NAME = "DETimeBiomass";
	//public static final String DESCRIPTION = "DETimeBiomass.description";
	//public static final String AUTHOR = "F. de Coligny, M. Jonard";
	//public static final String VERSION = "1.0";


	/**
	 * Extension dynamic compatibility mechanism. This matchwith method checks
	 * if the extension can deal (i.e. is compatible) with the referent.
	 */
	static public boolean matchWith (Object referent) {
		// compatible with HetModel only
		return referent instanceof HetModel;
	}

	@Override
	public String getName() {
		return Translator.swap("DETimeBiomass.name");
	}

	@Override
	public String getAuthor() {
		return "F. de Coligny, M. Jonard";
	}

	@Override
	public String getDescription() {
		return Translator.swap("DETimeBiomass.description");
	}

	@Override
	public String getVersion() {
		return "1.0";
	}

	@Override
	public String[] getYAxisVariableNames () {
		// the names of the variables
		return new String[] {Translator.swap ("leafBiomass"), Translator.swap ("branchBiomass"),
				Translator.swap ("stemBiomass"), Translator.swap ("rootBiomass"), Translator.swap ("fineRootBiomass")};
	}

	/**
	 * Returns the value for the 'i'th variable of the tree 'treeId'.
	 */
	@Override
	protected Number getValue (GModel m, GScene scene, int treeId, int date, int i) {
		HetScene sc = (HetScene) scene;

		HetTree t = (HetTree) sc.getTree (treeId);

		if (i <= 0) {
			return t.getLeafBiomass_kgC ();
		} else if (i == 1) {
			return t.getBranchBiomass_kgC ();
		} else if (i == 2) {
			return t.getStemBiomass_kgC ();
		} else if (i == 3) {
			return t.getRootBiomass_kgC ();
		} else if (i == 4) {
			return t.getFineRootBiomass_kgC ();
		} else {
			return 0;
		}

	}

}