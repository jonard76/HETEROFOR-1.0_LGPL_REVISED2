/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */
package heterofor.extension.ioformat;

import heterofor.model.HetInitialParameters;
import heterofor.model.HetModel;
import heterofor.model.HetScene;
import heterofor.model.HetSpecies;
import heterofor.model.phenology.HetPhenology;
import heterofor.model.phenology.HetPhenologyDate;

import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.Vector;

import jeeb.lib.util.Translator;
import capsis.kernel.GModel;
import capsis.kernel.GScene;
import capsis.kernel.Step;
import capsis.util.StandRecordSet;

/**
 * Exports the phenological dates over time for each species. Phenological dates are:
 * - t1_forcingStartingDate
 * - t2a_standBudburstStartingDate
 * - t2b_averageTreeBudburstDate
 * - t2c_completeLeafDevelopmentDate
 * - t4a_yellowingStartingDate
 * - t4b_yellowingEndingDate
 * - t5a_fallingStartingDate
 * - t5b_fallingEndingDate
 * See @link{heterofor.model.phenology.HetPhenology} class for description of these phenological dates.
 *
 * @author N. Beudez - June 2017
 */
public class HetPhenologicalDatesExport extends StandRecordSet {

	static {
		Translator.addBundle("heterofor.extension.ioformat.ExportLabels");
	}

	// Extension properties
	// nb-13.08.2018
	//public static String NAME = Translator.swap("HetPhenologicalDatesExport");
	//public static String AUTHOR = "N. Beudez";
	//public static String VERSION = "1.0";
	//public static String DESCRIPTION = Translator.swap("HetPhenologicalDatesExport.description");

	private static final String TAB = "\t";
	private static final String DATE_FORMAT = "dd/mm/yyyy";
	private static final String NOT_AVAILABLE = "NA";

	/**
	 * Constructor
	 */
	public HetPhenologicalDatesExport() {

		super();
		// Do not write the standard header lines in the output file
		setHeaderEnabled(false);
	}

	/**
	 * Extension dynamic compatibility mechanism. This matchWith method checks
	 * if the extension can deal (i.e. is compatible) with the referent.
	 */
	static public boolean matchWith(Object referent) {

		return referent instanceof HetModel;
	}

	@Override
	public String getName() {
		return Translator.swap("HetPhenologicalDatesExport.name");
	}

	@Override
	public String getAuthor() {
		return "N. Beudez";
	}

	@Override
	public String getDescription() {
		return Translator.swap("HetPhenologicalDatesExport.description");
	}

	@Override
	public String getVersion() {
		return "1.0";
	}

	/**
	 * Export: turns the given Scene into a collection of records. In script
	 * mode, save (fileName) must be called after.
	 */
	@Override
	public void createRecordSet(GScene s) throws Exception {

		HetScene scene = (HetScene) s;
		super.createRecordSet(scene); // deals with RecordSet's source

		// Custom headers
		add(new CommentRecord("Heterofor scene export (HetPhenologicalDatesExport) at " + new Date()));
		add(new EmptyRecord());

		String lineHeader = "year" + TAB + "speciesName"
								+ TAB + "t1_forcingStartingDate (" + DATE_FORMAT + ")"
								+ TAB + "t2a_standBudburstStartingDate (" + DATE_FORMAT + ")"
								+ TAB + "t2b_averageTreeBudburstDate (" + DATE_FORMAT + ")"
								+ TAB + "t2c_completeLeafDevelopmentDate (" + DATE_FORMAT + ")"
								+ TAB + "t4a_yellowingStartingDate (" + DATE_FORMAT + ")"
								+ TAB + "t5a_fallingStartingDate (" + DATE_FORMAT + ")"
								+ TAB + "t4b_yellowingEndingDate (" + DATE_FORMAT + ")"
								+ TAB + "t5b_fallingEndingDate (" + DATE_FORMAT + ")";

		// Tree line header
		add(new CommentRecord(lineHeader));

		writeLines((HetScene) s);
	}

	/**
	 * Writes a line for each year and each species from initial scene to current scene.
	 * @param scene The reference to the current scene
	 */
	private void writeLines(HetScene scene) {

		HetInitialParameters ip = (HetInitialParameters) scene.getStep().getProject().getModel().getSettings();

		// Retrieve Steps from root to reference step
		Step step = scene.getStep();
		Vector steps = step.getProject().getStepsFromRoot(step);
		Iterator iterator = steps.iterator();

		// Loop on steps
		while (iterator.hasNext()) {

			Step s = (Step) iterator.next();
			HetScene sc = (HetScene) s.getScene();
			int year = sc.getDate();

			Collection<HetSpecies> speciesCollection = ip.speciesMap.values();

			for (HetSpecies species : speciesCollection) {

				String str = Integer.toString(year);

				String speciesName = species.getName();
				str += TAB + speciesName;

				int speciesId = species.getValue();
				HetPhenology phenology = sc.getPhenologyMap().get(speciesId);

				HetPhenologyDate t1_forcingStartingDate = phenology.getT1_forcingStartingDate();
				HetPhenologyDate t2a_standBudburstStartingDate = phenology.getT2a_standBudburstStartingDate();
				HetPhenologyDate t2b_averageTreeBudburstDate = phenology.getT2b_averageTreeBudburstDate();
				HetPhenologyDate t2c_completeLeafDevelopmentDate = phenology.getT2c_completeLeafDevelopmentDate();
				HetPhenologyDate t4a_yellowingStartingDate = phenology.getT4a_yellowingStartingDate();
				HetPhenologyDate t4b_yellowingEndingDate = phenology.getT4b_yellowingEndingDate();
				HetPhenologyDate t5a_fallingStartingDate = phenology.getT5a_fallingStartingDate();
				HetPhenologyDate t5b_fallingEndingDate = phenology.getT5b_fallingEndingDate();

				String t1_forcingStartingDateStr;
				String t2a_standBudburstStartingDateStr;
				String t2b_averageTreeBudburstDateStr;
				String t2c_completeLeafDevelopmentDateStr;
				String t4a_yellowingStartingDateStr;
				String t4b_yellowingEndingDateStr;
				String t5a_fallingStartingDateStr;
				String t5b_fallingEndingDateStr;

				if (t1_forcingStartingDate.isSet()) {
					t1_forcingStartingDateStr = HetPhenologyDate.getYearMonthDay(t1_forcingStartingDate.getYear(), t1_forcingStartingDate.getDoy());
				} else {
					t1_forcingStartingDateStr = NOT_AVAILABLE;
				}

				if (t2a_standBudburstStartingDate.isSet()) {
					t2a_standBudburstStartingDateStr = HetPhenologyDate.getYearMonthDay(t2a_standBudburstStartingDate.getYear(), t2a_standBudburstStartingDate.getDoy());
				} else {
					t2a_standBudburstStartingDateStr = NOT_AVAILABLE;
				}

				if (t2b_averageTreeBudburstDate.isSet()) {
					t2b_averageTreeBudburstDateStr = HetPhenologyDate.getYearMonthDay(t2b_averageTreeBudburstDate.getYear(), t2b_averageTreeBudburstDate.getDoy());
				} else {
					t2b_averageTreeBudburstDateStr = NOT_AVAILABLE;
				}

				if (t2c_completeLeafDevelopmentDate.isSet()) {
					t2c_completeLeafDevelopmentDateStr = HetPhenologyDate.getYearMonthDay(t2c_completeLeafDevelopmentDate.getYear(), t2c_completeLeafDevelopmentDate.getDoy());
				} else {
					t2c_completeLeafDevelopmentDateStr = NOT_AVAILABLE;
				}

				if (t4a_yellowingStartingDate.isSet()) {
					t4a_yellowingStartingDateStr = HetPhenologyDate.getYearMonthDay(t4a_yellowingStartingDate.getYear(), t4a_yellowingStartingDate.getDoy());
				} else {
					t4a_yellowingStartingDateStr = NOT_AVAILABLE;
				}

				if (t4b_yellowingEndingDate.isSet()) {
					t4b_yellowingEndingDateStr = HetPhenologyDate.getYearMonthDay(t4b_yellowingEndingDate.getYear(), t4b_yellowingEndingDate.getDoy());
				} else {
					t4b_yellowingEndingDateStr = NOT_AVAILABLE;
				}

				if (t5a_fallingStartingDate.isSet()) {
					t5a_fallingStartingDateStr = HetPhenologyDate.getYearMonthDay(t5a_fallingStartingDate.getYear(), t5a_fallingStartingDate.getDoy());
				} else {
					t5a_fallingStartingDateStr = NOT_AVAILABLE;
				}

				if (t5b_fallingEndingDate.isSet()) {
					t5b_fallingEndingDateStr = HetPhenologyDate.getYearMonthDay(t5b_fallingEndingDate.getYear(), t5b_fallingEndingDate.getDoy());
				} else {
					t5b_fallingEndingDateStr = NOT_AVAILABLE;
				}

				str += TAB + t1_forcingStartingDateStr + TAB + t2a_standBudburstStartingDateStr + TAB + t2b_averageTreeBudburstDateStr
						+ TAB + t2c_completeLeafDevelopmentDateStr + TAB + t4a_yellowingStartingDateStr + TAB + t5a_fallingStartingDateStr
						+ TAB + t4b_yellowingEndingDateStr + TAB + t5b_fallingEndingDateStr;

				add(new FreeRecord(str));
			}
		}

	}

	/**
	 * Importation is not implemented here
	 */
	@Override
	public GScene load(GModel model) throws Exception {
		return null;
	}

}
