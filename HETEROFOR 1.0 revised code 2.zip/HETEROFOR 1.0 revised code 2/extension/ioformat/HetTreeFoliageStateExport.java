/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.extension.ioformat;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;

import capsis.defaulttype.Tree;
import capsis.kernel.GModel;
import capsis.kernel.GScene;
import capsis.kernel.Step;
import capsis.util.Calendar;
import capsis.util.GTreeIdComparator;
import capsis.util.StandRecordSet;
import heterofor.model.HetModel;
import heterofor.model.HetScene;
import heterofor.model.HetTree;
import heterofor.model.phenology.HetPhenologyDate;
import jeeb.lib.util.Translator;

/**
 * Exports the daily evolution of the foliage state over time per tree, from initial year to current year. 
 * The foliage state is composed of:
 * - the proportion of green leaves compared to the level of maximum development (greenProp coefficient,
 * see {@link heterofor.model.phenology.HetPhenology#getDoyGreenPropMap()});
 * - the proportion of leaf area compared to the level of maximum development (ladProp coefficient, 
 *   see {@link heterofor.model.phenology.HetPhenology#getDoyLadPropMap()});
 * - the leaf area of the tree;
 * - the leaf area of the species.
 *
 * @author N. Beudez - November 2019
 */
public class HetTreeFoliageStateExport extends StandRecordSet {

	static {
		Translator.addBundle("heterofor.extension.ioformat.ExportLabels");
	}
	
	/**
	 * Separator.
	 */
	private static final String TAB = "\t";

	/**
	 * Constructor.
	 */
	public HetTreeFoliageStateExport() {

		super();

		// Do not writes the standard header lines in the output file.
		setHeaderEnabled(false);
	}

	/**
	 * Extension dynamic compatibility mechanism. This matchWith method checks
	 * if the extension can deal (i.e. is compatible) with the referent.
	 */
	static public boolean matchWith(Object referent) {

		boolean matchWith = false;

		if (referent instanceof HetModel) {
		
			HetModel model = (HetModel) referent;
			matchWith = model.getSettings().phenologyAtTreeLevel;
		}

		return matchWith;
	}

	@Override
	public String getName() {
		return Translator.swap("HetTreeFoliageStateExport.name");
	}

	@Override
	public String getAuthor() {
		return "N. Beudez";
	}

	@Override
	public String getDescription() {
		return Translator.swap("HetTreeFoliageStateExport.description");
	}

	@Override
	public String getVersion() {
		return "1.0";
	}

	/**
	 * Export: turns the given Scene into a collection of records. In script
	 * mode, save (fileName) must be called after.
	 */
	@Override
	public void createRecordSet(GScene s) throws Exception {

		HetScene scene = (HetScene) s;
		super.createRecordSet(scene); // deals with RecordSet's source

		// Custom headers
		add(new CommentRecord("Heterofor scene export (HetTreeFoliageStateExport) at " + new Date()));
		add(new EmptyRecord());

		String lineHeader = "date (dd/mm/yyyy)" + TAB + "dayOfYear" + TAB + "treeId" + TAB +  "ladProp ([0,1])" 
								+ TAB + "greenProp ([0,1])" + TAB + "leafAreaTree (m2)" + TAB + "leafAreaSpecies (m2)";		

		// Tree line header.
		add(new CommentRecord(lineHeader));

		writeLines((HetScene) s);
	}

	/**
	 * Writes a line for each day from initial scene to current scene.
	 * @param scene The reference to the current scene
	 */
	private void writeLines(HetScene scene) {

		// Retrieve steps from root to reference step.
		Step step = scene.getStep();
		Vector steps = step.getProject().getStepsFromRoot(step);
		Iterator iterator = steps.iterator();

		// Loop on steps
		while (iterator.hasNext()) {

			Step s = (Step) iterator.next();
			HetScene sc = (HetScene) s.getScene();

			int year = sc.getDate();

			int nbOfDaysInyear;

			if (Calendar.isLeap(year)) {
				nbOfDaysInyear = 366;
			} else {
				nbOfDaysInyear = 365;
			}

			// Loop on days.
			for (int doy = 1; doy <= nbOfDaysInyear; doy++) {

				String date = HetPhenologyDate.getYearMonthDay(year, doy); // "dd/mm/year"

				Collection<? extends Tree> treeCollection = sc.getTrees();
				List<Tree> treeList = new ArrayList<Tree>(treeCollection);
				Collections.sort(treeList, new GTreeIdComparator(true));
				
				for (Tree t : treeList) {

					String str = date + TAB + doy;
					
					HetTree tree = (HetTree) t;
					int treeId = tree.getId();
					
					double ladProp = sc.getLadProportion(treeId, doy, sc.getPhenologyMap());				
					double greenProp = sc.getGreenProportion(treeId, doy, sc.getPhenologyMap());
					double leafAreaTree = tree.getLeafArea();
					int speciesId = tree.getSpecies().getId();
//					double leafAreaSpecies = tree.getSpecies().leafArea_sp;
					double leafAreaSpecies = scene.getSpeciesLeafAreaMap().get(speciesId); // fa-17.12.2019: moved species leaf area from HetSpecies to HetScene

					str += TAB + treeId + TAB + ladProp + TAB + greenProp + TAB + leafAreaTree + TAB + leafAreaSpecies;
					
					add(new FreeRecord(str));
				}

			}
		}
		
	}

	/**
	 * Importation is not implemented here
	 */
	@Override
	public GScene load(GModel model) throws Exception {
		return null;
	}

}
