/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.extension.ioformat;

import java.util.Date;

import capsis.kernel.GModel;
import capsis.kernel.GScene;
import capsis.kernel.Project;
import capsis.kernel.Step;
import capsis.util.StandRecordSet;
import heterofor.model.HetModel;
import heterofor.model.HetScene;
import heterofor.model.soil.HetHorizon;
import heterofor.model.soil.HetSoilInterface;
import heterofor.model.soilchemistry.HetMineral;
import jeeb.lib.util.Import;
import jeeb.lib.util.Log;
import jeeb.lib.util.Record;
import jeeb.lib.util.Translator;

/**
 * HetNutrientCyclingExport export for Heterofor.
 *
 * @author F. de Coligny - October 2015
 */
public class HetNutrientCyclingExport extends StandRecordSet {

	static {
		Translator.addBundle("heterofor.extension.ioformat.ExportLabels");
	}

	// Extension properties
	// nb-13.08.2018
	//static public String NAME = Translator.swap("HetNutrientCyclingExport");
	//static public String AUTHOR = "F. de Coligny, M. Jonard";
	//static public String VERSION = "1.0";
	//static public String DESCRIPTION = Translator.swap("HetNutrientCyclingExport.description");

	// A tree line in the file
	@Import
	static public class Line extends Record {

		public Line() {
			super();
		}

		public Line(String line) throws Exception {
			super(line);
		}

		// public String getSeparator () {return ";";} // to change default "\t"
		// separator

		public int date;
		public int horizonId;
		public String soilCompartment;
		public String eltName;
		public double concentration;

	}

	/**
	 * Constructor
	 */
	public HetNutrientCyclingExport() {
		super();
		// Do not write the standard header lines in the output file
		setHeaderEnabled(false);
	}

	/**
	 * Extension dynamic compatibility mechanism. This matchWith method checks
	 * if the extension can deal (i.e. is compatible) with the referent.
	 */
	static public boolean matchWith(Object referent) {
		try {
			if (!(referent instanceof HetModel)) {
				return false;
			}
			
			// fc+mj+fa-19.11.2019 Compatible only if HetSoil (not with a HetDiscreteSoil)
			HetModel model = (HetModel) referent;
			Step root = (Step) model.getProject ().getRoot ();
			HetSoilInterface soil = ((HetScene) root.getScene ()).getSoil ();
			return !soil.isDiscreteSoil();
//			return soil instanceof HetSoil;

		} catch (Exception e) {
			Log.println(Log.ERROR, "HetNutrientCyclingExport.matchWith ()", "Error in matchWith () (returned false)",
					e);
			return false;
		}

//		return true;
	}

	@Override
	public String getName() {
		return Translator.swap("HetNutrientCyclingExport.name");
	}

	@Override
	public String getAuthor() {
		return "F. de Coligny, M. Jonard";
	}

	@Override
	public String getDescription() {
		return Translator.swap("HetNutrientCyclingExport.description");
	}

	@Override
	public String getVersion() {
		return "1.0";
	}

	/**
	 * Export: turns the given Scene into a collection of records In script
	 * mode, save (fileName) must be called after.
	 */
	@Override
	public void createRecordSet(GScene s) throws Exception {
		HetScene scene = (HetScene) s;
		super.createRecordSet(scene); // deals with RecordSet's source

		// 1. Custom headers
		add(new CommentRecord("Heterofor Nutrient Cyclig Export (HetNutrientCyclingExport) at " + new Date()));
		add(new EmptyRecord());

		// Tree line header
		add(new CommentRecord("date\thorizonId\tsoilCompartment\teltName\tconcentration"));

		// For each step in the scenario from the root, write a block
		Step step = scene.getStep();
		Project project = step.getProject();
		for (Step st : project.getStepsFromRoot(step)) {

//			add(new EmptyRecord());
			writeLines((HetScene) st.getScene());

		}

	}

	private void writeLines(HetScene scene) {

		HetSoilInterface soil = scene.getSoil();

		// fc-13.11.2019		
		for (HetHorizon h : soil.getPedonSpecimen().getHorizons()) {
//		for (HetHorizon h : soil.getHorizons()) {

			// Solution
			// pH
			Line r = new Line();
			r.date = scene.getDate();
			r.horizonId = h.id;
			r.soilCompartment = "solution";
			r.eltName = "pH";
			r.concentration = h.solution_pH;
			add(r);

			for (String eltName : h.getSolutionConcentrations().keySet()) {
				double conc = h.getSolutionConcentration(eltName);

				r = new Line();
				r.date = scene.getDate();
				r.horizonId = h.id;
				r.soilCompartment = "solution";
				r.eltName = eltName;
				r.concentration = conc;
				add(r);

			}

			// ExchangeableCations
			for (String exchName : h.getExchangeableCationConcentrations().keySet()) {
				double conc = h.getExchCationConcentration(exchName);

				r = new Line();
				r.date = scene.getDate();
				r.horizonId = h.id;
				r.soilCompartment = "exchangeableCations";
				r.eltName = exchName;
				r.concentration = conc;
				add(r);

			}

			// ExchangeableAnions
			for (String exchName : h.getExchangeableAnionConcentrations().keySet()) {
				double conc = h.getExchAnionConcentration(exchName);

				r = new Line();
				r.date = scene.getDate();
				r.horizonId = h.id;
				r.soilCompartment = "exchangeableAnions";
				r.eltName = exchName;
				r.concentration = conc;
				add(r);

			}

			// Minerals
			for (String mineralName : h.getMineralConcentrations().keySet()) {
				HetMineral m = h.getMineral(mineralName);

				double conc = m.concentration; // mole/kg

				r = new Line();
				r.date = scene.getDate();
				r.horizonId = h.id;
				r.soilCompartment = "minerals";
				r.eltName = mineralName;
				r.concentration = conc;
				add(r);

			}

		}

	}

	/**
	 * Importation is not implemented here
	 */
	@Override
	public GScene load(GModel m) throws Exception {
		return null;
	}

}