/*
 * The HETEROFOR model.
 *
 * Copyright (C) 2012-2019: M. Jonard (UCL ELIe Forest Science).
 *
 * This file is part of the HETEROFOR model and is free software:  you can redistribute it and/or
 * modifiy it under the terms of the GNU Lesser General Public License as published by the
 * Free Software Foundation, version 2.1 of the License, or (at your option) any later version.
 */

package heterofor.extension.ioformat;

import heterofor.model.HetInitialParameters;
import heterofor.model.HetModel;
import heterofor.model.HetScene;
import heterofor.model.HetSpecies;
import heterofor.model.phenology.HetPhenology;
import heterofor.model.phenology.HetPhenologyDate;

import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.Vector;

import jeeb.lib.util.Translator;
import capsis.kernel.GModel;
import capsis.kernel.GScene;
import capsis.kernel.Step;
import capsis.util.Calendar;
import capsis.util.StandRecordSet;

/**
 * Exports the evolution of the foliage state over time per species. The foliage state is composed of
 * the proportion of green leaves compared to the level of maximum development (greenProp coefficient,
 * see {@link heterofor.model.phenology.HetPhenology#getDoyGreenPropMap()}) and the proportion compared
 * to the level of maximum development (ladProp coeffcient, see {@link heterofor.model.phenology.HetPhenology#getDoyLadPropMap()}).
 *
 * @author N. Beudez - June 2017
 */
public class HetSpeciesFoliageStateExport extends StandRecordSet {

	static {
		Translator.addBundle("heterofor.extension.ioformat.ExportLabels");
	}

	// Extension properties
	// nb-13.08.2018
	//public static String NAME = Translator.swap("HetFoliageStateExport");
	//public static String AUTHOR = "N. Beudez";
	//public static String VERSION = "1.0";
	//public static String DESCRIPTION = Translator.swap("HetFoliageStateExport.description");

	private static final String TAB = "\t";

	/**
	 * Constructor
	 */
	public HetSpeciesFoliageStateExport() {

		super();
		// Do not write the standard header lines in the output file
		setHeaderEnabled(false);
	}

	/**
	 * Extension dynamic compatibility mechanism. This matchWith method checks
	 * if the extension can deal (i.e. is compatible) with the referent.
	 */
	static public boolean matchWith(Object referent) {

		return referent instanceof HetModel;
	}

	@Override
	public String getName() {
		return Translator.swap("HetFoliageStateExport.name");
	}

	@Override
	public String getAuthor() {
		return "N. Beudez";
	}

	@Override
	public String getDescription() {
		return Translator.swap("HetFoliageStateExport.description");
	}

	@Override
	public String getVersion() {
		return "1.0";
	}

	/**
	 * Export: turns the given Scene into a collection of records. In script
	 * mode, save (fileName) must be called after.
	 */
	@Override
	public void createRecordSet(GScene s) throws Exception {

		HetScene scene = (HetScene) s;
		super.createRecordSet(scene); // deals with RecordSet's source

		// Custom headers
		add(new CommentRecord("Heterofor scene export (HetSpeciesFoliageStateExport) at " + new Date()));
		add(new EmptyRecord());

		HetInitialParameters ip = (HetInitialParameters) s.getStep().getProject().getModel().getSettings();

		Collection<HetSpecies> speciesCollection = ip.speciesMap.values();

		String lineHeader = "date (dd/mm/yyyy)" + TAB + "dayOfYear";

		for (int i=0 ; i<speciesCollection.size() ; ++i) {
			lineHeader += TAB + "speciesName" + TAB + "greenProp (-)" + TAB + "ladProp (-)";
		}

		// Tree line header
		add(new CommentRecord(lineHeader));

		writeLines((HetScene) s);
	}

	/**
	 * Writes a line for each day from initial scene to current scene.
	 * @param scene The reference to the current scene
	 */
	private void writeLines(HetScene scene) {

		HetInitialParameters ip = (HetInitialParameters) scene.getStep().getProject().getModel().getSettings();

		// Retrieve Steps from root to reference step
		Step step = scene.getStep();
		Vector steps = step.getProject().getStepsFromRoot(step);
		Iterator iterator = steps.iterator();

		// Loop on steps
		while (iterator.hasNext()) {

			Step s = (Step) iterator.next();
			HetScene sc = (HetScene) s.getScene();
			int year = sc.getDate();

			int nbOfDaysInyear;

			if (Calendar.isLeap(year)) {
				nbOfDaysInyear = 366;
			} else {
				nbOfDaysInyear = 365;
			}

			for (int doy=1 ; doy<=nbOfDaysInyear ; ++doy) {

				String date = HetPhenologyDate.getYearMonthDay(year, doy);
				String str = date + TAB + doy;

				Collection<HetSpecies> speciesCollection = ip.speciesMap.values();

				for (HetSpecies species : speciesCollection) {

					String speciesName = species.getName();

					int speciesId = species.getValue();
					HetPhenology phenology = sc.getPhenologyMap().get(speciesId);
					double greenProp = phenology.getDoyGreenPropMap().get(doy);
					double ladProp = phenology.getDoyLadPropMap().get(doy);

					str += TAB + speciesName + TAB + greenProp + TAB + ladProp;
				}

				add(new FreeRecord(str));
			}
		}

	}

	/**
	 * Importation is not implemented here
	 */
	@Override
	public GScene load(GModel model) throws Exception {
		return null;
	}

}
