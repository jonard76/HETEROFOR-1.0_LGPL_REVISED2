/* 
 * The Heterofor model.
 *
 * Copyright (C) 2012-2017: M. Jonard (UCL ELIe Forest Science).
 * 
 * This file is part of the Heterofor model and is NOT free software.
 * It is the property of its authors and must not be copied without their 
 * permission. 
 * It can be shared by the modellers of the Capsis co-development community 
 * in agreement with the Capsis charter (http://capsis.cirad.fr/capsis/charter).
 * See the license.txt file in the Capsis installation directory 
 * for further information about licenses in Capsis.
 */

package heterofor.extension.ioformat;

import heterofor.model.HetModel;
import heterofor.model.HetScene;
import heterofor.model.waterbalance.HetHourlyTreeTranspiration;

import java.util.Date;
import java.util.Iterator;

import jeeb.lib.util.Import;
import jeeb.lib.util.Log;
import jeeb.lib.util.Record;
import jeeb.lib.util.Translator;
import capsis.kernel.GModel;
import capsis.kernel.GScene;
import capsis.kernel.Project;
import capsis.kernel.Step;
import capsis.util.StandRecordSet;

/**
 * Exports transpiration of each tree at an hourly time step
 * 
 * @author F. Andre - September 2019
 */
public class HetTreeTranspirationHourlyExport extends StandRecordSet {

	static {
		Translator.addBundle("heterofor.extension.ioformat.ExportLabels");
	}

	// Extension properties
	//static public String NAME = Translator.swap("HetHourlyTreeTranspirationExport");
	//static public String AUTHOR = "F. Andre";
	//static public String VERSION = "1.0";
	//static public String DESCRIPTION = Translator.swap("HetHourlyTreeTranspirationExport.description");

	// A line in the file
	@Import
	static public class Line extends Record {

		public Line() {
			super();
		}

		public Line(String line) throws Exception {
			super(line);
		}

		public int treeId;
		public int year;
		public int month;
		public int day;
		public int hour;

		public double treeTranspiration; // l
		public double treePotentialTranspiration; // l
	}

	static private final String TAB = "\t";

	/**
	 * Constructor
	 */
	public HetTreeTranspirationHourlyExport() {
		super();
		// Do not write the standard header lines in the output file
		setHeaderEnabled(false);
	}

	/**
	 * Extension dynamic compatibility mechanism. This matchWith method checks
	 * if the extension can deal (i.e. is compatible) with the referent.
	 */
	static public boolean matchWith(Object referent) {
		try {
			if (!(referent instanceof HetModel)) {
				return false;
			}

		} catch (Exception e) {
			Log.println(Log.ERROR, "HetExport.matchWith()", "Error in matchWith() (returned false)", e);
			return false;
		}

		return true;
	}

	@Override
	public String getName() {
		return Translator.swap("HetTreeTranspirationHourlyExport.name");
	}

	@Override
	public String getAuthor() {
		return "F. Andre";
	}

	@Override
	public String getDescription() {
		return Translator.swap("HetTreeTranspirationHourlyExport.description");
	}

	@Override
	public String getVersion() {
		return "1.0";
	}

	/**
	 * Export: create a list of records. In script mode, save (fileName) must be
	 * called after.
	 */
	@Override
	public void createRecordSet(GScene s) throws Exception {
		
		HetScene scene = (HetScene) s;
		super.createRecordSet(scene); // deals with RecordSet's source
		
		// 1. Custom headers
		add(new CommentRecord("Heterofor Tree Transpiration Hourly Export (HetExport) at " + new Date()));
		add(new EmptyRecord());

		// Tree line header
		add(new CommentRecord("Tree Transpiration lines"));
		String columnNames = "treeId" + TAB + "year" + TAB + "month" + TAB + "day" + TAB + "hour" + TAB + "treeTranspiration (l)" + TAB
				+ "treePotentialTranspiration (l)";
		add(new CommentRecord(columnNames));

		// For each step in the scenario from the root, write all trees

		Step step = scene.getStep();
		Project project = step.getProject();
				
		for (Step st : project.getStepsFromRoot(step)) {
			
			if (st.getScene().isInterventionResult()) //fa-02.12.2019: skip 'star scene' (result of intervention, with dead or thinned trees removed)
				continue;

			HetScene sc = (HetScene) st.getScene();			

			// add (new EmptyRecord ());
			if (sc.hourlyTreeTranspirationMap != null && !sc.hourlyTreeTranspirationMap.isEmpty()) { // no hourlyTreeTranspiration map for root step
				writeLines(sc);
			}
		}

	}

	/**
	 * Writes the tree transpiration for all hours of the given scene which represents a year of simulation.
	 */
	private void writeLines(HetScene scene) {		
		System.out.println(scene.hourlyTreeTranspirationMap.keySet().size());

		System.out.println("writeLines() date: " + scene.getDate() + "  size: " + scene.hourlyTreeTranspirationMap.keySet().size());

		// Remark: hourlyTreeTranspirationMap for initial scene is empty so that the following for () loop is not entered for 
		// the initial scene.
		for (Iterator<String> i = scene.hourlyTreeTranspirationMap.keySet().iterator(); i.hasNext();) {

			String key = i.next();
//			System.out.println("key: " + key);

			// htt contains tree transpiration for the current tree and hour (key is treeId_year_month_day_hour)
			HetHourlyTreeTranspiration htt = scene.hourlyTreeTranspirationMap.get(key);

			Line line = new Line();

			line.treeId = htt.treeId;
			line.year = htt.year;
			line.month = htt.month;
			line.day = htt.day;
			line.hour = htt.hour;

//			System.out.println("treeId: " + htt.treeId);
//			System.out.println("year: " + htt.year);
//			System.out.println("month: " + htt.month);
//			System.out.println("day: " + htt.day);
//			System.out.println("hour: " + htt.hour);
			
			//System.exit(1);
			
			line.treeTranspiration = htt.treeTranspiration;
			line.treePotentialTranspiration = htt.treePotentialTranspiration;

			add(line);
		}

	}

	/**
	 * Importation is not implemented here
	 */
	@Override
	public GScene load(GModel m) throws Exception {
		return null;
	}

}
